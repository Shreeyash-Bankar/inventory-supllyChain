import React, { useState } from 'react';
import { Canvas3D } from './components/Canvas3D';
import { TopNav } from './components/TopNav';
import { AntennaControlPanel } from './components/AntennaControlPanel';
import { RadiationTooltip } from './components/RadiationTooltip';
import { BottomAnalyticsDock } from './components/BottomAnalyticsDock';
import { LinkBudgetHUD } from './components/LinkBudgetHUD';
import { ViewportControls } from './components/ViewportControls';
import { SlidersHorizontal, X } from 'lucide-react';

export const App: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = useState(true);

  return (
    <div className="flex flex-col h-screen w-screen bg-[#070b14] text-slate-100 overflow-hidden font-sans">
      {/* Top Header */}
      <TopNav />

      {/* Main Workspace Body */}
      <div className="relative flex-1 flex overflow-hidden">
        {/* Left Side Control Panel */}
        <aside
          className={`relative z-20 h-full transition-all duration-300 ease-in-out ${
            sidebarOpen ? 'w-80 md:w-96' : 'w-0'
          }`}
        >
          {sidebarOpen && <AntennaControlPanel />}
        </aside>

        {/* Sidebar Toggle Handle */}
        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          title={sidebarOpen ? 'Collapse Parameters Panel' : 'Expand Parameters Panel'}
          className="absolute top-4 left-4 z-30 p-2.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/80 shadow-2xl backdrop-blur-md transition-all flex items-center space-x-1"
          style={{ left: sidebarOpen ? 'calc(24rem + 12px)' : '1rem' }}
        >
          {sidebarOpen ? <X className="w-4 h-4" /> : <SlidersHorizontal className="w-4 h-4 text-sky-400" />}
          {!sidebarOpen && <span className="text-xs font-mono font-medium">Antenna Config</span>}
        </button>

        {/* 3D Canvas Area */}
        <main className="relative flex-1 h-full w-full overflow-hidden">
          <Canvas3D />

          {/* Interactive Floating Hover Telemetry Tooltip */}
          <RadiationTooltip />

          {/* Point-to-Point Link Budget Engine HUD (active in Link Budget Mode) */}
          <LinkBudgetHUD />

          {/* Viewport & Scene Helper Controls */}
          <ViewportControls />

          {/* Bottom Analytics Dock (Antenna Comparison Matrix & 2D Polar Plots) */}
          <BottomAnalyticsDock />
        </main>
      </div>
    </div>
  );
};

export default App;
