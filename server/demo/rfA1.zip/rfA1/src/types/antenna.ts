import { WeatherCondition } from "../math/rfPhysics";

export type AntennaType =
  | "dipole"
  | "monopole"
  | "patch"
  | "yagi"
  | "horn"
  | "helical"
  | "isotropic";

export type ColormapType = "turbo" | "jet" | "viridis" | "plasma" | "electric";
export type AntennaRole = "transmitter" | "receiver";
export type HeatmapMetric =
  | "dbi"
  | "rssi"
  | "snr"
  | "field_strength"
  | "power_density";

export type ViewMode = "side-by-side" | "overlaid" | "link-budget";

export type GizmoMode = "translate" | "rotate" | "none";

export interface AntennaConfig {
  id: string;
  name: string;
  color: string;
  enabled: boolean;
  type: AntennaType;
  role: AntennaRole;
  // Core user-requested parameters:
  powerMilliwatts: number; // 0.01 mW to 100,000 mW (100 W)
  gainDbi: number; // Peak Gain in dBi (e.g. -10 to +30 dBi)
  lengthMm: number; // Antenna physical length in mm
  frequencyMHz: number; // Frequency in MHz (e.g. 100 MHz to 60,000 MHz)
  diameterMm: number; // Antenna element diameter / thickness in mm
  // Visual & spatial controls
  position: [number, number, number];
  rotation: [number, number, number]; // [Pitch X, Yaw Y, Roll Z] in degrees
  showLobe: boolean;
  showPhysicalAntenna: boolean;
  wireframe: boolean;
  opacity: number;
  scaleLobe: number; // visual scale factor
}

export interface RFEnvironmentConfig {
  weather: WeatherCondition;
  bandwidthMHz: number; // e.g. 20 MHz (Wi-Fi), 0.125 MHz (LoRa), 100 MHz (5G)
  noiseFigureDb: number; // typical 4-7 dB
  temperatureK: number; // default 290K
}

export interface HoverInspectionData {
  antennaId: string;
  antennaName: string;
  color: string;
  worldPosition: [number, number, number];
  distanceFromCenter: number; // distance in current canvas scale or meters
  thetaDeg: number; // Polar angle 0..180
  phiDeg: number; // Azimuth angle -180..180
  dbiAtPoint: number; // Calculated gain at this angle
  relativeGainLinear: number;
  // RF telemetry at chosen reference distance or raycast distance
  evalDistanceMeters: number;
  rssiAtDistanceDbm: number;
  fsplDb: number;
  atmosphericLossDb: number; // Atmospheric absorption loss
  noiseFloorDbm: number; // Receiver thermal noise floor
  snrDb: number; // Signal-to-Noise Ratio (RSSI - Noise)
  modulationGrade: string; // e.g. 256-QAM, 64-QAM, QPSK, BPSK, etc.
  eFieldVm: number;
  powerDensityUWCm2: number;
  eirpDbm: number;
  eirpWatts: number;
  coverageMaxMeters: number; // Max distance where signal >= rxSensitivity
  rxSensitivityDbm: number;
}
