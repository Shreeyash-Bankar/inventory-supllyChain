import React, { useRef, useEffect } from 'react';
import { useAntennaStore } from '../store/antennaStore';
import { calculateRadiationPattern } from '../math/radiationPatterns';

interface PolarPlotProps {
  plane: 'elevation' | 'azimuth';
  width?: number;
  height?: number;
}

export const PolarPlot: React.FC<PolarPlotProps> = ({ plane = 'elevation', width = 280, height = 280 }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const antenna1 = useAntennaStore((s) => s.antenna1);
  const antenna2 = useAntennaStore((s) => s.antenna2);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Retina support
    const dpr = window.devicePixelRatio || 1;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    ctx.scale(dpr, dpr);

    const centerX = width / 2;
    const centerY = height / 2;
    const maxRadius = Math.min(centerX, centerY) - 24;

    // Clear background
    ctx.fillStyle = '#090d16';
    ctx.fillRect(0, 0, width, height);

    // Draw dB concentric rings
    const dbRings = [
      { db: 0, label: '0 dB' },
      { db: -3, label: '-3 dB' },
      { db: -10, label: '-10 dB' },
      { db: -20, label: '-20 dB' },
      { db: -30, label: '-30 dB' },
    ];

    ctx.lineWidth = 1;
    dbRings.forEach((ring) => {
      // Map 0dB to maxRadius, -30dB to 0
      const r = maxRadius * Math.pow(10, ring.db / 30);
      ctx.strokeStyle = ring.db === -3 ? 'rgba(234, 179, 8, 0.4)' : 'rgba(51, 65, 85, 0.45)';
      ctx.setLineDash(ring.db === -3 ? [2, 2] : []);
      ctx.beginPath();
      ctx.arc(centerX, centerY, r, 0, 2 * Math.PI);
      ctx.stroke();

      // Ring text
      ctx.fillStyle = ring.db === -3 ? '#eab308' : '#64748b';
      ctx.font = '8px monospace';
      ctx.fillText(ring.label, centerX + 3, centerY - r + 9);
    });

    ctx.setLineDash([]);

    // Draw Radial Angle Rays (every 30 degrees)
    for (let deg = 0; deg < 360; deg += 30) {
      const rad = (deg * Math.PI) / 180;
      const x = centerX + Math.cos(rad) * maxRadius;
      const y = centerY + Math.sin(rad) * maxRadius;

      ctx.strokeStyle = 'rgba(51, 65, 85, 0.35)';
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.lineTo(x, y);
      ctx.stroke();

      // Angle label at edge
      const labelX = centerX + Math.cos(rad) * (maxRadius + 12);
      const labelY = centerY + Math.sin(rad) * (maxRadius + 12);
      ctx.fillStyle = '#64748b';
      ctx.font = '8px monospace';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(`${deg}°`, labelX, labelY);
    }

    // Function to draw an antenna's curve
    const drawAntennaPattern = (config: typeof antenna1, strokeColor: string) => {
      if (!config.enabled) return;

      ctx.beginPath();
      ctx.strokeStyle = strokeColor;
      ctx.lineWidth = 2;
      ctx.shadowColor = strokeColor;
      ctx.shadowBlur = 4;

      const steps = 180;
      for (let i = 0; i <= steps; i++) {
        const angle = (i / steps) * 2 * Math.PI;

        let theta = 0;
        let phi = 0;

        if (plane === 'elevation') {
          // Elevation cut: phi = 0, angle is theta [0, 2*PI]
          theta = angle;
          phi = 0;
        } else {
          // Azimuth cut: theta = PI/2, angle is phi
          theta = Math.PI / 2;
          phi = angle;
        }

        const sample = calculateRadiationPattern(theta, phi, config);
        // sample.relativeLinear is 0..1
        // Dynamic dB range: 30 dB
        const linearDb = Math.max(-30, 20 * Math.log10(Math.max(1e-4, sample.relativeLinear)));
        const normR = Math.max(0.05, (linearDb + 30) / 30);
        const r = normR * maxRadius;

        // In 2D: 0 rad is Up or Right. Let's orient 0° at Top (Y-axis):
        const px = centerX + r * Math.sin(angle);
        const py = centerY - r * Math.cos(angle);

        if (i === 0) {
          ctx.moveTo(px, py);
        } else {
          ctx.lineTo(px, py);
        }
      }
      ctx.closePath();
      ctx.stroke();
      ctx.shadowBlur = 0;
    };

    // Draw Antenna 1 (Sky Blue) & Antenna 2 (Rose)
    drawAntennaPattern(antenna1, antenna1.color);
    drawAntennaPattern(antenna2, antenna2.color);

    // Title label
    ctx.fillStyle = '#94a3b8';
    ctx.font = '10px monospace';
    ctx.textAlign = 'left';
    ctx.fillText(plane === 'elevation' ? 'Elevation (E-Plane)' : 'Azimuth (H-Plane)', 8, 14);
  }, [antenna1, antenna2, plane, width, height]);

  return <canvas ref={canvasRef} style={{ width, height }} className="rounded-xl border border-slate-800" />;
};
