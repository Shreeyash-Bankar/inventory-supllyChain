// // import * as THREE from 'three';
// // import { AntennaConfig, ColormapType, HeatmapMetric, RFEnvironmentConfig } from '../../types/antenna';
// // import { calculateRadiationPattern } from '../../math/radiationPatterns';
// // import { getColorFromColormap } from '../../math/colormaps';
// // import {
// //   mwToDbm,
// //   calculateReceivedPowerDbm,
// //   calculateElectricField,
// //   calculatePowerDensityUWCm2,
// //   calculateEIRP,
// //   calculateSNR,
// // } from '../../math/rfPhysics';

// // /**
// //  * Builds the 3D Radiation Lobe Mesh with vertex colors corresponding to the radiation heatmap
// //  */
// // export function createRadiationLobeMesh(
// //   config: AntennaConfig,
// //   colormap: ColormapType,
// //   heatmapMetric: HeatmapMetric,
// //   evalDistanceMeters: number,
// //   rfEnvironment?: RFEnvironmentConfig
// // ): THREE.Mesh {
// //   // Discretization: 64 theta steps (polar), 96 phi steps (azimuth)
// //   const uSegments = 64; // theta
// //   const vSegments = 96; // phi

// //   const vertexCount = (uSegments + 1) * (vSegments + 1);
// //   const positions = new Float32Array(vertexCount * 3);
// //   const colors = new Float32Array(vertexCount * 3);
// //   const normals = new Float32Array(vertexCount * 3);
// //   const uvs = new Float32Array(vertexCount * 2);
// //   const indices: number[] = [];

// //   const { gainDbi, powerMilliwatts, frequencyMHz } = config;
// //   const { eirpWatts } = calculateEIRP(powerMilliwatts, gainDbi);

// //   const weather = rfEnvironment?.weather || 'clear';
// //   const bwHz = (rfEnvironment?.bandwidthMHz || 20) * 1e6;
// //   const nfDb = rfEnvironment?.noiseFigureDb || 5;

// //   // Determine dynamic range for heatmap metric
// //   const peakDbi = gainDbi;
// //   const minDbi = peakDbi - 30; // 30 dB dynamic range

// //   let vertexIndex = 0;

// //   for (let i = 0; i <= uSegments; i++) {
// //     const u = i / uSegments;
// //     const theta = u * Math.PI; // 0 to PI

// //     for (let j = 0; j <= vSegments; j++) {
// //       const v = j / vSegments;
// //       const phi = v * 2 * Math.PI - Math.PI; // -PI to PI

// //       // Sample radiation pattern
// //       const sample = calculateRadiationPattern(theta, phi, config);

// //       const r = sample.radius * (config.scaleLobe || 1.0);
// //       const sinT = Math.sin(theta);
// //       const cosT = Math.cos(theta);
// //       const sinP = Math.sin(phi);
// //       const cosP = Math.cos(phi);

// //       const px = r * sinT * cosP;
// //       const py = r * cosT;
// //       const pz = r * sinT * sinP;

// //       const pIdx = vertexIndex * 3;
// //       positions[pIdx] = px;
// //       positions[pIdx + 1] = py;
// //       positions[pIdx + 2] = pz;

// //       // Calculate normalized value for heatmap coloring
// //       let normVal = 0;

// //       switch (heatmapMetric) {
// //         case 'dbi': {
// //           normVal = (sample.gainDbi - minDbi) / Math.max(1, peakDbi - minDbi);
// //           break;
// //         }
// //         case 'rssi': {
// //           const { rssiDbm } = calculateReceivedPowerDbm(powerMilliwatts, sample.gainDbi, 0, evalDistanceMeters, frequencyMHz, weather);
// //           const maxRssi = mwToDbm(powerMilliwatts) + peakDbi - 40;
// //           const minRssi = maxRssi - 35;
// //           normVal = (rssiDbm - minRssi) / Math.max(1, maxRssi - minRssi);
// //           break;
// //         }
// //         case 'snr': {
// //           const { rssiDbm } = calculateReceivedPowerDbm(powerMilliwatts, sample.gainDbi, 0, evalDistanceMeters, frequencyMHz, weather);
// //           const { snrDb } = calculateSNR(rssiDbm, bwHz, nfDb);
// //           // Map -5 dB to +35 dB onto [0, 1]
// //           normVal = (snrDb - (-5)) / 40;
// //           break;
// //         }
// //         case 'field_strength': {
// //           const eField = calculateElectricField(eirpWatts * Math.pow(sample.relativeLinear, 2), evalDistanceMeters);
// //           const maxE = calculateElectricField(eirpWatts, evalDistanceMeters);
// //           normVal = eField / Math.max(0.001, maxE);
// //           break;
// //         }
// //         case 'power_density': {
// //           const s = calculatePowerDensityUWCm2(eirpWatts * Math.pow(sample.relativeLinear, 2), evalDistanceMeters);
// //           const maxS = calculatePowerDensityUWCm2(eirpWatts, evalDistanceMeters);
// //           normVal = s / Math.max(0.001, maxS);
// //           break;
// //         }
// //       }

// //       normVal = Math.max(0, Math.min(1, normVal));
// //       const col = getColorFromColormap(normVal, colormap);

// //       colors[pIdx] = col.r;
// //       colors[pIdx + 1] = col.g;
// //       colors[pIdx + 2] = col.b;

// //       uvs[vertexIndex * 2] = v;
// //       uvs[vertexIndex * 2 + 1] = u;

// //       vertexIndex++;
// //     }
// //   }

// //   // Create Triangles
// //   for (let i = 0; i < uSegments; i++) {
// //     for (let j = 0; j < vSegments; j++) {
// //       const a = i * (vSegments + 1) + j;
// //       const b = (i + 1) * (vSegments + 1) + j;
// //       const c = (i + 1) * (vSegments + 1) + (j + 1);
// //       const d = i * (vSegments + 1) + (j + 1);

// //       indices.push(a, b, d);
// //       indices.push(b, c, d);
// //     }
// //   }

// //   const geometry = new THREE.BufferGeometry();
// //   geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
// //   geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
// //   geometry.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
// //   geometry.setIndex(indices);
// //   geometry.computeVertexNormals();

// //   // Mesh Material
// //   const material = new THREE.MeshStandardMaterial({
// //     vertexColors: true,
// //     roughness: 0.25,
// //     metalness: 0.15,
// //     wireframe: config.wireframe,
// //     transparent: true,
// //     opacity: config.opacity,
// //     side: THREE.DoubleSide,
// //     depthWrite: false, // Prevents Z-fighting in transparent dual lobes
// //   });

// //   const mesh = new THREE.Mesh(geometry, material);
// //   mesh.name = `radiation-lobe-${config.id}`;
// //   mesh.userData = { configId: config.id, isRadiationLobe: true };

// //   return mesh;
// // }

// // /**
// //  * Builds physical 3D antenna representation (brass/copper/dielectric realistic models)
// //  */
// // export function createPhysicalAntennaMesh(config: AntennaConfig): THREE.Group {
// //   const group = new THREE.Group();
// //   group.name = `physical-antenna-${config.id}`;

// //   const { type, lengthMm, diameterMm } = config;

// //   // Normalized scale: map 100mm -> 1.0 unit in 3D scene
// //   const lengthScale = Math.max(0.2, Math.min(4.0, (lengthMm / 100)));
// //   const diaScale = Math.max(0.015, Math.min(0.25, (diameterMm / 100)));

// //   // Materials
// //   const copperMaterial = new THREE.MeshStandardMaterial({
// //     color: 0xcd7f32,
// //     metalness: 0.9,
// //     roughness: 0.2,
// //   });

// //   const brassMaterial = new THREE.MeshStandardMaterial({
// //     color: 0xd4af37,
// //     metalness: 0.85,
// //     roughness: 0.25,
// //   });

// //   const chromeMaterial = new THREE.MeshStandardMaterial({
// //     color: 0xdde2ea,
// //     metalness: 0.95,
// //     roughness: 0.1,
// //   });

// //   const pcbMaterial = new THREE.MeshStandardMaterial({
// //     color: 0x14532d, // dark FR4 green
// //     metalness: 0.1,
// //     roughness: 0.5,
// //   });

// //   const feedMaterial = new THREE.MeshStandardMaterial({
// //     color: 0x1e293b,
// //     metalness: 0.4,
// //     roughness: 0.6,
// //   });

// //   switch (type) {
// //     case 'dipole': {
// //       // Center fed dipole with upper and lower elements along Y axis
// //       const armLength = (lengthScale * 0.95) / 2;
// //       const radius = Math.max(0.02, diaScale);

// //       // Upper arm
// //       const upperGeo = new THREE.CylinderGeometry(radius, radius, armLength, 16);
// //       const upperMesh = new THREE.Mesh(upperGeo, brassMaterial);
// //       upperMesh.position.y = armLength / 2 + 0.04;

// //       // Lower arm
// //       const lowerGeo = new THREE.CylinderGeometry(radius, radius, armLength, 16);
// //       const lowerMesh = new THREE.Mesh(lowerGeo, brassMaterial);
// //       lowerMesh.position.y = -armLength / 2 - 0.04;

// //       // Center feedpoint insulator / balun
// //       const feedGeo = new THREE.CylinderGeometry(radius * 1.6, radius * 1.6, 0.08, 16);
// //       const feedMesh = new THREE.Mesh(feedGeo, feedMaterial);

// //       // Coax feed connector
// //       const coaxGeo = new THREE.CylinderGeometry(radius * 0.8, radius * 0.8, 0.35, 12);
// //       const coaxMesh = new THREE.Mesh(coaxGeo, chromeMaterial);
// //       coaxMesh.rotation.z = Math.PI / 2;
// //       coaxMesh.position.x = -0.18;

// //       group.add(upperMesh, lowerMesh, feedMesh, coaxMesh);
// //       break;
// //     }

// //     case 'monopole': {
// //       // Quarter-wave whip along +Y over ground plane disc
// //       const whipLength = lengthScale * 0.9;
// //       const radius = Math.max(0.02, diaScale);

// //       // Ground plane disc
// //       const groundGeo = new THREE.CylinderGeometry(radius * 8, radius * 8, 0.03, 32);
// //       const groundMesh = new THREE.Mesh(groundGeo, chromeMaterial);
// //       groundMesh.position.y = 0;

// //       // Whip element
// //       const whipGeo = new THREE.CylinderGeometry(radius * 0.7, radius, whipLength, 16);
// //       const whipMesh = new THREE.Mesh(whipGeo, brassMaterial);
// //       whipMesh.position.y = whipLength / 2 + 0.02;

// //       // SMA base
// //       const baseGeo = new THREE.CylinderGeometry(radius * 2, radius * 2, 0.1, 16);
// //       const baseMesh = new THREE.Mesh(baseGeo, feedMaterial);
// //       baseMesh.position.y = -0.05;

// //       group.add(groundMesh, whipMesh, baseMesh);
// //       break;
// //     }

// //     case 'patch': {
// //       // Microstrip patch: FR4 PCB substrate + copper rectangular patch on top facing +X
// //       const size = lengthScale * 0.7;
// //       const subGeo = new THREE.BoxGeometry(0.04, size * 1.3, size * 1.3);
// //       const subMesh = new THREE.Mesh(subGeo, pcbMaterial);

// //       const patchGeo = new THREE.BoxGeometry(0.02, size * 0.9, size * 0.9);
// //       const patchMesh = new THREE.Mesh(patchGeo, copperMaterial);
// //       patchMesh.position.x = 0.025; // on top of substrate facing +X

// //       // SMA connector on the back
// //       const smaGeo = new THREE.CylinderGeometry(0.04, 0.04, 0.15, 12);
// //       const smaMesh = new THREE.Mesh(smaGeo, brassMaterial);
// //       smaMesh.rotation.z = Math.PI / 2;
// //       smaMesh.position.x = -0.09;

// //       group.add(subMesh, patchMesh, smaMesh);
// //       break;
// //     }

// //     case 'yagi': {
// //       // Boom + Reflector + Driven element + Directors along +X axis
// //       const boomLength = lengthScale * 1.5;
// //       const boomGeo = new THREE.CylinderGeometry(0.025, 0.025, boomLength, 12);
// //       const boomMesh = new THREE.Mesh(boomGeo, chromeMaterial);
// //       boomMesh.rotation.z = Math.PI / 2;
// //       boomMesh.position.x = boomLength / 2 - 0.2;

// //       // Reflector (longest element at rear)
// //       const refLen = lengthScale * 0.95;
// //       const refGeo = new THREE.CylinderGeometry(0.015, 0.015, refLen, 12);
// //       const refMesh = new THREE.Mesh(refGeo, chromeMaterial);
// //       refMesh.position.x = -0.15;

// //       // Driven element (dipole with feed)
// //       const drvLen = lengthScale * 0.85;
// //       const drvGeo = new THREE.CylinderGeometry(0.018, 0.018, drvLen, 12);
// //       const drvMesh = new THREE.Mesh(drvGeo, brassMaterial);
// //       drvMesh.position.x = 0.08;

// //       group.add(boomMesh, refMesh, drvMesh);

// //       // 4 Directors spaced along +X
// //       for (let i = 1; i <= 4; i++) {
// //         const dirLen = drvLen * (1 - i * 0.06);
// //         const dirGeo = new THREE.CylinderGeometry(0.015, 0.015, dirLen, 12);
// //         const dirMesh = new THREE.Mesh(dirGeo, chromeMaterial);
// //         dirMesh.position.x = 0.08 + i * (boomLength / 5);
// //         group.add(dirMesh);
// //       }
// //       break;
// //     }

// //     case 'horn': {
// //       // Pyramidal flared horn facing +X
// //       const hornLength = lengthScale * 0.9;
// //       const apertureSize = Math.max(0.4, diaScale * 3);
// //       const throatSize = 0.12;

// //       // Flared horn pyramid
// //       const hornGeo = new THREE.CylinderGeometry(apertureSize, throatSize, hornLength, 4, 1, true);
// //       const hornMesh = new THREE.Mesh(hornGeo, brassMaterial);
// //       hornMesh.rotation.z = -Math.PI / 2;
// //       hornMesh.rotation.y = Math.PI / 4;
// //       hornMesh.position.x = hornLength / 2;

// //       // Waveguide throat & flange
// //       const throatGeo = new THREE.CylinderGeometry(throatSize, throatSize, 0.2, 4);
// //       const throatMesh = new THREE.Mesh(throatGeo, chromeMaterial);
// //       throatMesh.rotation.z = -Math.PI / 2;
// //       throatMesh.rotation.y = Math.PI / 4;
// //       throatMesh.position.x = -0.1;

// //       group.add(hornMesh, throatMesh);
// //       break;
// //     }

// //     case 'helical': {
// //       // Ground reflector disc + helical wire wound along +Z or +Y
// //       const groundGeo = new THREE.CylinderGeometry(0.5, 0.5, 0.02, 24);
// //       const groundMesh = new THREE.Mesh(groundGeo, chromeMaterial);
// //       groundMesh.position.y = -0.1;

// //       // Spiral coil curve
// //       const turns = 6;
// //       const height = lengthScale * 1.1;
// //       const coilRadius = Math.max(0.12, diaScale);
// //       const curvePoints: THREE.Vector3[] = [];

// //       for (let t = 0; t <= 120; t++) {
// //         const angle = (t / 120) * (turns * 2 * Math.PI);
// //         const cy = (t / 120) * height;
// //         const cx = coilRadius * Math.cos(angle);
// //         const cz = coilRadius * Math.sin(angle);
// //         curvePoints.push(new THREE.Vector3(cx, cy, cz));
// //       }

// //       const curve = new THREE.CatmullRomCurve3(curvePoints);
// //       const tubeGeo = new THREE.TubeGeometry(curve, 90, 0.015, 8, false);
// //       const tubeMesh = new THREE.Mesh(tubeGeo, copperMaterial);

// //       group.add(groundMesh, tubeMesh);
// //       break;
// //     }

// //     case 'isotropic':
// //     default: {
// //       // Glowing omnidirectional beacon sphere
// //       const sphereGeo = new THREE.SphereGeometry(0.12, 24, 24);
// //       const sphereMat = new THREE.MeshStandardMaterial({
// //         color: 0x38bdf8,
// //         emissive: 0x0284c7,
// //         emissiveIntensity: 0.6,
// //         roughness: 0.2,
// //       });
// //       const beacon = new THREE.Mesh(sphereGeo, sphereMat);
// //       group.add(beacon);
// //       break;
// //     }
// //   }

// //   // Anchor ring indicator
// //   const ringGeo = new THREE.RingGeometry(0.1, 0.15, 24);
// //   const ringMat = new THREE.MeshBasicMaterial({
// //     color: new THREE.Color(config.color),
// //     side: THREE.DoubleSide,
// //     transparent: true,
// //     opacity: 0.8,
// //   });
// //   const ring = new THREE.Mesh(ringGeo, ringMat);
// //   ring.rotation.x = Math.PI / 2;
// //   ring.position.y = -0.01;
// //   group.add(ring);

// //   return group;
// // }
// import * as THREE from "three";
// import {
//   AntennaConfig,
//   ColormapType,
//   HeatmapMetric,
//   RFEnvironmentConfig,
// } from "../../types/antenna";
// import { calculateRadiationPattern } from "../../math/radiationPatterns";
// import { getColorFromColormap } from "../../math/colormaps";
// import {
//   calculateElectricField,
//   calculatePowerDensityUWCm2,
// } from "../../math/rfPhysics";
// import { calculateDirectionalCoverageMetrics } from "../../math/directionalCoverage";

// /**
//  * Builds a radiation-pattern mesh whose radius is the maximum usable RF range
//  * in each direction. The pattern still controls the shape; the RF link budget
//  * controls how far each part of the shape extends.
//  */
// export function createRadiationLobeMesh(
//   config: AntennaConfig,
//   peerConfig: AntennaConfig,
//   rxSensitivityDbm: number,
//   colormap: ColormapType,
//   heatmapMetric: HeatmapMetric,
//   evalDistanceMeters: number,
//   rfEnvironment?: RFEnvironmentConfig,
// ): THREE.Mesh {
//   // Keep the existing mesh resolution and visual quality.
//   const uSegments = 64; // theta
//   const vSegments = 96; // phi

//   const vertexCount = (uSegments + 1) * (vSegments + 1);
//   const positions = new Float32Array(vertexCount * 3);
//   const colors = new Float32Array(vertexCount * 3);
//   const uvs = new Float32Array(vertexCount * 2);
//   const indices: number[] = [];

//   // The configured gainDbi is the peak of the normalized pattern model.
//   const peakDbi = config.gainDbi;
//   const minDbi = peakDbi - 30; // Keep the existing 30 dB gain-color range.
//   const peakMetrics = calculateDirectionalCoverageMetrics(
//     config,
//     peerConfig,
//     peakDbi,
//     evalDistanceMeters,
//     rxSensitivityDbm,
//     rfEnvironment,
//   );
//   const peakEField = calculateElectricField(
//     peakMetrics.eirpWatts,
//     evalDistanceMeters,
//   );
//   const peakPowerDensity = calculatePowerDensityUWCm2(
//     peakMetrics.eirpWatts,
//     evalDistanceMeters,
//   );

//   const scaleLobe = Math.max(0.01, config.scaleLobe || 1);
//   let vertexIndex = 0;

//   for (let i = 0; i <= uSegments; i++) {
//     const theta = (i / uSegments) * Math.PI;

//     for (let j = 0; j <= vSegments; j++) {
//       const phi = (j / vSegments) * 2 * Math.PI - Math.PI;
//       const sample = calculateRadiationPattern(theta, phi, config);

//       // A TX lobe uses directional TX gain. An RX lobe uses the reciprocal
//       // directional RX gain. The partner is assumed optimally aligned at peak
//       // gain, so this is a potential-coverage envelope, not the live link SNR.
//       const metrics = calculateDirectionalCoverageMetrics(
//         config,
//         peerConfig,
//         sample.gainDbi,
//         evalDistanceMeters,
//         rxSensitivityDbm,
//         rfEnvironment,
//       );

//       // One Three.js world unit represents one metre in the coverage scene.
//       // Use the calculated range directly rather than the old fixed 0.18–2.4 radius.
//       const rangeMeters = metrics.coverageRangeMeters;
//       const radius = Math.max(0.1, rangeMeters) * scaleLobe;

//       const sinTheta = Math.sin(theta);
//       const cosTheta = Math.cos(theta);
//       const sinPhi = Math.sin(phi);
//       const cosPhi = Math.cos(phi);

//       const pIdx = vertexIndex * 3;
//       positions[pIdx] = radius * sinTheta * cosPhi;
//       positions[pIdx + 1] = radius * cosTheta;
//       positions[pIdx + 2] = radius * sinTheta * sinPhi;

//       // Heatmap colors continue to represent the metric selected in the UI.
//       let normVal = 0;
//       switch (heatmapMetric) {
//         case "dbi": {
//           normVal = (sample.gainDbi - minDbi) / Math.max(1, peakDbi - minDbi);
//           break;
//         }
//         case "rssi": {
//           const minRssi = peakMetrics.rssiDbm - 35;
//           normVal = (metrics.rssiDbm - minRssi) / 35;
//           break;
//         }
//         case "snr": {
//           // Preserve the existing -5 dB to +35 dB color window.
//           normVal = (metrics.snrDb + 5) / 40;
//           break;
//         }
//         case "field_strength": {
//           const eField = calculateElectricField(
//             metrics.eirpWatts,
//             evalDistanceMeters,
//           );
//           normVal = eField / Math.max(0.001, peakEField);
//           break;
//         }
//         case "power_density": {
//           const density = calculatePowerDensityUWCm2(
//             metrics.eirpWatts,
//             evalDistanceMeters,
//           );
//           normVal = density / Math.max(0.001, peakPowerDensity);
//           break;
//         }
//       }

//       normVal = Math.max(0, Math.min(1, normVal));
//       const color = getColorFromColormap(normVal, colormap);
//       colors[pIdx] = color.r;
//       colors[pIdx + 1] = color.g;
//       colors[pIdx + 2] = color.b;

//       uvs[vertexIndex * 2] = j / vSegments;
//       uvs[vertexIndex * 2 + 1] = i / uSegments;
//       vertexIndex++;
//     }
//   }

//   // Create triangles.
//   for (let i = 0; i < uSegments; i++) {
//     for (let j = 0; j < vSegments; j++) {
//       const a = i * (vSegments + 1) + j;
//       const b = (i + 1) * (vSegments + 1) + j;
//       const c = (i + 1) * (vSegments + 1) + (j + 1);
//       const d = i * (vSegments + 1) + (j + 1);
//       indices.push(a, b, d);
//       indices.push(b, c, d);
//     }
//   }

//   const geometry = new THREE.BufferGeometry();
//   geometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
//   geometry.setAttribute("color", new THREE.BufferAttribute(colors, 3));
//   geometry.setAttribute("uv", new THREE.BufferAttribute(uvs, 2));
//   geometry.setIndex(indices);
//   geometry.computeVertexNormals();

//   const material = new THREE.MeshStandardMaterial({
//     vertexColors: true,
//     roughness: 0.25,
//     metalness: 0.15,
//     wireframe: config.wireframe,
//     transparent: true,
//     opacity: config.opacity,
//     side: THREE.DoubleSide,
//     depthWrite: false,
//   });

//   const mesh = new THREE.Mesh(geometry, material);
//   mesh.name = `radiation-lobe-${config.id}`;
//   mesh.userData = { configId: config.id, isRadiationLobe: true };
//   return mesh;
// }

// /**
//  * Builds physical 3D antenna representation (brass/copper/dielectric realistic models)
//  */
// export function createPhysicalAntennaMesh(config: AntennaConfig): THREE.Group {
//   const group = new THREE.Group();
//   group.name = `physical-antenna-${config.id}`;

//   const { type, lengthMm, diameterMm } = config;

//   // Normalized scale: map 100mm -> 1.0 unit in 3D scene
//   const lengthScale = Math.max(0.2, Math.min(4.0, lengthMm / 100));
//   const diaScale = Math.max(0.015, Math.min(0.25, diameterMm / 100));

//   // Materials
//   const copperMaterial = new THREE.MeshStandardMaterial({
//     color: 0xcd7f32,
//     metalness: 0.9,
//     roughness: 0.2,
//   });

//   const brassMaterial = new THREE.MeshStandardMaterial({
//     color: 0xd4af37,
//     metalness: 0.85,
//     roughness: 0.25,
//   });

//   const chromeMaterial = new THREE.MeshStandardMaterial({
//     color: 0xdde2ea,
//     metalness: 0.95,
//     roughness: 0.1,
//   });

//   const pcbMaterial = new THREE.MeshStandardMaterial({
//     color: 0x14532d, // dark FR4 green
//     metalness: 0.1,
//     roughness: 0.5,
//   });

//   const feedMaterial = new THREE.MeshStandardMaterial({
//     color: 0x1e293b,
//     metalness: 0.4,
//     roughness: 0.6,
//   });

//   switch (type) {
//     case "dipole": {
//       // Center fed dipole with upper and lower elements along Y axis
//       const armLength = (lengthScale * 0.95) / 2;
//       const radius = Math.max(0.02, diaScale);

//       // Upper arm
//       const upperGeo = new THREE.CylinderGeometry(
//         radius,
//         radius,
//         armLength,
//         16,
//       );
//       const upperMesh = new THREE.Mesh(upperGeo, brassMaterial);
//       upperMesh.position.y = armLength / 2 + 0.04;

//       // Lower arm
//       const lowerGeo = new THREE.CylinderGeometry(
//         radius,
//         radius,
//         armLength,
//         16,
//       );
//       const lowerMesh = new THREE.Mesh(lowerGeo, brassMaterial);
//       lowerMesh.position.y = -armLength / 2 - 0.04;

//       // Center feedpoint insulator / balun
//       const feedGeo = new THREE.CylinderGeometry(
//         radius * 1.6,
//         radius * 1.6,
//         0.08,
//         16,
//       );
//       const feedMesh = new THREE.Mesh(feedGeo, feedMaterial);

//       // Coax feed connector
//       const coaxGeo = new THREE.CylinderGeometry(
//         radius * 0.8,
//         radius * 0.8,
//         0.35,
//         12,
//       );
//       const coaxMesh = new THREE.Mesh(coaxGeo, chromeMaterial);
//       coaxMesh.rotation.z = Math.PI / 2;
//       coaxMesh.position.x = -0.18;

//       group.add(upperMesh, lowerMesh, feedMesh, coaxMesh);
//       break;
//     }

//     case "monopole": {
//       // Quarter-wave whip along +Y over ground plane disc
//       const whipLength = lengthScale * 0.9;
//       const radius = Math.max(0.02, diaScale);

//       // Ground plane disc
//       const groundGeo = new THREE.CylinderGeometry(
//         radius * 8,
//         radius * 8,
//         0.03,
//         32,
//       );
//       const groundMesh = new THREE.Mesh(groundGeo, chromeMaterial);
//       groundMesh.position.y = 0;

//       // Whip element
//       const whipGeo = new THREE.CylinderGeometry(
//         radius * 0.7,
//         radius,
//         whipLength,
//         16,
//       );
//       const whipMesh = new THREE.Mesh(whipGeo, brassMaterial);
//       whipMesh.position.y = whipLength / 2 + 0.02;

//       // SMA base
//       const baseGeo = new THREE.CylinderGeometry(
//         radius * 2,
//         radius * 2,
//         0.1,
//         16,
//       );
//       const baseMesh = new THREE.Mesh(baseGeo, feedMaterial);
//       baseMesh.position.y = -0.05;

//       group.add(groundMesh, whipMesh, baseMesh);
//       break;
//     }

//     case "patch": {
//       // Microstrip patch: FR4 PCB substrate + copper rectangular patch on top facing +X
//       const size = lengthScale * 0.7;
//       const subGeo = new THREE.BoxGeometry(0.04, size * 1.3, size * 1.3);
//       const subMesh = new THREE.Mesh(subGeo, pcbMaterial);

//       const patchGeo = new THREE.BoxGeometry(0.02, size * 0.9, size * 0.9);
//       const patchMesh = new THREE.Mesh(patchGeo, copperMaterial);
//       patchMesh.position.x = 0.025; // on top of substrate facing +X

//       // SMA connector on the back
//       const smaGeo = new THREE.CylinderGeometry(0.04, 0.04, 0.15, 12);
//       const smaMesh = new THREE.Mesh(smaGeo, brassMaterial);
//       smaMesh.rotation.z = Math.PI / 2;
//       smaMesh.position.x = -0.09;

//       group.add(subMesh, patchMesh, smaMesh);
//       break;
//     }

//     case "yagi": {
//       // Boom + Reflector + Driven element + Directors along +X axis
//       const boomLength = lengthScale * 1.5;
//       const boomGeo = new THREE.CylinderGeometry(0.025, 0.025, boomLength, 12);
//       const boomMesh = new THREE.Mesh(boomGeo, chromeMaterial);
//       boomMesh.rotation.z = Math.PI / 2;
//       boomMesh.position.x = boomLength / 2 - 0.2;

//       // Reflector (longest element at rear)
//       const refLen = lengthScale * 0.95;
//       const refGeo = new THREE.CylinderGeometry(0.015, 0.015, refLen, 12);
//       const refMesh = new THREE.Mesh(refGeo, chromeMaterial);
//       refMesh.position.x = -0.15;

//       // Driven element (dipole with feed)
//       const drvLen = lengthScale * 0.85;
//       const drvGeo = new THREE.CylinderGeometry(0.018, 0.018, drvLen, 12);
//       const drvMesh = new THREE.Mesh(drvGeo, brassMaterial);
//       drvMesh.position.x = 0.08;

//       group.add(boomMesh, refMesh, drvMesh);

//       // 4 Directors spaced along +X
//       for (let i = 1; i <= 4; i++) {
//         const dirLen = drvLen * (1 - i * 0.06);
//         const dirGeo = new THREE.CylinderGeometry(0.015, 0.015, dirLen, 12);
//         const dirMesh = new THREE.Mesh(dirGeo, chromeMaterial);
//         dirMesh.position.x = 0.08 + i * (boomLength / 5);
//         group.add(dirMesh);
//       }
//       break;
//     }

//     case "horn": {
//       // Pyramidal flared horn facing +X
//       const hornLength = lengthScale * 0.9;
//       const apertureSize = Math.max(0.4, diaScale * 3);
//       const throatSize = 0.12;

//       // Flared horn pyramid
//       const hornGeo = new THREE.CylinderGeometry(
//         apertureSize,
//         throatSize,
//         hornLength,
//         4,
//         1,
//         true,
//       );
//       const hornMesh = new THREE.Mesh(hornGeo, brassMaterial);
//       hornMesh.rotation.z = -Math.PI / 2;
//       hornMesh.rotation.y = Math.PI / 4;
//       hornMesh.position.x = hornLength / 2;

//       // Waveguide throat & flange
//       const throatGeo = new THREE.CylinderGeometry(
//         throatSize,
//         throatSize,
//         0.2,
//         4,
//       );
//       const throatMesh = new THREE.Mesh(throatGeo, chromeMaterial);
//       throatMesh.rotation.z = -Math.PI / 2;
//       throatMesh.rotation.y = Math.PI / 4;
//       throatMesh.position.x = -0.1;

//       group.add(hornMesh, throatMesh);
//       break;
//     }

//     case "helical": {
//       // Ground reflector disc + helical wire wound along +Z or +Y
//       const groundGeo = new THREE.CylinderGeometry(0.5, 0.5, 0.02, 24);
//       const groundMesh = new THREE.Mesh(groundGeo, chromeMaterial);
//       groundMesh.position.y = -0.1;

//       // Spiral coil curve
//       const turns = 6;
//       const height = lengthScale * 1.1;
//       const coilRadius = Math.max(0.12, diaScale);
//       const curvePoints: THREE.Vector3[] = [];

//       for (let t = 0; t <= 120; t++) {
//         const angle = (t / 120) * (turns * 2 * Math.PI);
//         const cy = (t / 120) * height;
//         const cx = coilRadius * Math.cos(angle);
//         const cz = coilRadius * Math.sin(angle);
//         curvePoints.push(new THREE.Vector3(cx, cy, cz));
//       }

//       const curve = new THREE.CatmullRomCurve3(curvePoints);
//       const tubeGeo = new THREE.TubeGeometry(curve, 90, 0.015, 8, false);
//       const tubeMesh = new THREE.Mesh(tubeGeo, copperMaterial);

//       group.add(groundMesh, tubeMesh);
//       break;
//     }

//     case "isotropic":
//     default: {
//       // Glowing omnidirectional beacon sphere
//       const sphereGeo = new THREE.SphereGeometry(0.12, 24, 24);
//       const sphereMat = new THREE.MeshStandardMaterial({
//         color: 0x38bdf8,
//         emissive: 0x0284c7,
//         emissiveIntensity: 0.6,
//         roughness: 0.2,
//       });
//       const beacon = new THREE.Mesh(sphereGeo, sphereMat);
//       group.add(beacon);
//       break;
//     }
//   }

//   // Anchor ring indicator
//   const ringGeo = new THREE.RingGeometry(0.1, 0.15, 24);
//   const ringMat = new THREE.MeshBasicMaterial({
//     color: new THREE.Color(config.color),
//     side: THREE.DoubleSide,
//     transparent: true,
//     opacity: 0.8,
//   });
//   const ring = new THREE.Mesh(ringGeo, ringMat);
//   ring.rotation.x = Math.PI / 2;
//   ring.position.y = -0.01;
//   group.add(ring);

//   return group;
// }
// import * as THREE from 'three';
// import { AntennaConfig, ColormapType, HeatmapMetric, RFEnvironmentConfig } from '../../types/antenna';
// import { calculateRadiationPattern } from '../../math/radiationPatterns';
// import { getColorFromColormap } from '../../math/colormaps';
// import {
//   mwToDbm,
//   calculateReceivedPowerDbm,
//   calculateElectricField,
//   calculatePowerDensityUWCm2,
//   calculateEIRP,
//   calculateSNR,
// } from '../../math/rfPhysics';

// /**
//  * Builds the 3D Radiation Lobe Mesh with vertex colors corresponding to the radiation heatmap
//  */
// export function createRadiationLobeMesh(
//   config: AntennaConfig,
//   colormap: ColormapType,
//   heatmapMetric: HeatmapMetric,
//   evalDistanceMeters: number,
//   rfEnvironment?: RFEnvironmentConfig
// ): THREE.Mesh {
//   // Discretization: 64 theta steps (polar), 96 phi steps (azimuth)
//   const uSegments = 64; // theta
//   const vSegments = 96; // phi

//   const vertexCount = (uSegments + 1) * (vSegments + 1);
//   const positions = new Float32Array(vertexCount * 3);
//   const colors = new Float32Array(vertexCount * 3);
//   const normals = new Float32Array(vertexCount * 3);
//   const uvs = new Float32Array(vertexCount * 2);
//   const indices: number[] = [];

//   const { gainDbi, powerMilliwatts, frequencyMHz } = config;
//   const { eirpWatts } = calculateEIRP(powerMilliwatts, gainDbi);

//   const weather = rfEnvironment?.weather || 'clear';
//   const bwHz = (rfEnvironment?.bandwidthMHz || 20) * 1e6;
//   const nfDb = rfEnvironment?.noiseFigureDb || 5;

//   // Determine dynamic range for heatmap metric
//   const peakDbi = gainDbi;
//   const minDbi = peakDbi - 30; // 30 dB dynamic range

//   let vertexIndex = 0;

//   for (let i = 0; i <= uSegments; i++) {
//     const u = i / uSegments;
//     const theta = u * Math.PI; // 0 to PI

//     for (let j = 0; j <= vSegments; j++) {
//       const v = j / vSegments;
//       const phi = v * 2 * Math.PI - Math.PI; // -PI to PI

//       // Sample radiation pattern
//       const sample = calculateRadiationPattern(theta, phi, config);

//       const r = sample.radius * (config.scaleLobe || 1.0);
//       const sinT = Math.sin(theta);
//       const cosT = Math.cos(theta);
//       const sinP = Math.sin(phi);
//       const cosP = Math.cos(phi);

//       const px = r * sinT * cosP;
//       const py = r * cosT;
//       const pz = r * sinT * sinP;

//       const pIdx = vertexIndex * 3;
//       positions[pIdx] = px;
//       positions[pIdx + 1] = py;
//       positions[pIdx + 2] = pz;

//       // Calculate normalized value for heatmap coloring
//       let normVal = 0;

//       switch (heatmapMetric) {
//         case 'dbi': {
//           normVal = (sample.gainDbi - minDbi) / Math.max(1, peakDbi - minDbi);
//           break;
//         }
//         case 'rssi': {
//           const { rssiDbm } = calculateReceivedPowerDbm(powerMilliwatts, sample.gainDbi, 0, evalDistanceMeters, frequencyMHz, weather);
//           const maxRssi = mwToDbm(powerMilliwatts) + peakDbi - 40;
//           const minRssi = maxRssi - 35;
//           normVal = (rssiDbm - minRssi) / Math.max(1, maxRssi - minRssi);
//           break;
//         }
//         case 'snr': {
//           const { rssiDbm } = calculateReceivedPowerDbm(powerMilliwatts, sample.gainDbi, 0, evalDistanceMeters, frequencyMHz, weather);
//           const { snrDb } = calculateSNR(rssiDbm, bwHz, nfDb);
//           // Map -5 dB to +35 dB onto [0, 1]
//           normVal = (snrDb - (-5)) / 40;
//           break;
//         }
//         case 'field_strength': {
//           const eField = calculateElectricField(eirpWatts * Math.pow(sample.relativeLinear, 2), evalDistanceMeters);
//           const maxE = calculateElectricField(eirpWatts, evalDistanceMeters);
//           normVal = eField / Math.max(0.001, maxE);
//           break;
//         }
//         case 'power_density': {
//           const s = calculatePowerDensityUWCm2(eirpWatts * Math.pow(sample.relativeLinear, 2), evalDistanceMeters);
//           const maxS = calculatePowerDensityUWCm2(eirpWatts, evalDistanceMeters);
//           normVal = s / Math.max(0.001, maxS);
//           break;
//         }
//       }

//       normVal = Math.max(0, Math.min(1, normVal));
//       const col = getColorFromColormap(normVal, colormap);

//       colors[pIdx] = col.r;
//       colors[pIdx + 1] = col.g;
//       colors[pIdx + 2] = col.b;

//       uvs[vertexIndex * 2] = v;
//       uvs[vertexIndex * 2 + 1] = u;

//       vertexIndex++;
//     }
//   }

//   // Create Triangles
//   for (let i = 0; i < uSegments; i++) {
//     for (let j = 0; j < vSegments; j++) {
//       const a = i * (vSegments + 1) + j;
//       const b = (i + 1) * (vSegments + 1) + j;
//       const c = (i + 1) * (vSegments + 1) + (j + 1);
//       const d = i * (vSegments + 1) + (j + 1);

//       indices.push(a, b, d);
//       indices.push(b, c, d);
//     }
//   }

//   const geometry = new THREE.BufferGeometry();
//   geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
//   geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
//   geometry.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
//   geometry.setIndex(indices);
//   geometry.computeVertexNormals();

//   // Mesh Material
//   const material = new THREE.MeshStandardMaterial({
//     vertexColors: true,
//     roughness: 0.25,
//     metalness: 0.15,
//     wireframe: config.wireframe,
//     transparent: true,
//     opacity: config.opacity,
//     side: THREE.DoubleSide,
//     depthWrite: false, // Prevents Z-fighting in transparent dual lobes
//   });

//   const mesh = new THREE.Mesh(geometry, material);
//   mesh.name = `radiation-lobe-${config.id}`;
//   mesh.userData = { configId: config.id, isRadiationLobe: true };

//   return mesh;
// }

// /**
//  * Builds physical 3D antenna representation (brass/copper/dielectric realistic models)
//  */
// export function createPhysicalAntennaMesh(config: AntennaConfig): THREE.Group {
//   const group = new THREE.Group();
//   group.name = `physical-antenna-${config.id}`;

//   const { type, lengthMm, diameterMm } = config;

//   // Normalized scale: map 100mm -> 1.0 unit in 3D scene
//   const lengthScale = Math.max(0.2, Math.min(4.0, (lengthMm / 100)));
//   const diaScale = Math.max(0.015, Math.min(0.25, (diameterMm / 100)));

//   // Materials
//   const copperMaterial = new THREE.MeshStandardMaterial({
//     color: 0xcd7f32,
//     metalness: 0.9,
//     roughness: 0.2,
//   });

//   const brassMaterial = new THREE.MeshStandardMaterial({
//     color: 0xd4af37,
//     metalness: 0.85,
//     roughness: 0.25,
//   });

//   const chromeMaterial = new THREE.MeshStandardMaterial({
//     color: 0xdde2ea,
//     metalness: 0.95,
//     roughness: 0.1,
//   });

//   const pcbMaterial = new THREE.MeshStandardMaterial({
//     color: 0x14532d, // dark FR4 green
//     metalness: 0.1,
//     roughness: 0.5,
//   });

//   const feedMaterial = new THREE.MeshStandardMaterial({
//     color: 0x1e293b,
//     metalness: 0.4,
//     roughness: 0.6,
//   });

//   switch (type) {
//     case 'dipole': {
//       // Center fed dipole with upper and lower elements along Y axis
//       const armLength = (lengthScale * 0.95) / 2;
//       const radius = Math.max(0.02, diaScale);

//       // Upper arm
//       const upperGeo = new THREE.CylinderGeometry(radius, radius, armLength, 16);
//       const upperMesh = new THREE.Mesh(upperGeo, brassMaterial);
//       upperMesh.position.y = armLength / 2 + 0.04;

//       // Lower arm
//       const lowerGeo = new THREE.CylinderGeometry(radius, radius, armLength, 16);
//       const lowerMesh = new THREE.Mesh(lowerGeo, brassMaterial);
//       lowerMesh.position.y = -armLength / 2 - 0.04;

//       // Center feedpoint insulator / balun
//       const feedGeo = new THREE.CylinderGeometry(radius * 1.6, radius * 1.6, 0.08, 16);
//       const feedMesh = new THREE.Mesh(feedGeo, feedMaterial);

//       // Coax feed connector
//       const coaxGeo = new THREE.CylinderGeometry(radius * 0.8, radius * 0.8, 0.35, 12);
//       const coaxMesh = new THREE.Mesh(coaxGeo, chromeMaterial);
//       coaxMesh.rotation.z = Math.PI / 2;
//       coaxMesh.position.x = -0.18;

//       group.add(upperMesh, lowerMesh, feedMesh, coaxMesh);
//       break;
//     }

//     case 'monopole': {
//       // Quarter-wave whip along +Y over ground plane disc
//       const whipLength = lengthScale * 0.9;
//       const radius = Math.max(0.02, diaScale);

//       // Ground plane disc
//       const groundGeo = new THREE.CylinderGeometry(radius * 8, radius * 8, 0.03, 32);
//       const groundMesh = new THREE.Mesh(groundGeo, chromeMaterial);
//       groundMesh.position.y = 0;

//       // Whip element
//       const whipGeo = new THREE.CylinderGeometry(radius * 0.7, radius, whipLength, 16);
//       const whipMesh = new THREE.Mesh(whipGeo, brassMaterial);
//       whipMesh.position.y = whipLength / 2 + 0.02;

//       // SMA base
//       const baseGeo = new THREE.CylinderGeometry(radius * 2, radius * 2, 0.1, 16);
//       const baseMesh = new THREE.Mesh(baseGeo, feedMaterial);
//       baseMesh.position.y = -0.05;

//       group.add(groundMesh, whipMesh, baseMesh);
//       break;
//     }

//     case 'patch': {
//       // Microstrip patch: FR4 PCB substrate + copper rectangular patch on top facing +X
//       const size = lengthScale * 0.7;
//       const subGeo = new THREE.BoxGeometry(0.04, size * 1.3, size * 1.3);
//       const subMesh = new THREE.Mesh(subGeo, pcbMaterial);

//       const patchGeo = new THREE.BoxGeometry(0.02, size * 0.9, size * 0.9);
//       const patchMesh = new THREE.Mesh(patchGeo, copperMaterial);
//       patchMesh.position.x = 0.025; // on top of substrate facing +X

//       // SMA connector on the back
//       const smaGeo = new THREE.CylinderGeometry(0.04, 0.04, 0.15, 12);
//       const smaMesh = new THREE.Mesh(smaGeo, brassMaterial);
//       smaMesh.rotation.z = Math.PI / 2;
//       smaMesh.position.x = -0.09;

//       group.add(subMesh, patchMesh, smaMesh);
//       break;
//     }

//     case 'yagi': {
//       // Boom + Reflector + Driven element + Directors along +X axis
//       const boomLength = lengthScale * 1.5;
//       const boomGeo = new THREE.CylinderGeometry(0.025, 0.025, boomLength, 12);
//       const boomMesh = new THREE.Mesh(boomGeo, chromeMaterial);
//       boomMesh.rotation.z = Math.PI / 2;
//       boomMesh.position.x = boomLength / 2 - 0.2;

//       // Reflector (longest element at rear)
//       const refLen = lengthScale * 0.95;
//       const refGeo = new THREE.CylinderGeometry(0.015, 0.015, refLen, 12);
//       const refMesh = new THREE.Mesh(refGeo, chromeMaterial);
//       refMesh.position.x = -0.15;

//       // Driven element (dipole with feed)
//       const drvLen = lengthScale * 0.85;
//       const drvGeo = new THREE.CylinderGeometry(0.018, 0.018, drvLen, 12);
//       const drvMesh = new THREE.Mesh(drvGeo, brassMaterial);
//       drvMesh.position.x = 0.08;

//       group.add(boomMesh, refMesh, drvMesh);

//       // 4 Directors spaced along +X
//       for (let i = 1; i <= 4; i++) {
//         const dirLen = drvLen * (1 - i * 0.06);
//         const dirGeo = new THREE.CylinderGeometry(0.015, 0.015, dirLen, 12);
//         const dirMesh = new THREE.Mesh(dirGeo, chromeMaterial);
//         dirMesh.position.x = 0.08 + i * (boomLength / 5);
//         group.add(dirMesh);
//       }
//       break;
//     }

//     case 'horn': {
//       // Pyramidal flared horn facing +X
//       const hornLength = lengthScale * 0.9;
//       const apertureSize = Math.max(0.4, diaScale * 3);
//       const throatSize = 0.12;

//       // Flared horn pyramid
//       const hornGeo = new THREE.CylinderGeometry(apertureSize, throatSize, hornLength, 4, 1, true);
//       const hornMesh = new THREE.Mesh(hornGeo, brassMaterial);
//       hornMesh.rotation.z = -Math.PI / 2;
//       hornMesh.rotation.y = Math.PI / 4;
//       hornMesh.position.x = hornLength / 2;

//       // Waveguide throat & flange
//       const throatGeo = new THREE.CylinderGeometry(throatSize, throatSize, 0.2, 4);
//       const throatMesh = new THREE.Mesh(throatGeo, chromeMaterial);
//       throatMesh.rotation.z = -Math.PI / 2;
//       throatMesh.rotation.y = Math.PI / 4;
//       throatMesh.position.x = -0.1;

//       group.add(hornMesh, throatMesh);
//       break;
//     }

//     case 'helical': {
//       // Ground reflector disc + helical wire wound along +Z or +Y
//       const groundGeo = new THREE.CylinderGeometry(0.5, 0.5, 0.02, 24);
//       const groundMesh = new THREE.Mesh(groundGeo, chromeMaterial);
//       groundMesh.position.y = -0.1;

//       // Spiral coil curve
//       const turns = 6;
//       const height = lengthScale * 1.1;
//       const coilRadius = Math.max(0.12, diaScale);
//       const curvePoints: THREE.Vector3[] = [];

//       for (let t = 0; t <= 120; t++) {
//         const angle = (t / 120) * (turns * 2 * Math.PI);
//         const cy = (t / 120) * height;
//         const cx = coilRadius * Math.cos(angle);
//         const cz = coilRadius * Math.sin(angle);
//         curvePoints.push(new THREE.Vector3(cx, cy, cz));
//       }

//       const curve = new THREE.CatmullRomCurve3(curvePoints);
//       const tubeGeo = new THREE.TubeGeometry(curve, 90, 0.015, 8, false);
//       const tubeMesh = new THREE.Mesh(tubeGeo, copperMaterial);

//       group.add(groundMesh, tubeMesh);
//       break;
//     }

//     case 'isotropic':
//     default: {
//       // Glowing omnidirectional beacon sphere
//       const sphereGeo = new THREE.SphereGeometry(0.12, 24, 24);
//       const sphereMat = new THREE.MeshStandardMaterial({
//         color: 0x38bdf8,
//         emissive: 0x0284c7,
//         emissiveIntensity: 0.6,
//         roughness: 0.2,
//       });
//       const beacon = new THREE.Mesh(sphereGeo, sphereMat);
//       group.add(beacon);
//       break;
//     }
//   }

//   // Anchor ring indicator
//   const ringGeo = new THREE.RingGeometry(0.1, 0.15, 24);
//   const ringMat = new THREE.MeshBasicMaterial({
//     color: new THREE.Color(config.color),
//     side: THREE.DoubleSide,
//     transparent: true,
//     opacity: 0.8,
//   });
//   const ring = new THREE.Mesh(ringGeo, ringMat);
//   ring.rotation.x = Math.PI / 2;
//   ring.position.y = -0.01;
//   group.add(ring);

//   return group;
// }
import * as THREE from "three";
import {
  AntennaConfig,
  ColormapType,
  HeatmapMetric,
  RFEnvironmentConfig,
} from "../../types/antenna";
import { calculateRadiationPattern } from "../../math/radiationPatterns";
import { getColorFromColormap } from "../../math/colormaps";
import {
  calculateElectricField,
  calculatePowerDensityUWCm2,
} from "../../math/rfPhysics";
import { calculateDirectionalCoverageMetrics } from "../../math/directionalCoverage";

/**
 * Builds a potential-coverage envelope: directional antenna gain controls
 * the shape and the modeled TX/RX link budget controls its radius. This is
 * intentionally distinct from a pure normalized radiation-pattern plot.
 */
export function createRadiationLobeMesh(
  config: AntennaConfig,
  peerConfig: AntennaConfig,
  rxSensitivityDbm: number,
  colormap: ColormapType,
  heatmapMetric: HeatmapMetric,
  evalDistanceMeters: number,
  rfEnvironment?: RFEnvironmentConfig,
): THREE.Mesh {
  // Keep the existing mesh resolution and visual quality.
  const uSegments = 64; // theta
  const vSegments = 96; // phi

  const vertexCount = (uSegments + 1) * (vSegments + 1);
  const positions = new Float32Array(vertexCount * 3);
  const colors = new Float32Array(vertexCount * 3);
  const uvs = new Float32Array(vertexCount * 2);
  const indices: number[] = [];

  // The configured gainDbi is the peak of the normalized pattern model.
  const peakDbi = config.gainDbi;
  const minDbi = peakDbi - 30; // Keep the existing 30 dB gain-color range.
  const peakMetrics = calculateDirectionalCoverageMetrics(
    config,
    peerConfig,
    peakDbi,
    evalDistanceMeters,
    rxSensitivityDbm,
    rfEnvironment,
  );
  const peakPowerAtDistance =
    peakMetrics.eirpWatts * 10 ** (-peakMetrics.atmosphericLossDb / 10);
  const peakEField = calculateElectricField(
    peakPowerAtDistance,
    evalDistanceMeters,
  );
  const peakPowerDensity = calculatePowerDensityUWCm2(
    peakPowerAtDistance,
    evalDistanceMeters,
  );

  const scaleLobe = Math.max(0.01, config.scaleLobe || 1);
  let vertexIndex = 0;

  for (let i = 0; i <= uSegments; i++) {
    const theta = (i / uSegments) * Math.PI;

    for (let j = 0; j <= vSegments; j++) {
      const phi = (j / vSegments) * 2 * Math.PI - Math.PI;
      const sample = calculateRadiationPattern(theta, phi, config);

      // A TX lobe uses directional TX gain. An RX lobe uses the reciprocal
      // directional RX gain. The partner is assumed optimally aligned at peak
      // gain, so this is a potential-coverage envelope, not the live link SNR.
      const metrics = calculateDirectionalCoverageMetrics(
        config,
        peerConfig,
        sample.gainDbi,
        evalDistanceMeters,
        rxSensitivityDbm,
        rfEnvironment,
      );

      // One Three.js world unit represents one metre in the coverage scene.
      // Zero means no valid coverage; do not draw a fabricated 0.1 m lobe.
      const rangeMeters = metrics.coverageRangeMeters;
      const radius = Math.max(0, rangeMeters) * scaleLobe;

      const sinTheta = Math.sin(theta);
      const cosTheta = Math.cos(theta);
      const sinPhi = Math.sin(phi);
      const cosPhi = Math.cos(phi);

      const pIdx = vertexIndex * 3;
      positions[pIdx] = radius * sinTheta * cosPhi;
      positions[pIdx + 1] = radius * cosTheta;
      positions[pIdx + 2] = radius * sinTheta * sinPhi;

      // Heatmap colors continue to represent the metric selected in the UI.
      let normVal = 0;
      switch (heatmapMetric) {
        case "dbi": {
          normVal = (sample.gainDbi - minDbi) / Math.max(1, peakDbi - minDbi);
          break;
        }
        case "rssi": {
          const minRssi = peakMetrics.rssiDbm - 35;
          normVal = (metrics.rssiDbm - minRssi) / 35;
          break;
        }
        case "snr": {
          // Preserve the existing -5 dB to +35 dB color window.
          normVal = (metrics.snrDb + 5) / 40;
          break;
        }
        case "field_strength": {
          const receivedPowerWatts =
            metrics.eirpWatts * 10 ** (-metrics.atmosphericLossDb / 10);
          const eField = calculateElectricField(
            receivedPowerWatts,
            evalDistanceMeters,
          );
          normVal = eField / Math.max(0.001, peakEField);
          break;
        }
        case "power_density": {
          const receivedPowerWatts =
            metrics.eirpWatts * 10 ** (-metrics.atmosphericLossDb / 10);
          const density = calculatePowerDensityUWCm2(
            receivedPowerWatts,
            evalDistanceMeters,
          );
          normVal = density / Math.max(0.001, peakPowerDensity);
          break;
        }
      }

      normVal = Number.isFinite(normVal)
        ? Math.max(0, Math.min(1, normVal))
        : 0;
      const color = getColorFromColormap(normVal, colormap);
      colors[pIdx] = color.r;
      colors[pIdx + 1] = color.g;
      colors[pIdx + 2] = color.b;

      uvs[vertexIndex * 2] = j / vSegments;
      uvs[vertexIndex * 2 + 1] = i / uSegments;
      vertexIndex++;
    }
  }

  // Create triangles.
  for (let i = 0; i < uSegments; i++) {
    for (let j = 0; j < vSegments; j++) {
      const a = i * (vSegments + 1) + j;
      const b = (i + 1) * (vSegments + 1) + j;
      const c = (i + 1) * (vSegments + 1) + (j + 1);
      const d = i * (vSegments + 1) + (j + 1);
      indices.push(a, b, d);
      indices.push(b, c, d);
    }
  }

  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
  geometry.setAttribute("color", new THREE.BufferAttribute(colors, 3));
  geometry.setAttribute("uv", new THREE.BufferAttribute(uvs, 2));
  geometry.setIndex(indices);
  geometry.computeVertexNormals();

  const material = new THREE.MeshStandardMaterial({
    vertexColors: true,
    roughness: 0.25,
    metalness: 0.15,
    wireframe: config.wireframe,
    transparent: true,
    opacity: config.opacity,
    side: THREE.DoubleSide,
    depthWrite: false,
  });

  const mesh = new THREE.Mesh(geometry, material);
  mesh.name = `radiation-lobe-${config.id}`;
  mesh.userData = { configId: config.id, isRadiationLobe: true };
  return mesh;
}

/**
 * Builds physical 3D antenna representation (brass/copper/dielectric realistic models)
 */
export function createPhysicalAntennaMesh(config: AntennaConfig): THREE.Group {
  const group = new THREE.Group();
  group.name = `physical-antenna-${config.id}`;

  const { type, lengthMm, diameterMm } = config;

  // Normalized scale: map 100mm -> 1.0 unit in 3D scene
  const lengthScale = Math.max(0.2, Math.min(4.0, lengthMm / 100));
  const diaScale = Math.max(0.015, Math.min(0.25, diameterMm / 100));

  // Materials
  const copperMaterial = new THREE.MeshStandardMaterial({
    color: 0xcd7f32,
    metalness: 0.9,
    roughness: 0.2,
  });

  const brassMaterial = new THREE.MeshStandardMaterial({
    color: 0xd4af37,
    metalness: 0.85,
    roughness: 0.25,
  });

  const chromeMaterial = new THREE.MeshStandardMaterial({
    color: 0xdde2ea,
    metalness: 0.95,
    roughness: 0.1,
  });

  const pcbMaterial = new THREE.MeshStandardMaterial({
    color: 0x14532d, // dark FR4 green
    metalness: 0.1,
    roughness: 0.5,
  });

  const feedMaterial = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    metalness: 0.4,
    roughness: 0.6,
  });

  switch (type) {
    case "dipole": {
      // Center fed dipole with upper and lower elements along Y axis
      const armLength = (lengthScale * 0.95) / 2;
      const radius = Math.max(0.02, diaScale);

      // Upper arm
      const upperGeo = new THREE.CylinderGeometry(
        radius,
        radius,
        armLength,
        16,
      );
      const upperMesh = new THREE.Mesh(upperGeo, brassMaterial);
      upperMesh.position.y = armLength / 2 + 0.04;

      // Lower arm
      const lowerGeo = new THREE.CylinderGeometry(
        radius,
        radius,
        armLength,
        16,
      );
      const lowerMesh = new THREE.Mesh(lowerGeo, brassMaterial);
      lowerMesh.position.y = -armLength / 2 - 0.04;

      // Center feedpoint insulator / balun
      const feedGeo = new THREE.CylinderGeometry(
        radius * 1.6,
        radius * 1.6,
        0.08,
        16,
      );
      const feedMesh = new THREE.Mesh(feedGeo, feedMaterial);

      // Coax feed connector
      const coaxGeo = new THREE.CylinderGeometry(
        radius * 0.8,
        radius * 0.8,
        0.35,
        12,
      );
      const coaxMesh = new THREE.Mesh(coaxGeo, chromeMaterial);
      coaxMesh.rotation.z = Math.PI / 2;
      coaxMesh.position.x = -0.18;

      group.add(upperMesh, lowerMesh, feedMesh, coaxMesh);
      break;
    }

    case "monopole": {
      // Quarter-wave whip along +Y over ground plane disc
      const whipLength = lengthScale * 0.9;
      const radius = Math.max(0.02, diaScale);

      // Ground plane disc
      const groundGeo = new THREE.CylinderGeometry(
        radius * 8,
        radius * 8,
        0.03,
        32,
      );
      const groundMesh = new THREE.Mesh(groundGeo, chromeMaterial);
      groundMesh.position.y = 0;

      // Whip element
      const whipGeo = new THREE.CylinderGeometry(
        radius * 0.7,
        radius,
        whipLength,
        16,
      );
      const whipMesh = new THREE.Mesh(whipGeo, brassMaterial);
      whipMesh.position.y = whipLength / 2 + 0.02;

      // SMA base
      const baseGeo = new THREE.CylinderGeometry(
        radius * 2,
        radius * 2,
        0.1,
        16,
      );
      const baseMesh = new THREE.Mesh(baseGeo, feedMaterial);
      baseMesh.position.y = -0.05;

      group.add(groundMesh, whipMesh, baseMesh);
      break;
    }

    case "patch": {
      // Microstrip patch: FR4 PCB substrate + copper rectangular patch on top facing +X
      const size = lengthScale * 0.7;
      const subGeo = new THREE.BoxGeometry(0.04, size * 1.3, size * 1.3);
      const subMesh = new THREE.Mesh(subGeo, pcbMaterial);

      const patchGeo = new THREE.BoxGeometry(0.02, size * 0.9, size * 0.9);
      const patchMesh = new THREE.Mesh(patchGeo, copperMaterial);
      patchMesh.position.x = 0.025; // on top of substrate facing +X

      // SMA connector on the back
      const smaGeo = new THREE.CylinderGeometry(0.04, 0.04, 0.15, 12);
      const smaMesh = new THREE.Mesh(smaGeo, brassMaterial);
      smaMesh.rotation.z = Math.PI / 2;
      smaMesh.position.x = -0.09;

      group.add(subMesh, patchMesh, smaMesh);
      break;
    }

    case "yagi": {
      // Boom + Reflector + Driven element + Directors along +X axis
      const boomLength = lengthScale * 1.5;
      const boomGeo = new THREE.CylinderGeometry(0.025, 0.025, boomLength, 12);
      const boomMesh = new THREE.Mesh(boomGeo, chromeMaterial);
      boomMesh.rotation.z = Math.PI / 2;
      boomMesh.position.x = boomLength / 2 - 0.2;

      // Reflector (longest element at rear)
      const refLen = lengthScale * 0.95;
      const refGeo = new THREE.CylinderGeometry(0.015, 0.015, refLen, 12);
      const refMesh = new THREE.Mesh(refGeo, chromeMaterial);
      refMesh.position.x = -0.15;

      // Driven element (dipole with feed)
      const drvLen = lengthScale * 0.85;
      const drvGeo = new THREE.CylinderGeometry(0.018, 0.018, drvLen, 12);
      const drvMesh = new THREE.Mesh(drvGeo, brassMaterial);
      drvMesh.position.x = 0.08;

      group.add(boomMesh, refMesh, drvMesh);

      // 4 Directors spaced along +X
      for (let i = 1; i <= 4; i++) {
        const dirLen = drvLen * (1 - i * 0.06);
        const dirGeo = new THREE.CylinderGeometry(0.015, 0.015, dirLen, 12);
        const dirMesh = new THREE.Mesh(dirGeo, chromeMaterial);
        dirMesh.position.x = 0.08 + i * (boomLength / 5);
        group.add(dirMesh);
      }
      break;
    }

    case "horn": {
      // Pyramidal flared horn facing +X
      const hornLength = lengthScale * 0.9;
      const apertureSize = Math.max(0.4, diaScale * 3);
      const throatSize = 0.12;

      // Flared horn pyramid
      const hornGeo = new THREE.CylinderGeometry(
        apertureSize,
        throatSize,
        hornLength,
        4,
        1,
        true,
      );
      const hornMesh = new THREE.Mesh(hornGeo, brassMaterial);
      hornMesh.rotation.z = -Math.PI / 2;
      hornMesh.rotation.y = Math.PI / 4;
      hornMesh.position.x = hornLength / 2;

      // Waveguide throat & flange
      const throatGeo = new THREE.CylinderGeometry(
        throatSize,
        throatSize,
        0.2,
        4,
      );
      const throatMesh = new THREE.Mesh(throatGeo, chromeMaterial);
      throatMesh.rotation.z = -Math.PI / 2;
      throatMesh.rotation.y = Math.PI / 4;
      throatMesh.position.x = -0.1;

      group.add(hornMesh, throatMesh);
      break;
    }

    case "helical": {
      // Ground reflector disc + helical wire wound along +Z or +Y
      const groundGeo = new THREE.CylinderGeometry(0.5, 0.5, 0.02, 24);
      const groundMesh = new THREE.Mesh(groundGeo, chromeMaterial);
      groundMesh.position.y = -0.1;

      // Spiral coil curve
      const turns = 6;
      const height = lengthScale * 1.1;
      const coilRadius = Math.max(0.12, diaScale);
      const curvePoints: THREE.Vector3[] = [];

      for (let t = 0; t <= 120; t++) {
        const angle = (t / 120) * (turns * 2 * Math.PI);
        const cy = (t / 120) * height;
        const cx = coilRadius * Math.cos(angle);
        const cz = coilRadius * Math.sin(angle);
        curvePoints.push(new THREE.Vector3(cx, cy, cz));
      }

      const curve = new THREE.CatmullRomCurve3(curvePoints);
      const tubeGeo = new THREE.TubeGeometry(curve, 90, 0.015, 8, false);
      const tubeMesh = new THREE.Mesh(tubeGeo, copperMaterial);

      group.add(groundMesh, tubeMesh);
      break;
    }

    case "isotropic":
    default: {
      // Glowing omnidirectional beacon sphere
      const sphereGeo = new THREE.SphereGeometry(0.12, 24, 24);
      const sphereMat = new THREE.MeshStandardMaterial({
        color: 0x38bdf8,
        emissive: 0x0284c7,
        emissiveIntensity: 0.6,
        roughness: 0.2,
      });
      const beacon = new THREE.Mesh(sphereGeo, sphereMat);
      group.add(beacon);
      break;
    }
  }

  // Anchor ring indicator
  const ringGeo = new THREE.RingGeometry(0.1, 0.15, 24);
  const ringMat = new THREE.MeshBasicMaterial({
    color: new THREE.Color(config.color),
    side: THREE.DoubleSide,
    transparent: true,
    opacity: 0.8,
  });
  const ring = new THREE.Mesh(ringGeo, ringMat);
  ring.rotation.x = Math.PI / 2;
  ring.position.y = -0.01;
  group.add(ring);

  return group;
}
