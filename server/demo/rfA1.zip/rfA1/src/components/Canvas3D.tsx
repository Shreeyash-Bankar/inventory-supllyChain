// import React, { useEffect, useRef } from "react";
// import * as THREE from "three";
// import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
// import { TransformControls } from "three/examples/jsm/controls/TransformControls.js";
// import { useAntennaStore } from "../store/antennaStore";
// import {
//   createRadiationLobeMesh,
//   createPhysicalAntennaMesh,
// } from "./3d/antennaGeometry";
// import { calculateRadiationPattern } from "../math/radiationPatterns";
// import {
//   calculateReceivedPowerDbm,
//   calculateEIRP,
//   calculateElectricField,
//   calculatePowerDensityUWCm2,
//   calculateMaxCoverageRange,
//   calculateSNR,
// } from "../math/rfPhysics";
// import { HoverInspectionData } from "../types/antenna";

// export const Canvas3D: React.FC = () => {
//   const mountRef = useRef<HTMLDivElement>(null);

//   // Store subscriptions
//   const antenna1 = useAntennaStore((s) => s.antenna1);
//   const antenna2 = useAntennaStore((s) => s.antenna2);
//   const selectedAntennaId = useAntennaStore((s) => s.selectedAntennaId);
//   const setSelectedAntennaId = useAntennaStore((s) => s.setSelectedAntennaId);
//   const gizmoMode = useAntennaStore((s) => s.gizmoMode);
//   const viewMode = useAntennaStore((s) => s.viewMode);
//   const colormap = useAntennaStore((s) => s.colormap);
//   const heatmapMetric = useAntennaStore((s) => s.heatmapMetric);
//   const evalDistanceMeters = useAntennaStore((s) => s.evalDistanceMeters);
//   const rxSensitivityDbm = useAntennaStore((s) => s.rxSensitivityDbm);
//   const showGroundPlane = useAntennaStore((s) => s.showGroundPlane);
//   const showDistanceRings = useAntennaStore((s) => s.showDistanceRings);
//   const showAxes = useAntennaStore((s) => s.showAxes);
//   const autoRotate = useAntennaStore((s) => s.autoRotate);
//   const polarCutMode = useAntennaStore((s) => s.polarCutMode);
//   const linkDistanceMeters = useAntennaStore((s) => s.linkDistanceMeters);
//   const rfEnvironment = useAntennaStore((s) => s.rfEnvironment);
//   const hoverData = useAntennaStore((s) => s.hoverData);
//   const setHoverData = useAntennaStore((s) => s.setHoverData);
//   const isInspectionPinned = useAntennaStore((s) => s.isInspectionPinned);
//   const setIsInspectionPinned = useAntennaStore((s) => s.setIsInspectionPinned);
//   const isHoveringTooltip = useAntennaStore((s) => s.isHoveringTooltip);

//   // Three.js runtime references
//   const sceneRef = useRef<THREE.Scene | null>(null);
//   const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
//   const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
//   const controlsRef = useRef<OrbitControls | null>(null);
//   const transformControlsRef = useRef<TransformControls | null>(null);

//   // Object groups
//   const ant1GroupRef = useRef<THREE.Group>(new THREE.Group());
//   const ant2GroupRef = useRef<THREE.Group>(new THREE.Group());
//   const visualHelpersGroupRef = useRef<THREE.Group>(new THREE.Group());
//   const linkLineRef = useRef<THREE.Line | null>(null);

//   // Probe / Hover interactive visuals
//   const probeMarkerRef = useRef<THREE.Mesh | null>(null);
//   const probeRayLineRef = useRef<THREE.Line | null>(null);
//   const raycasterRef = useRef<THREE.Raycaster>(new THREE.Raycaster());
//   const pointerRef = useRef<THREE.Vector2>(new THREE.Vector2(-999, -999));
//   const activeLobeMeshesRef = useRef<THREE.Mesh[]>([]);

//   // 1. Initialize Scene, Camera, Renderer, Controls & TransformControls
//   useEffect(() => {
//     if (!mountRef.current) return;
//     const container = mountRef.current;
//     const width = container.clientWidth;
//     const height = container.clientHeight;

//     // Scene
//     const scene = new THREE.Scene();
//     scene.background = new THREE.Color(0x070b14);
//     scene.fog = new THREE.FogExp2(0x070b14, 0.001);
//     sceneRef.current = scene;

//     // Camera
//     const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
//     camera.position.set(0, 5, 11);
//     cameraRef.current = camera;

//     // Renderer
//     const renderer = new THREE.WebGLRenderer({
//       antialias: true,
//       alpha: true,
//       powerPreference: "high-performance",
//     });
//     renderer.setSize(width, height);
//     renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
//     renderer.toneMapping = THREE.ACESFilmicToneMapping;
//     renderer.toneMappingExposure = 1.1;
//     container.appendChild(renderer.domElement);
//     rendererRef.current = renderer;

//     // OrbitControls
//     const controls = new OrbitControls(camera, renderer.domElement);
//     controls.enableDamping = true;
//     controls.dampingFactor = 0.05;
//     controls.maxPolarAngle = Math.PI / 2 + 0.15; // Allow viewing slightly from below horizon
//     controls.minDistance = 1.0;
//     controls.maxDistance = 600.0;
//     controlsRef.current = controls;

//     // TransformControls for interactive 3D translation & rotation gizmos
//     const transformControls = new TransformControls(
//       camera,
//       renderer.domElement,
//     );
//     transformControls.size = 0.75;
//     transformControls.addEventListener("dragging-changed", (event) => {
//       controls.enabled = !event.value;
//     });

//     transformControls.addEventListener("objectChange", () => {
//       const target = transformControls.object;
//       if (!target) return;
//       const isAnt1 = target === ant1GroupRef.current;

//       const newPos: [number, number, number] = [
//         Math.round(target.position.x * 100) / 100,
//         Math.round(target.position.y * 100) / 100,
//         Math.round(target.position.z * 100) / 100,
//       ];

//       const newRot: [number, number, number] = [
//         Math.round(THREE.MathUtils.radToDeg(target.rotation.x) * 10) / 10,
//         Math.round(THREE.MathUtils.radToDeg(target.rotation.y) * 10) / 10,
//         Math.round(THREE.MathUtils.radToDeg(target.rotation.z) * 10) / 10,
//       ];

//       if (isAnt1) {
//         useAntennaStore
//           .getState()
//           .updateAntenna1({ position: newPos, rotation: newRot });
//       } else {
//         useAntennaStore
//           .getState()
//           .updateAntenna2({ position: newPos, rotation: newRot });
//       }
//     });

//     scene.add(transformControls.getHelper());
//     transformControlsRef.current = transformControls;

//     // Lighting
//     const ambientLight = new THREE.AmbientLight(0xffffff, 0.65);
//     scene.add(ambientLight);

//     const dirLight1 = new THREE.DirectionalLight(0xffffff, 1.2);
//     dirLight1.position.set(10, 15, 10);
//     scene.add(dirLight1);

//     const dirLight2 = new THREE.DirectionalLight(0x38bdf8, 0.5);
//     dirLight2.position.set(-10, -5, -10);
//     scene.add(dirLight2);

//     // Add containers for antennas and helpers
//     scene.add(ant1GroupRef.current);
//     scene.add(ant2GroupRef.current);
//     scene.add(visualHelpersGroupRef.current);

//     // Create Hover Probe indicator objects
//     const markerGeo = new THREE.SphereGeometry(0.08, 16, 16);
//     const markerMat = new THREE.MeshBasicMaterial({
//       color: 0xffff00,
//       wireframe: true,
//     });
//     const probeMarker = new THREE.Mesh(markerGeo, markerMat);
//     probeMarker.visible = false;
//     scene.add(probeMarker);
//     probeMarkerRef.current = probeMarker;

//     const lineMat = new THREE.LineDashedMaterial({
//       color: 0x38bdf8,
//       dashSize: 0.1,
//       gapSize: 0.05,
//       linewidth: 2,
//     });
//     const lineGeo = new THREE.BufferGeometry().setFromPoints([
//       new THREE.Vector3(0, 0, 0),
//       new THREE.Vector3(0, 0, 0),
//     ]);
//     const probeLine = new THREE.Line(lineGeo, lineMat);
//     probeLine.computeLineDistances();
//     probeLine.visible = false;
//     scene.add(probeLine);
//     probeRayLineRef.current = probeLine;

//     // Animation Loop
//     let animationFrameId: number;
//     const animate = () => {
//       animationFrameId = requestAnimationFrame(animate);
//       if (controlsRef.current) {
//         controlsRef.current.autoRotate = autoRotate;
//         controlsRef.current.autoRotateSpeed = 1.0;
//         controlsRef.current.update();
//       }
//       renderer.render(scene, camera);
//     };
//     animate();

//     // Window Resize Handler
//     const handleResize = () => {
//       if (!mountRef.current || !rendererRef.current || !cameraRef.current)
//         return;
//       const w = mountRef.current.clientWidth;
//       const h = mountRef.current.clientHeight;
//       cameraRef.current.aspect = w / h;
//       cameraRef.current.updateProjectionMatrix();
//       rendererRef.current.setSize(w, h);
//     };
//     window.addEventListener("resize", handleResize);

//     return () => {
//       window.removeEventListener("resize", handleResize);
//       cancelAnimationFrame(animationFrameId);
//       transformControls.dispose();
//       controls.dispose();
//       renderer.dispose();
//       if (container.contains(renderer.domElement)) {
//         container.removeChild(renderer.domElement);
//       }
//     };
//   }, []);

//   // 2. Update Environment Visual Helpers (Grid, Rings, Axes, Polar Planes)
//   useEffect(() => {
//     const group = visualHelpersGroupRef.current;
//     while (group.children.length > 0) {
//       group.remove(group.children[0]);
//     }

//     // Ground Plane Grid
//     if (showGroundPlane) {
//       const grid = new THREE.GridHelper(24, 24, 0x1e293b, 0x0f172a);
//       grid.position.y = -0.01;
//       group.add(grid);
//     }

//     // Distance Rings (Radar-style concentric range rings at 1m, 2m, 3m, 4m, 5m scale)
//     if (showDistanceRings) {
//       const ringDistances = [1.0, 2.0, 3.0, 4.0, 5.0];
//       ringDistances.forEach((dist) => {
//         const ringGeo = new THREE.RingGeometry(dist - 0.015, dist + 0.015, 64);
//         const ringMat = new THREE.MeshBasicMaterial({
//           color: 0x334155,
//           side: THREE.DoubleSide,
//           transparent: true,
//           opacity: 0.35,
//         });
//         const ringMesh = new THREE.Mesh(ringGeo, ringMat);
//         ringMesh.rotation.x = Math.PI / 2;
//         ringMesh.position.y = 0.005;
//         group.add(ringMesh);
//       });
//     }

//     // Axes Helper
//     if (showAxes) {
//       const axesHelper = new THREE.AxesHelper(2.5);
//       group.add(axesHelper);
//     }

//     // Polar Cut Planes (Elevation or Azimuth)
//     if (polarCutMode === "e-plane") {
//       const planeGeo = new THREE.PlaneGeometry(6, 6);
//       const planeMat = new THREE.MeshBasicMaterial({
//         color: 0x38bdf8,
//         transparent: true,
//         opacity: 0.12,
//         side: THREE.DoubleSide,
//         wireframe: false,
//       });
//       const planeMesh = new THREE.Mesh(planeGeo, planeMat);
//       planeMesh.position.y = 0;
//       group.add(planeMesh);

//       const wire = new THREE.LineSegments(
//         new THREE.WireframeGeometry(planeGeo),
//         new THREE.LineBasicMaterial({
//           color: 0x38bdf8,
//           transparent: true,
//           opacity: 0.3,
//         }),
//       );
//       wire.position.y = 0;
//       group.add(wire);
//     } else if (polarCutMode === "h-plane") {
//       const planeGeo = new THREE.PlaneGeometry(6, 6);
//       const planeMat = new THREE.MeshBasicMaterial({
//         color: 0x10b981,
//         transparent: true,
//         opacity: 0.12,
//         side: THREE.DoubleSide,
//       });
//       const planeMesh = new THREE.Mesh(planeGeo, planeMat);
//       planeMesh.rotation.x = Math.PI / 2;
//       group.add(planeMesh);
//     }
//   }, [showGroundPlane, showDistanceRings, showAxes, polarCutMode]);

//   // 3. Rebuild Antenna 1 & Antenna 2 Meshes and Apply 3D Spatial Transforms
//   useEffect(() => {
//     const g1 = ant1GroupRef.current;
//     const g2 = ant2GroupRef.current;

//     // Clear existing children
//     while (g1.children.length > 0) g1.remove(g1.children[0]);
//     while (g2.children.length > 0) g2.remove(g2.children[0]);
//     activeLobeMeshesRef.current = [];

//     // Apply Position and Rotation on any axis from store
//     g1.position.set(
//       antenna1.position[0],
//       antenna1.position[1],
//       antenna1.position[2],
//     );
//     g1.rotation.set(
//       THREE.MathUtils.degToRad(antenna1.rotation[0]),
//       THREE.MathUtils.degToRad(antenna1.rotation[1]),
//       THREE.MathUtils.degToRad(antenna1.rotation[2]),
//     );

//     g2.position.set(
//       antenna2.position[0],
//       antenna2.position[1],
//       antenna2.position[2],
//     );
//     g2.rotation.set(
//       THREE.MathUtils.degToRad(antenna2.rotation[0]),
//       THREE.MathUtils.degToRad(antenna2.rotation[1]),
//       THREE.MathUtils.degToRad(antenna2.rotation[2]),
//     );

//     // Build Antenna 1
//     if (antenna1.enabled) {
//       if (antenna1.showPhysicalAntenna) {
//         const physical1 = createPhysicalAntennaMesh(antenna1);
//         g1.add(physical1);
//       }
//       if (antenna1.showLobe) {
//         const lobe1 = createRadiationLobeMesh(
//           antenna1,
//           colormap,
//           heatmapMetric,
//           evalDistanceMeters,
//           rfEnvironment,
//         );
//         g1.add(lobe1);
//         activeLobeMeshesRef.current.push(lobe1);
//       }
//     }

//     // Build Antenna 2
//     if (antenna2.enabled) {
//       if (antenna2.showPhysicalAntenna) {
//         const physical2 = createPhysicalAntennaMesh(antenna2);
//         g2.add(physical2);
//       }
//       if (antenna2.showLobe) {
//         const lobe2 = createRadiationLobeMesh(
//           antenna2,
//           colormap,
//           heatmapMetric,
//           evalDistanceMeters,
//           rfEnvironment,
//         );
//         g2.add(lobe2);
//         activeLobeMeshesRef.current.push(lobe2);
//       }
//     }

//     // Attach / Update TransformControls Gizmo
//     if (transformControlsRef.current) {
//       const tc = transformControlsRef.current;
//       if (gizmoMode === "none") {
//         tc.detach();
//       } else {
//         const targetGroup = selectedAntennaId === "antenna-1" ? g1 : g2;
//         tc.setMode(gizmoMode);
//         tc.attach(targetGroup);
//       }
//     }

//     // Link budget line
//     if (viewMode === "link-budget" && antenna1.enabled && antenna2.enabled) {
//       if (linkLineRef.current && linkLineRef.current.parent) {
//         linkLineRef.current.parent.remove(linkLineRef.current);
//       }
//       const linkLineMat = new THREE.LineDashedMaterial({
//         color: 0x38bdf8,
//         dashSize: 0.25,
//         gapSize: 0.15,
//         linewidth: 3,
//       });
//       const p1 = new THREE.Vector3();
//       const p2 = new THREE.Vector3();
//       g1.getWorldPosition(p1);
//       g2.getWorldPosition(p2);
//       const linkGeo = new THREE.BufferGeometry().setFromPoints([p1, p2]);
//       const linkLine = new THREE.Line(linkGeo, linkLineMat);
//       linkLine.computeLineDistances();
//       g1.parent?.add(linkLine);
//       linkLineRef.current = linkLine;
//     } else if (linkLineRef.current && linkLineRef.current.parent) {
//       linkLineRef.current.parent.remove(linkLineRef.current);
//       linkLineRef.current = null;
//     }
//   }, [
//     antenna1,
//     antenna2,
//     selectedAntennaId,
//     gizmoMode,
//     viewMode,
//     colormap,
//     heatmapMetric,
//     evalDistanceMeters,
//     linkDistanceMeters,
//     rfEnvironment,
//   ]);

//   // 4. Raycasting & Hover Inspection Event Handlers
//   const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
//     // If pinned or cursor is actively inside the tooltip card, keep data intact!
//     if (isInspectionPinned || isHoveringTooltip) return;

//     if (!mountRef.current || !cameraRef.current) return;
//     const rect = mountRef.current.getBoundingClientRect();
//     const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
//     const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

//     pointerRef.current.set(x, y);

//     const camera = cameraRef.current;
//     const raycaster = raycasterRef.current;
//     raycaster.setFromCamera(pointerRef.current, camera);

//     const intersects = raycaster.intersectObjects(
//       activeLobeMeshesRef.current,
//       false,
//     );

//     if (intersects.length > 0) {
//       const hit = intersects[0];
//       const hitMesh = hit.object as THREE.Mesh;
//       const configId = hitMesh.userData.configId as "antenna-1" | "antenna-2";
//       const config = configId === "antenna-1" ? antenna1 : antenna2;

//       // Transform world hit point to local antenna space (takes into account both translation and rotation!)
//       const antGroup =
//         configId === "antenna-1" ? ant1GroupRef.current : ant2GroupRef.current;
//       const localHit = antGroup.worldToLocal(hit.point.clone());

//       const r = localHit.length();
//       const theta = Math.acos(
//         Math.max(-1, Math.min(1, localHit.y / Math.max(1e-5, r))),
//       );
//       const phi = Math.atan2(localHit.z, localHit.x);

//       const thetaDeg = Math.round(((theta * 180) / Math.PI) * 10) / 10;
//       const phiDeg = Math.round(((phi * 180) / Math.PI) * 10) / 10;

//       const patternSample = calculateRadiationPattern(theta, phi, config);
//       const gainDbi = Math.round(patternSample.gainDbi * 100) / 100;

//       const { eirpDbm, eirpWatts } = calculateEIRP(
//         config.powerMilliwatts,
//         gainDbi,
//       );
//       const { rssiDbm, fsplDb, atmosphericLossDb } = calculateReceivedPowerDbm(
//         config.powerMilliwatts,
//         gainDbi,
//         0,
//         evalDistanceMeters,
//         config.frequencyMHz,
//         rfEnvironment.weather,
//       );
//       const bwHz = rfEnvironment.bandwidthMHz * 1e6;
//       const { snrDb, noiseFloorDbm, modulationGrade } = calculateSNR(
//         rssiDbm,
//         bwHz,
//         rfEnvironment.noiseFigureDb,
//       );
//       const eField = calculateElectricField(eirpWatts, evalDistanceMeters);
//       const powerDensity = calculatePowerDensityUWCm2(
//         eirpWatts,
//         evalDistanceMeters,
//       );
//       const maxCoverageDist = calculateMaxCoverageRange(
//         config.powerMilliwatts,
//         gainDbi,
//         config.frequencyMHz,
//         rxSensitivityDbm,
//         0,
//         rfEnvironment.weather,
//       );

//       const inspectionData: HoverInspectionData = {
//         antennaId: config.id,
//         antennaName: config.name,
//         color: config.color,
//         worldPosition: [hit.point.x, hit.point.y, hit.point.z],
//         distanceFromCenter: Math.round(r * 100) / 100,
//         thetaDeg,
//         phiDeg,
//         dbiAtPoint: gainDbi,
//         relativeGainLinear:
//           Math.round(patternSample.relativeLinear * 1000) / 1000,
//         evalDistanceMeters,
//         rssiAtDistanceDbm: Math.round(rssiDbm * 10) / 10,
//         fsplDb: Math.round(fsplDb * 10) / 10,
//         atmosphericLossDb: Math.round(atmosphericLossDb * 100) / 100,
//         noiseFloorDbm,
//         snrDb,
//         modulationGrade,
//         eFieldVm: Math.round(eField * 1000) / 1000,
//         powerDensityUWCm2: Math.round(powerDensity * 1000) / 1000,
//         eirpDbm: Math.round(eirpDbm * 10) / 10,
//         eirpWatts: Math.round(eirpWatts * 100) / 100,
//         coverageMaxMeters: Math.round(maxCoverageDist * 10) / 10,
//         rxSensitivityDbm,
//       };

//       setHoverData(inspectionData);

//       // Update 3D hover visuals
//       if (probeMarkerRef.current) {
//         probeMarkerRef.current.position.copy(hit.point);
//         probeMarkerRef.current.visible = true;
//       }
//       if (probeRayLineRef.current) {
//         const positions = probeRayLineRef.current.geometry.attributes
//           .position as THREE.BufferAttribute;
//         const originWorld = new THREE.Vector3();
//         antGroup.getWorldPosition(originWorld);
//         positions.setXYZ(0, originWorld.x, originWorld.y, originWorld.z);
//         positions.setXYZ(1, hit.point.x, hit.point.y, hit.point.z);
//         positions.needsUpdate = true;
//         probeRayLineRef.current.computeLineDistances();
//         probeRayLineRef.current.visible = true;
//       }
//     } else {
//       setHoverData(null);
//       if (probeMarkerRef.current) probeMarkerRef.current.visible = false;
//       if (probeRayLineRef.current) probeRayLineRef.current.visible = false;
//     }
//   };

//   const handlePointerLeave = () => {
//     // If pinned or cursor transitioned into the tooltip card, keep it intact!
//     if (isInspectionPinned || isHoveringTooltip) return;

//     setHoverData(null);
//     if (probeMarkerRef.current) probeMarkerRef.current.visible = false;
//     if (probeRayLineRef.current) probeRayLineRef.current.visible = false;
//   };

//   const handleCanvasClick = () => {
//     // Clicking on the lobe locks/pins the inspection data
//     if (hoverData) {
//       setIsInspectionPinned(true);
//     }
//   };

//   return (
//     <div
//       ref={mountRef}
//       onPointerMove={handlePointerMove}
//       onPointerLeave={handlePointerLeave}
//       onClick={handleCanvasClick}
//       className="relative w-full h-full cursor-crosshair overflow-hidden"
//     >
//       {/* Visual orientation indicator compass or legend in corner */}
//       <div className="absolute top-4 left-4 pointer-events-none flex items-center space-x-2 text-xs font-mono text-slate-400 bg-slate-900/70 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-700/60 shadow-lg">
//         <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse"></span>
//         <span>Interactive 3D Radiation Field</span>
//         <span className="text-slate-600">|</span>
//         <span className="text-slate-300">
//           Click lobe to Pin/Lock • Hover for Telemetry
//         </span>
//       </div>
//     </div>
//   );
// };
import React, { useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { TransformControls } from "three/examples/jsm/controls/TransformControls.js";
import { useAntennaStore } from "../store/antennaStore";
import {
  createRadiationLobeMesh,
  createPhysicalAntennaMesh,
} from "./3d/antennaGeometry";
import { calculateRadiationPattern } from "../math/radiationPatterns";
import {
  calculateElectricField,
  calculatePowerDensityUWCm2,
} from "../math/rfPhysics";
import {
  calculateDirectionalCoverageMetrics,
  calculateMaximumDirectionalCoverageRangeMeters,
} from "../math/directionalCoverage";
import { HoverInspectionData } from "../types/antenna";

const GRID_DIVISIONS = 40;
const MIN_SCENE_HALF_EXTENT_METERS = 12;

function formatDistance(meters: number): string {
  if (!Number.isFinite(meters)) return "—";
  if (meters >= 1000) return `${(meters / 1000).toFixed(2)} km`;
  return `${meters.toFixed(1)} m`;
}

function fogDensityForExtent(halfExtent: number): number {
  return Math.max(0.000005, Math.min(0.025, 0.25 / Math.max(1, halfExtent)));
}

function disposeObject3D(object: THREE.Object3D): void {
  object.traverse((child) => {
    const renderable = child as THREE.Mesh;
    if (renderable.geometry) renderable.geometry.dispose();

    const material = renderable.material as
      | THREE.Material
      | THREE.Material[]
      | undefined;
    if (Array.isArray(material)) {
      material.forEach((item) => item.dispose());
    } else if (material) {
      material.dispose();
    }
  });
}

function fitCameraToCoverage(
  camera: THREE.PerspectiveCamera,
  controls: OrbitControls,
  center: THREE.Vector3,
  halfExtent: number,
): void {
  const safeExtent = Math.max(MIN_SCENE_HALF_EXTENT_METERS, halfExtent);
  const verticalHalfFov = THREE.MathUtils.degToRad(camera.fov / 2);
  const horizontalHalfFov = Math.atan(
    Math.tan(verticalHalfFov) * Math.max(0.1, camera.aspect),
  );
  const limitingHalfFov = Math.min(verticalHalfFov, horizontalHalfFov);
  const fitDistance =
    (safeExtent / Math.max(0.1, Math.sin(limitingHalfFov))) * 1.2;
  const viewDirection = new THREE.Vector3(0.55, 0.38, 1).normalize();

  controls.target.copy(center);
  camera.position.copy(center).addScaledVector(viewDirection, fitDistance);
  camera.near = Math.max(0.05, safeExtent * 0.00001);
  camera.far = Math.max(1000, fitDistance + safeExtent * 5);
  camera.updateProjectionMatrix();

  controls.minDistance = Math.max(0.1, safeExtent * 0.0002);
  controls.maxDistance = Math.max(600, fitDistance * 8);
  controls.update();
}

export const Canvas3D: React.FC = () => {
  const mountRef = useRef<HTMLDivElement>(null);

  // Store subscriptions
  const antenna1 = useAntennaStore((s) => s.antenna1);
  const antenna2 = useAntennaStore((s) => s.antenna2);
  const selectedAntennaId = useAntennaStore((s) => s.selectedAntennaId);
  const setSelectedAntennaId = useAntennaStore((s) => s.setSelectedAntennaId);
  const gizmoMode = useAntennaStore((s) => s.gizmoMode);
  const viewMode = useAntennaStore((s) => s.viewMode);
  const colormap = useAntennaStore((s) => s.colormap);
  const heatmapMetric = useAntennaStore((s) => s.heatmapMetric);
  const evalDistanceMeters = useAntennaStore((s) => s.evalDistanceMeters);
  const rxSensitivityDbm = useAntennaStore((s) => s.rxSensitivityDbm);
  const showGroundPlane = useAntennaStore((s) => s.showGroundPlane);
  const showDistanceRings = useAntennaStore((s) => s.showDistanceRings);
  const showAxes = useAntennaStore((s) => s.showAxes);
  const autoRotate = useAntennaStore((s) => s.autoRotate);
  const polarCutMode = useAntennaStore((s) => s.polarCutMode);
  const linkDistanceMeters = useAntennaStore((s) => s.linkDistanceMeters);
  const rfEnvironment = useAntennaStore((s) => s.rfEnvironment);
  const hoverData = useAntennaStore((s) => s.hoverData);
  const setHoverData = useAntennaStore((s) => s.setHoverData);
  const isInspectionPinned = useAntennaStore((s) => s.isInspectionPinned);
  const setIsInspectionPinned = useAntennaStore((s) => s.setIsInspectionPinned);
  const isHoveringTooltip = useAntennaStore((s) => s.isHoveringTooltip);

  // Calculate the range envelope first, then use it to size the whole 3D world.
  // The configured gainDbi is the peak gain used by the normalized pattern models.
  const coverageScene = useMemo(() => {
    const range1 =
      calculateMaximumDirectionalCoverageRangeMeters(
        antenna1,
        antenna2,
        rxSensitivityDbm,
        rfEnvironment,
      ) * Math.max(0.01, antenna1.scaleLobe || 1);
    const range2 =
      calculateMaximumDirectionalCoverageRangeMeters(
        antenna2,
        antenna1,
        rxSensitivityDbm,
        rfEnvironment,
      ) * Math.max(0.01, antenna2.scaleLobe || 1);

    // Keep the world cube and XYZ axes anchored at the global origin.
    // Each axis must contain both antenna positions plus their full lobe radius.
    const requiredHalfExtent = Math.max(
      Math.abs(antenna1.position[0]) + range1,
      Math.abs(antenna1.position[1]) + range1,
      Math.abs(antenna1.position[2]) + range1,
      Math.abs(antenna2.position[0]) + range2,
      Math.abs(antenna2.position[1]) + range2,
      Math.abs(antenna2.position[2]) + range2,
    );
    const halfExtent = Math.max(
      MIN_SCENE_HALF_EXTENT_METERS,
      requiredHalfExtent * 1.12,
    );

    return {
      range1,
      range2,
      center: new THREE.Vector3(0, 0, 0),
      halfExtent,
    };
  }, [antenna1, antenna2, rxSensitivityDbm, rfEnvironment]);

  const sceneHalfExtent = coverageScene.halfExtent;
  const sceneCenter = coverageScene.center;

  // Three.js runtime references
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const transformControlsRef = useRef<TransformControls | null>(null);

  // Object groups
  const ant1GroupRef = useRef<THREE.Group>(new THREE.Group());
  const ant2GroupRef = useRef<THREE.Group>(new THREE.Group());
  const visualHelpersGroupRef = useRef<THREE.Group>(new THREE.Group());
  const linkLineRef = useRef<THREE.Line | null>(null);

  // Probe / Hover interactive visuals
  const probeMarkerRef = useRef<THREE.Mesh | null>(null);
  const probeRayLineRef = useRef<THREE.Line | null>(null);
  const raycasterRef = useRef<THREE.Raycaster>(new THREE.Raycaster());
  const pointerRef = useRef<THREE.Vector2>(new THREE.Vector2(-999, -999));
  const activeLobeMeshesRef = useRef<THREE.Mesh[]>([]);
  const hasUserInteractedWithCameraRef = useRef(false);
  const lastFittedExtentRef = useRef<number | null>(null);
  const lastFittedCenterRef = useRef<THREE.Vector3>(new THREE.Vector3());

  // 1. Initialize Scene, Camera, Renderer, Controls & TransformControls
  useEffect(() => {
    if (!mountRef.current) return;
    const container = mountRef.current;
    const width = container.clientWidth;
    const height = container.clientHeight;

    // Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x070b14);
    scene.fog = new THREE.FogExp2(
      0x070b14,
      fogDensityForExtent(sceneHalfExtent),
    );
    sceneRef.current = scene;

    // One world unit now represents one metre. Set a generous clipping range;
    // the adaptive effect below keeps it synchronized as coverage changes.
    const camera = new THREE.PerspectiveCamera(
      45,
      width / height,
      0.1,
      Math.max(1000, sceneHalfExtent * 10),
    );
    cameraRef.current = camera;

    // Renderer
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: "high-performance",
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // OrbitControls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.maxPolarAngle = Math.PI / 2 + 0.15; // Allow viewing slightly from below horizon
    controls.minDistance = Math.max(0.1, sceneHalfExtent * 0.0002);
    controls.maxDistance = Math.max(600, sceneHalfExtent * 8);
    controls.addEventListener("start", () => {
      hasUserInteractedWithCameraRef.current = true;
    });
    controlsRef.current = controls;
    fitCameraToCoverage(camera, controls, sceneCenter, sceneHalfExtent);
    lastFittedExtentRef.current = sceneHalfExtent;
    lastFittedCenterRef.current.copy(sceneCenter);

    // TransformControls for interactive 3D translation & rotation gizmos
    const transformControls = new TransformControls(
      camera,
      renderer.domElement,
    );
    transformControls.size = Math.max(
      0.75,
      Math.min(2.5, sceneHalfExtent * 0.0005),
    );
    transformControls.addEventListener("dragging-changed", (event) => {
      controls.enabled = !event.value;
      if (event.value) hasUserInteractedWithCameraRef.current = true;
    });

    transformControls.addEventListener("objectChange", () => {
      const target = transformControls.object;
      if (!target) return;
      const isAnt1 = target === ant1GroupRef.current;

      const newPos: [number, number, number] = [
        Math.round(target.position.x * 100) / 100,
        Math.round(target.position.y * 100) / 100,
        Math.round(target.position.z * 100) / 100,
      ];

      const newRot: [number, number, number] = [
        Math.round(THREE.MathUtils.radToDeg(target.rotation.x) * 10) / 10,
        Math.round(THREE.MathUtils.radToDeg(target.rotation.y) * 10) / 10,
        Math.round(THREE.MathUtils.radToDeg(target.rotation.z) * 10) / 10,
      ];

      if (isAnt1) {
        useAntennaStore
          .getState()
          .updateAntenna1({ position: newPos, rotation: newRot });
      } else {
        useAntennaStore
          .getState()
          .updateAntenna2({ position: newPos, rotation: newRot });
      }
    });

    scene.add(transformControls.getHelper());
    transformControlsRef.current = transformControls;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.65);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0xffffff, 1.2);
    dirLight1.position.set(10, 15, 10);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x38bdf8, 0.5);
    dirLight2.position.set(-10, -5, -10);
    scene.add(dirLight2);

    // Add containers for antennas and helpers
    scene.add(ant1GroupRef.current);
    scene.add(ant2GroupRef.current);
    scene.add(visualHelpersGroupRef.current);

    // Create Hover Probe indicator objects
    const markerGeo = new THREE.SphereGeometry(
      Math.max(0.08, Math.min(3, sceneHalfExtent * 0.0005)),
      16,
      16,
    );
    const markerMat = new THREE.MeshBasicMaterial({
      color: 0xffff00,
      wireframe: true,
    });
    const probeMarker = new THREE.Mesh(markerGeo, markerMat);
    probeMarker.visible = false;
    scene.add(probeMarker);
    probeMarkerRef.current = probeMarker;

    const lineMat = new THREE.LineDashedMaterial({
      color: 0x38bdf8,
      dashSize: Math.max(0.1, Math.min(20, sceneHalfExtent * 0.002)),
      gapSize: Math.max(0.1, Math.min(20, sceneHalfExtent * 0.002)),
      linewidth: 2,
    });
    const lineGeo = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(0, 0, 0),
      new THREE.Vector3(0, 0, 0),
    ]);
    const probeLine = new THREE.Line(lineGeo, lineMat);
    probeLine.computeLineDistances();
    probeLine.visible = false;
    scene.add(probeLine);
    probeRayLineRef.current = probeLine;

    // Animation Loop
    let animationFrameId: number;
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      if (controlsRef.current) {
        controlsRef.current.autoRotate = autoRotate;
        controlsRef.current.autoRotateSpeed = 1.0;
        controlsRef.current.update();
      }
      renderer.render(scene, camera);
    };
    animate();

    // Window Resize Handler
    const handleResize = () => {
      if (!mountRef.current || !rendererRef.current || !cameraRef.current)
        return;
      const w = mountRef.current.clientWidth;
      const h = mountRef.current.clientHeight;
      cameraRef.current.aspect = w / h;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(w, h);
    };
    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
      cancelAnimationFrame(animationFrameId);
      transformControls.dispose();
      controls.dispose();
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  // Keep camera clipping, fog and camera fit synchronized with the coverage envelope.
  // The view is reframed when the world grows materially or moves out of view; small
  // control changes do not continuously fight the user's manual camera movement.
  useEffect(() => {
    const camera = cameraRef.current;
    const controls = controlsRef.current;
    const scene = sceneRef.current;
    if (!camera || !controls || !scene) return;

    const previousExtent = lastFittedExtentRef.current;
    const centerShift = lastFittedCenterRef.current.distanceTo(sceneCenter);
    const shouldRefit =
      previousExtent === null ||
      !hasUserInteractedWithCameraRef.current ||
      sceneHalfExtent > previousExtent * 1.15 ||
      sceneHalfExtent < previousExtent * 0.65 ||
      centerShift > Math.max(10, (previousExtent ?? sceneHalfExtent) * 0.5);

    camera.near = Math.max(0.05, sceneHalfExtent * 0.00001);
    camera.far = Math.max(1000, sceneHalfExtent * 10);
    camera.updateProjectionMatrix();
    controls.maxDistance = Math.max(600, sceneHalfExtent * 8);

    if (scene.fog instanceof THREE.FogExp2) {
      scene.fog.density = fogDensityForExtent(sceneHalfExtent);
    }

    if (shouldRefit) {
      fitCameraToCoverage(camera, controls, sceneCenter, sceneHalfExtent);
      lastFittedExtentRef.current = sceneHalfExtent;
      lastFittedCenterRef.current.copy(sceneCenter);
    }

    // Keep inspection helpers visible when the scene spans kilometres.
    if (probeMarkerRef.current) {
      const markerRadius = Math.max(
        0.08,
        Math.min(3, sceneHalfExtent * 0.0005),
      );
      probeMarkerRef.current.geometry.dispose();
      probeMarkerRef.current.geometry = new THREE.SphereGeometry(
        markerRadius,
        16,
        16,
      );
    }
    if (probeRayLineRef.current) {
      const material = probeRayLineRef.current
        .material as THREE.LineDashedMaterial;
      material.dashSize = Math.max(0.1, Math.min(20, sceneHalfExtent * 0.002));
      material.gapSize = material.dashSize;
    }
    if (transformControlsRef.current) {
      transformControlsRef.current.size = Math.max(
        0.75,
        Math.min(2.5, sceneHalfExtent * 0.0005),
      );
    }
  }, [sceneHalfExtent, sceneCenter.x, sceneCenter.y, sceneCenter.z]);

  // 2. Update adaptive environment helpers (ground grid, rings, axes, boundary cube).
  useEffect(() => {
    const group = visualHelpersGroupRef.current;
    while (group.children.length > 0) {
      const child = group.children[0];
      group.remove(child);
      disposeObject3D(child);
    }

    const worldSize = sceneHalfExtent * 2;
    const boundaryBox = new THREE.Box3(
      new THREE.Vector3(
        sceneCenter.x - sceneHalfExtent,
        sceneCenter.y - sceneHalfExtent,
        sceneCenter.z - sceneHalfExtent,
      ),
      new THREE.Vector3(
        sceneCenter.x + sceneHalfExtent,
        sceneCenter.y + sceneHalfExtent,
        sceneCenter.z + sceneHalfExtent,
      ),
    );

    // Show the adaptive cube boundary even when the ground grid is hidden.
    const boundary = new THREE.Box3Helper(boundaryBox, 0x1e3a5f);
    const boundaryMaterial = boundary.material as THREE.LineBasicMaterial;
    boundaryMaterial.transparent = true;
    boundaryMaterial.opacity = 0.45;
    group.add(boundary);

    // Ground grid now covers the entire adaptive world instead of a fixed 24m square.
    if (showGroundPlane) {
      const grid = new THREE.GridHelper(
        worldSize,
        GRID_DIVISIONS,
        0x1e293b,
        0x0f172a,
      );
      grid.position.set(sceneCenter.x, 0, sceneCenter.z);
      group.add(grid);
    }

    // Five concentric distance rings scale with the current world extent.
    if (showDistanceRings) {
      const ringThickness = Math.max(0.01, sceneHalfExtent * 0.0004);
      for (let i = 1; i <= 5; i++) {
        const distance = (sceneHalfExtent * i) / 5;
        const ringGeo = new THREE.RingGeometry(
          Math.max(0.001, distance - ringThickness),
          distance + ringThickness,
          128,
        );
        const ringMat = new THREE.MeshBasicMaterial({
          color: 0x334155,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.35,
        });
        const ringMesh = new THREE.Mesh(ringGeo, ringMat);
        ringMesh.rotation.x = Math.PI / 2;
        ringMesh.position.set(sceneCenter.x, 0.005, sceneCenter.z);
        group.add(ringMesh);
      }
    }

    // Axes length adapts so that they remain useful at long ranges.
    if (showAxes) {
      const axesHelper = new THREE.AxesHelper(
        Math.max(2.5, sceneHalfExtent * 0.2),
      );
      axesHelper.position.copy(sceneCenter);
      group.add(axesHelper);
    }

    // Polar cut planes scale with the adaptive coverage world.
    if (polarCutMode === "e-plane") {
      const planeGeo = new THREE.PlaneGeometry(worldSize, worldSize);
      const planeMat = new THREE.MeshBasicMaterial({
        color: 0x38bdf8,
        transparent: true,
        opacity: 0.12,
        side: THREE.DoubleSide,
        wireframe: false,
      });
      const planeMesh = new THREE.Mesh(planeGeo, planeMat);
      planeMesh.position.copy(sceneCenter);
      group.add(planeMesh);

      const wire = new THREE.LineSegments(
        new THREE.WireframeGeometry(planeGeo),
        new THREE.LineBasicMaterial({
          color: 0x38bdf8,
          transparent: true,
          opacity: 0.3,
        }),
      );
      wire.position.copy(sceneCenter);
      group.add(wire);
    } else if (polarCutMode === "h-plane") {
      const planeGeo = new THREE.PlaneGeometry(worldSize, worldSize);
      const planeMat = new THREE.MeshBasicMaterial({
        color: 0x10b981,
        transparent: true,
        opacity: 0.12,
        side: THREE.DoubleSide,
      });
      const planeMesh = new THREE.Mesh(planeGeo, planeMat);
      planeMesh.rotation.x = Math.PI / 2;
      planeMesh.position.copy(sceneCenter);
      group.add(planeMesh);
    }
  }, [
    showGroundPlane,
    showDistanceRings,
    showAxes,
    polarCutMode,
    sceneHalfExtent,
    sceneCenter.x,
    sceneCenter.y,
    sceneCenter.z,
  ]);

  // 3. Rebuild Antenna 1 & Antenna 2 Meshes and Apply 3D Spatial Transforms
  useEffect(() => {
    const g1 = ant1GroupRef.current;
    const g2 = ant2GroupRef.current;

    // Clear existing children
    while (g1.children.length > 0) {
      const child = g1.children[0];
      g1.remove(child);
      disposeObject3D(child);
    }
    while (g2.children.length > 0) {
      const child = g2.children[0];
      g2.remove(child);
      disposeObject3D(child);
    }
    activeLobeMeshesRef.current = [];

    // Apply Position and Rotation on any axis from store
    g1.position.set(
      antenna1.position[0],
      antenna1.position[1],
      antenna1.position[2],
    );
    g1.rotation.set(
      THREE.MathUtils.degToRad(antenna1.rotation[0]),
      THREE.MathUtils.degToRad(antenna1.rotation[1]),
      THREE.MathUtils.degToRad(antenna1.rotation[2]),
    );

    g2.position.set(
      antenna2.position[0],
      antenna2.position[1],
      antenna2.position[2],
    );
    g2.rotation.set(
      THREE.MathUtils.degToRad(antenna2.rotation[0]),
      THREE.MathUtils.degToRad(antenna2.rotation[1]),
      THREE.MathUtils.degToRad(antenna2.rotation[2]),
    );

    // Build Antenna 1
    if (antenna1.enabled) {
      if (antenna1.showPhysicalAntenna) {
        const physical1 = createPhysicalAntennaMesh(antenna1);
        g1.add(physical1);
      }
      if (antenna1.showLobe) {
        const lobe1 = createRadiationLobeMesh(
          antenna1,
          antenna2,
          rxSensitivityDbm,
          colormap,
          heatmapMetric,
          evalDistanceMeters,
          rfEnvironment,
        );
        g1.add(lobe1);
        activeLobeMeshesRef.current.push(lobe1);
      }
    }

    // Build Antenna 2
    if (antenna2.enabled) {
      if (antenna2.showPhysicalAntenna) {
        const physical2 = createPhysicalAntennaMesh(antenna2);
        g2.add(physical2);
      }
      if (antenna2.showLobe) {
        const lobe2 = createRadiationLobeMesh(
          antenna2,
          antenna1,
          rxSensitivityDbm,
          colormap,
          heatmapMetric,
          evalDistanceMeters,
          rfEnvironment,
        );
        g2.add(lobe2);
        activeLobeMeshesRef.current.push(lobe2);
      }
    }

    // Attach / Update TransformControls Gizmo
    if (transformControlsRef.current) {
      const tc = transformControlsRef.current;
      if (gizmoMode === "none") {
        tc.detach();
      } else {
        const targetGroup = selectedAntennaId === "antenna-1" ? g1 : g2;
        tc.setMode(gizmoMode);
        tc.attach(targetGroup);
      }
    }

    // Link budget line
    if (viewMode === "link-budget" && antenna1.enabled && antenna2.enabled) {
      if (linkLineRef.current && linkLineRef.current.parent) {
        linkLineRef.current.parent.remove(linkLineRef.current);
        disposeObject3D(linkLineRef.current);
        linkLineRef.current = null;
      }
      const linkLineMat = new THREE.LineDashedMaterial({
        color: 0x38bdf8,
        dashSize: Math.max(0.25, Math.min(30, sceneHalfExtent * 0.002)),
        gapSize: Math.max(0.15, Math.min(20, sceneHalfExtent * 0.001)),
        linewidth: 3,
      });
      const p1 = new THREE.Vector3();
      const p2 = new THREE.Vector3();
      g1.getWorldPosition(p1);
      g2.getWorldPosition(p2);
      const linkGeo = new THREE.BufferGeometry().setFromPoints([p1, p2]);
      const linkLine = new THREE.Line(linkGeo, linkLineMat);
      linkLine.computeLineDistances();
      g1.parent?.add(linkLine);
      linkLineRef.current = linkLine;
    } else if (linkLineRef.current && linkLineRef.current.parent) {
      linkLineRef.current.parent.remove(linkLineRef.current);
      disposeObject3D(linkLineRef.current);
      linkLineRef.current = null;
    }
  }, [
    antenna1,
    antenna2,
    selectedAntennaId,
    gizmoMode,
    viewMode,
    colormap,
    heatmapMetric,
    evalDistanceMeters,
    rxSensitivityDbm,
    linkDistanceMeters,
    rfEnvironment,
    sceneHalfExtent,
  ]);

  // 4. Raycasting & Hover Inspection Event Handlers
  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    // If pinned or cursor is actively inside the tooltip card, keep data intact!
    if (isInspectionPinned || isHoveringTooltip) return;

    if (!mountRef.current || !cameraRef.current) return;
    const rect = mountRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    pointerRef.current.set(x, y);

    const camera = cameraRef.current;
    const raycaster = raycasterRef.current;
    raycaster.setFromCamera(pointerRef.current, camera);

    const intersects = raycaster.intersectObjects(
      activeLobeMeshesRef.current,
      false,
    );

    if (intersects.length > 0) {
      const hit = intersects[0];
      const hitMesh = hit.object as THREE.Mesh;
      const configId = hitMesh.userData.configId as "antenna-1" | "antenna-2";
      const config = configId === "antenna-1" ? antenna1 : antenna2;

      // Transform world hit point to local antenna space (takes into account both translation and rotation!)
      const antGroup =
        configId === "antenna-1" ? ant1GroupRef.current : ant2GroupRef.current;
      const localHit = antGroup.worldToLocal(hit.point.clone());

      const r = localHit.length();
      const theta = Math.acos(
        Math.max(-1, Math.min(1, localHit.y / Math.max(1e-5, r))),
      );
      const phi = Math.atan2(localHit.z, localHit.x);

      const thetaDeg = Math.round(((theta * 180) / Math.PI) * 10) / 10;
      const phiDeg = Math.round(((phi * 180) / Math.PI) * 10) / 10;

      const patternSample = calculateRadiationPattern(theta, phi, config);
      const gainDbi = Math.round(patternSample.gainDbi * 100) / 100;

      const peerConfig = configId === "antenna-1" ? antenna2 : antenna1;
      const directionalMetrics = calculateDirectionalCoverageMetrics(
        config,
        peerConfig,
        gainDbi,
        evalDistanceMeters,
        rxSensitivityDbm,
        rfEnvironment,
      );
      const eField = calculateElectricField(
        directionalMetrics.eirpWatts,
        evalDistanceMeters,
      );
      const powerDensity = calculatePowerDensityUWCm2(
        directionalMetrics.eirpWatts,
        evalDistanceMeters,
      );

      const inspectionData: HoverInspectionData = {
        antennaId: config.id,
        antennaName: config.name,
        color: config.color,
        worldPosition: [hit.point.x, hit.point.y, hit.point.z],
        distanceFromCenter: Math.round(r * 100) / 100,
        thetaDeg,
        phiDeg,
        dbiAtPoint: gainDbi,
        relativeGainLinear:
          Math.round(patternSample.relativeLinear * 1000) / 1000,
        evalDistanceMeters,
        rssiAtDistanceDbm: Math.round(directionalMetrics.rssiDbm * 10) / 10,
        fsplDb: Math.round(directionalMetrics.fsplDb * 10) / 10,
        atmosphericLossDb:
          Math.round(directionalMetrics.atmosphericLossDb * 100) / 100,
        noiseFloorDbm: directionalMetrics.noiseFloorDbm,
        snrDb: directionalMetrics.snrDb,
        modulationGrade: directionalMetrics.modulationGrade,
        eFieldVm: Math.round(eField * 1000) / 1000,
        powerDensityUWCm2: Math.round(powerDensity * 1000) / 1000,
        eirpDbm: Math.round(directionalMetrics.eirpDbm * 10) / 10,
        eirpWatts: Math.round(directionalMetrics.eirpWatts * 100) / 100,
        coverageMaxMeters:
          Math.round(directionalMetrics.coverageRangeMeters * 10) / 10,
        rxSensitivityDbm,
      };

      setHoverData(inspectionData);

      // Update 3D hover visuals
      if (probeMarkerRef.current) {
        probeMarkerRef.current.position.copy(hit.point);
        probeMarkerRef.current.visible = true;
      }
      if (probeRayLineRef.current) {
        const positions = probeRayLineRef.current.geometry.attributes
          .position as THREE.BufferAttribute;
        const originWorld = new THREE.Vector3();
        antGroup.getWorldPosition(originWorld);
        positions.setXYZ(0, originWorld.x, originWorld.y, originWorld.z);
        positions.setXYZ(1, hit.point.x, hit.point.y, hit.point.z);
        positions.needsUpdate = true;
        probeRayLineRef.current.computeLineDistances();
        probeRayLineRef.current.visible = true;
      }
    } else {
      setHoverData(null);
      if (probeMarkerRef.current) probeMarkerRef.current.visible = false;
      if (probeRayLineRef.current) probeRayLineRef.current.visible = false;
    }
  };

  const handlePointerLeave = () => {
    // If pinned or cursor transitioned into the tooltip card, keep it intact!
    if (isInspectionPinned || isHoveringTooltip) return;

    setHoverData(null);
    if (probeMarkerRef.current) probeMarkerRef.current.visible = false;
    if (probeRayLineRef.current) probeRayLineRef.current.visible = false;
  };

  const handleCanvasClick = () => {
    // Clicking on the lobe locks/pins the inspection data
    if (hoverData) {
      setIsInspectionPinned(true);
    }
  };

  return (
    <div
      ref={mountRef}
      onPointerMove={handlePointerMove}
      onPointerLeave={handlePointerLeave}
      onClick={handleCanvasClick}
      className="relative w-full h-full cursor-crosshair overflow-hidden"
    >
      {/* Visual orientation indicator compass or legend in corner */}
      <div className="absolute top-4 left-4 pointer-events-none flex items-center space-x-2 text-xs font-mono text-slate-400 bg-slate-900/70 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-700/60 shadow-lg">
        <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse"></span>
        <span>Interactive 3D RF Coverage</span>
        <span className="text-slate-600">|</span>
        <span className="text-slate-300">
          World: {formatDistance(sceneHalfExtent * 2)} cube • Grid:{" "}
          {formatDistance((sceneHalfExtent * 2) / GRID_DIVISIONS)} per cell
        </span>
        <span className="text-slate-600">|</span>
        <span className="text-slate-300">
          A1 max: {formatDistance(coverageScene.range1)} • A2 max:{" "}
          {formatDistance(coverageScene.range2)}
        </span>
        <span className="text-slate-600">|</span>
        <span className="text-slate-300">
          Click lobe to Pin/Lock • Hover for Telemetry
        </span>
      </div>
    </div>
  );
};
