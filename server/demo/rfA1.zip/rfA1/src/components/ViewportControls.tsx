import React from 'react';
import { useAntennaStore } from '../store/antennaStore';
import {
  Grid,
  CircleDot,
  Axis3d,
  Move,
  RotateCcw,
  Maximize,
  Crosshair,
} from 'lucide-react';

export const ViewportControls: React.FC = () => {
  const showGroundPlane = useAntennaStore((s) => s.showGroundPlane);
  const setShowGroundPlane = useAntennaStore((s) => s.setShowGroundPlane);
  const showDistanceRings = useAntennaStore((s) => s.showDistanceRings);
  const setShowDistanceRings = useAntennaStore((s) => s.setShowDistanceRings);
  const showAxes = useAntennaStore((s) => s.showAxes);
  const setShowAxes = useAntennaStore((s) => s.setShowAxes);
  const rxSensitivityDbm = useAntennaStore((s) => s.rxSensitivityDbm);
  const setRxSensitivityDbm = useAntennaStore((s) => s.setRxSensitivityDbm);
  const gizmoMode = useAntennaStore((s) => s.gizmoMode);
  const setGizmoMode = useAntennaStore((s) => s.setGizmoMode);
  const selectedAntennaId = useAntennaStore((s) => s.selectedAntennaId);
  const setSelectedAntennaId = useAntennaStore((s) => s.setSelectedAntennaId);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen().catch(() => {});
    }
  };

  return (
    <div className="absolute bottom-14 left-4 z-20 flex flex-wrap items-center gap-1.5 bg-slate-900/90 backdrop-blur-md p-1.5 rounded-2xl border border-slate-800 shadow-xl font-mono text-xs">
      {/* Active Antenna Selector for 3D manipulation */}
      <div className="flex items-center space-x-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
        <button
          onClick={() => setSelectedAntennaId('antenna-1')}
          title="Select Antenna 1 for 3D manipulation"
          className={`px-2 py-1 rounded-lg text-[10px] font-semibold flex items-center space-x-1 transition-all ${
            selectedAntennaId === 'antenna-1'
              ? 'bg-sky-500/20 text-sky-400 border border-sky-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <div className="w-2 h-2 rounded-full bg-sky-400" />
          <span>Ant 1</span>
        </button>

        <button
          onClick={() => setSelectedAntennaId('antenna-2')}
          title="Select Antenna 2 for 3D manipulation"
          className={`px-2 py-1 rounded-lg text-[10px] font-semibold flex items-center space-x-1 transition-all ${
            selectedAntennaId === 'antenna-2'
              ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <div className="w-2 h-2 rounded-full bg-rose-400" />
          <span>Ant 2</span>
        </button>
      </div>

      {/* 3D Gizmo Mode Toggles (Move, Rotate, Off) */}
      <div className="flex items-center space-x-0.5 bg-slate-950 p-1 rounded-xl border border-slate-800">
        <button
          onClick={() => setGizmoMode(gizmoMode === 'translate' ? 'none' : 'translate')}
          title="3D Move Gizmo (X, Y, Z translation arrows)"
          className={`p-1.5 rounded-lg border transition-all ${
            gizmoMode === 'translate'
              ? 'bg-sky-500/20 text-sky-300 border-sky-500/50 shadow-sm'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Move className="w-3.5 h-3.5" />
        </button>

        <button
          onClick={() => setGizmoMode(gizmoMode === 'rotate' ? 'none' : 'rotate')}
          title="3D Rotate Gizmo (Pitch, Yaw, Roll gimbal rings)"
          className={`p-1.5 rounded-lg border transition-all ${
            gizmoMode === 'rotate'
              ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500/50 shadow-sm'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Crosshair className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="h-5 w-px bg-slate-800 mx-0.5" />

      {/* Ground Plane Toggle */}
      <button
        onClick={() => setShowGroundPlane(!showGroundPlane)}
        title="Toggle Ground Plane Grid"
        className={`p-2 rounded-xl border transition-all ${
          showGroundPlane
            ? 'bg-sky-500/20 text-sky-400 border-sky-500/40 shadow-sm'
            : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
        }`}
      >
        <Grid className="w-3.5 h-3.5" />
      </button>

      {/* Distance Rings Toggle */}
      <button
        onClick={() => setShowDistanceRings(!showDistanceRings)}
        title="Toggle Radar Range Rings"
        className={`p-2 rounded-xl border transition-all ${
          showDistanceRings
            ? 'bg-sky-500/20 text-sky-400 border-sky-500/40 shadow-sm'
            : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
        }`}
      >
        <CircleDot className="w-3.5 h-3.5" />
      </button>

      {/* 3D Axes Toggle */}
      <button
        onClick={() => setShowAxes(!showAxes)}
        title="Toggle 3D Coordinate Axes"
        className={`p-2 rounded-xl border transition-all ${
          showAxes
            ? 'bg-sky-500/20 text-sky-400 border-sky-500/40 shadow-sm'
            : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
        }`}
      >
        <Axis3d className="w-3.5 h-3.5" />
      </button>

      <div className="h-5 w-px bg-slate-800 mx-0.5" />

      {/* Quick Sensitivity Preset */}
      <div className="flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded-xl border border-slate-800 text-[11px]">
        <span className="text-slate-400 text-[10px]">Rx:</span>
        <select
          value={rxSensitivityDbm}
          onChange={(e) => setRxSensitivityDbm(parseFloat(e.target.value))}
          className="bg-transparent text-slate-200 focus:outline-none cursor-pointer"
        >
          <option value="-65" className="bg-slate-900 text-slate-200">-65 dBm</option>
          <option value="-75" className="bg-slate-900 text-slate-200">-75 dBm</option>
          <option value="-85" className="bg-slate-900 text-slate-200">-85 dBm (Wi-Fi)</option>
          <option value="-110" className="bg-slate-900 text-slate-200">-110 dBm (LoRa)</option>
        </select>
      </div>

      {/* Fullscreen */}
      <button
        onClick={toggleFullscreen}
        title="Toggle Fullscreen"
        className="p-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-400 hover:text-slate-200 transition-colors"
      >
        <Maximize className="w-3.5 h-3.5" />
      </button>
    </div>
  );
};
