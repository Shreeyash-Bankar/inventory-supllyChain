import React, { useState } from 'react';
import { useAntennaStore } from '../store/antennaStore';
import { ViewMode, ColormapType, HeatmapMetric } from '../types/antenna';
import {
  Radio,
  Split,
  Layers,
  ArrowLeftRight,
  Palette,
  RotateCw,
  Compass,
  Sliders,
  Sparkles,
  HelpCircle,
  RefreshCw,
  Activity,
} from 'lucide-react';

export const TopNav: React.FC = () => {
  const viewMode = useAntennaStore((s) => s.viewMode);
  const setViewMode = useAntennaStore((s) => s.setViewMode);
  const colormap = useAntennaStore((s) => s.colormap);
  const setColormap = useAntennaStore((s) => s.setColormap);
  const heatmapMetric = useAntennaStore((s) => s.heatmapMetric);
  const setHeatmapMetric = useAntennaStore((s) => s.setHeatmapMetric);
  const autoRotate = useAntennaStore((s) => s.autoRotate);
  const setAutoRotate = useAntennaStore((s) => s.setAutoRotate);
  const polarCutMode = useAntennaStore((s) => s.polarCutMode);
  const setPolarCutMode = useAntennaStore((s) => s.setPolarCutMode);
  const applyAntennaPreset = useAntennaStore((s) => s.applyAntennaPreset);
  const resetAll = useAntennaStore((s) => s.resetAll);

  const [showPresetsMenu, setShowPresetsMenu] = useState(false);
  const [showHelpModal, setShowHelpModal] = useState(false);

  const viewModes: { id: ViewMode; label: string; icon: React.ReactNode }[] = [
    { id: 'side-by-side', label: 'Side-by-Side', icon: <Split className="w-3.5 h-3.5" /> },
    { id: 'overlaid', label: 'Superimposed', icon: <Layers className="w-3.5 h-3.5" /> },
    { id: 'link-budget', label: 'RF Link', icon: <ArrowLeftRight className="w-3.5 h-3.5" /> },
  ];

  const colormaps: { id: ColormapType; label: string }[] = [
    { id: 'turbo', label: 'Turbo (Standard)' },
    { id: 'jet', label: 'Jet' },
    { id: 'viridis', label: 'Viridis' },
    { id: 'plasma', label: 'Plasma' },
    { id: 'electric', label: 'Electric' },
  ];

  const metrics: { id: HeatmapMetric; label: string }[] = [
    { id: 'dbi', label: 'Gain (dBi)' },
    { id: 'rssi', label: 'RSSI (dBm)' },
    { id: 'snr', label: 'SNR (dB)' },
    { id: 'field_strength', label: 'E-Field (V/m)' },
    { id: 'power_density', label: 'Power Density' },
  ];

  return (
    <>
      <header className="h-14 bg-slate-900/95 backdrop-blur-xl border-b border-slate-800 px-4 flex items-center justify-between z-30 select-none">
        {/* Logo & Branding */}
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-sky-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-sky-500/20">
            <Radio className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-bold text-sm tracking-wide bg-gradient-to-r from-sky-400 via-indigo-300 to-white bg-clip-text text-transparent">
                RF ANTENNA 3D STUDIO
              </span>
              <span className="text-[10px] bg-sky-500/10 text-sky-400 border border-sky-500/30 font-mono px-1.5 py-0.2 rounded font-semibold">
                0.01mW - 100W
              </span>
            </div>
            <div className="text-[10px] text-slate-400 font-mono">
              3D Radiation Lobe & Coverage Explorer
            </div>
          </div>
        </div>

        {/* View Mode Switcher */}
        <div className="hidden lg:flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800/80">
          {viewModes.map((vm) => (
            <button
              key={vm.id}
              onClick={() => setViewMode(vm.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center space-x-1.5 transition-all ${
                viewMode === vm.id
                  ? 'bg-sky-500/20 text-sky-400 border border-sky-500/30 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {vm.icon}
              <span>{vm.label}</span>
            </button>
          ))}
        </div>

        {/* Controls: Presets, Heatmap metric, Colormap, Helpers */}
        <div className="flex items-center space-x-2">
          {/* Quick Presets Dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowPresetsMenu(!showPresetsMenu)}
              className="px-2.5 py-1.5 rounded-xl text-xs font-medium bg-slate-950 border border-slate-800 text-slate-300 hover:text-white flex items-center space-x-1.5 transition-colors"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Presets</span>
            </button>

            {showPresetsMenu && (
              <div className="absolute right-0 mt-2 w-64 bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl p-2 z-50 text-xs font-mono animate-in fade-in zoom-in-95">
                <div className="px-2 py-1.5 text-[10px] uppercase tracking-wider text-slate-400 font-bold border-b border-slate-800">
                  Quick Benchmark Scenarios
                </div>
                <button
                  onClick={() => {
                    applyAntennaPreset('antenna-1', 'wifi-dipole');
                    applyAntennaPreset('antenna-2', 'patch-panel');
                    setShowPresetsMenu(false);
                  }}
                  className="w-full text-left px-2.5 py-2 hover:bg-slate-800 rounded-lg text-slate-300 hover:text-white flex flex-col"
                >
                  <span className="font-semibold text-sky-400">Wi-Fi 2.4G Dipole vs Patch</span>
                  <span className="text-[10px] text-slate-400">Omni 2.15 dBi vs Directional 8.5 dBi</span>
                </button>

                <button
                  onClick={() => {
                    applyAntennaPreset('antenna-1', 'lora-monopole');
                    applyAntennaPreset('antenna-2', 'yagi-directional');
                    setShowPresetsMenu(false);
                  }}
                  className="w-full text-left px-2.5 py-2 hover:bg-slate-800 rounded-lg text-slate-300 hover:text-white flex flex-col"
                >
                  <span className="font-semibold text-emerald-400">LoRa 868M Monopole vs 12dBi Yagi</span>
                  <span className="text-[10px] text-slate-400">25 mW Long-Range outdoor link</span>
                </button>

                <button
                  onClick={() => {
                    applyAntennaPreset('antenna-1', 'wifi-dipole');
                    applyAntennaPreset('antenna-2', 'horn-dish');
                    setShowPresetsMenu(false);
                  }}
                  className="w-full text-left px-2.5 py-2 hover:bg-slate-800 rounded-lg text-slate-300 hover:text-white flex flex-col"
                >
                  <span className="font-semibold text-rose-400">5.8G Pyramidal Horn (18 dBi)</span>
                  <span className="text-[10px] text-slate-400">1W High Directivity Narrow Beam</span>
                </button>

                <button
                  onClick={() => {
                    applyAntennaPreset('antenna-1', 'iot-micro');
                    applyAntennaPreset('antenna-2', 'high-power-pa');
                    setShowPresetsMenu(false);
                  }}
                  className="w-full text-left px-2.5 py-2 hover:bg-slate-800 rounded-lg text-slate-300 hover:text-white flex flex-col"
                >
                  <span className="font-semibold text-amber-400">0.01 mW IoT vs 50 W PA</span>
                  <span className="text-[10px] text-slate-400">70 dB dynamic range power test</span>
                </button>
              </div>
            )}
          </div>

          {/* Metric Selector */}
          <div className="hidden sm:flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded-xl border border-slate-800 text-xs font-mono">
            <span className="text-slate-400 text-[10px]">Metric:</span>
            <select
              value={heatmapMetric}
              onChange={(e) => setHeatmapMetric(e.target.value as HeatmapMetric)}
              className="bg-transparent text-slate-200 focus:outline-none cursor-pointer"
            >
              {metrics.map((m) => (
                <option key={m.id} value={m.id} className="bg-slate-900 text-slate-200">
                  {m.label}
                </option>
              ))}
            </select>
          </div>

          {/* Colormap Selector */}
          <div className="hidden md:flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded-xl border border-slate-800 text-xs font-mono">
            <Palette className="w-3.5 h-3.5 text-purple-400" />
            <select
              value={colormap}
              onChange={(e) => setColormap(e.target.value as ColormapType)}
              className="bg-transparent text-slate-200 focus:outline-none cursor-pointer"
            >
              {colormaps.map((cm) => (
                <option key={cm.id} value={cm.id} className="bg-slate-900 text-slate-200">
                  {cm.label}
                </option>
              ))}
            </select>
          </div>

          {/* Polar Plane Cut Toggle */}
          <button
            onClick={() => {
              if (polarCutMode === 'none') setPolarCutMode('e-plane');
              else if (polarCutMode === 'e-plane') setPolarCutMode('h-plane');
              else setPolarCutMode('none');
            }}
            title="Toggle Polar Cross-Section Slice"
            className={`px-2.5 py-1.5 rounded-xl text-xs font-mono border transition-all ${
              polarCutMode !== 'none'
                ? 'bg-sky-500/20 text-sky-400 border-sky-500/40'
                : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
            }`}
          >
            {polarCutMode === 'none' ? 'Slice: Off' : polarCutMode === 'e-plane' ? 'E-Plane Cut' : 'H-Plane Cut'}
          </button>

          {/* Auto Rotate Toggle */}
          <button
            onClick={() => setAutoRotate(!autoRotate)}
            title="Auto-rotate 3D view"
            className={`p-1.5 rounded-xl border transition-all ${
              autoRotate
                ? 'bg-indigo-500/20 text-indigo-400 border-indigo-500/40'
                : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
            }`}
          >
            <RotateCw className="w-4 h-4" />
          </button>

          {/* Reset All */}
          <button
            onClick={resetAll}
            title="Reset parameters to defaults"
            className="p-1.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-400 hover:text-slate-200 transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </header>
    </>
  );
};
