import React from "react";

import { useAntennaStore } from "../store/antennaStore";

import { calculateAntennaPairLinkBudget } from "../math/linkBudget";

import {
  ArrowLeftRight,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Radio,
} from "lucide-react";

export const LinkBudgetHUD: React.FC = () => {
  const viewMode = useAntennaStore((s) => s.viewMode);

  const antenna1 = useAntennaStore((s) => s.antenna1);
  const antenna2 = useAntennaStore((s) => s.antenna2);

  const setLinkDistanceMeters = useAntennaStore((s) => s.setLinkDistanceMeters);

  const rxSensitivityDbm = useAntennaStore((s) => s.rxSensitivityDbm);

  const rfEnvironment = useAntennaStore((s) => s.rfEnvironment);

  if (viewMode !== "link-budget") return null;

  const link = calculateAntennaPairLinkBudget(
    antenna1,
    antenna2,
    rfEnvironment,
    rxSensitivityDbm,
  );

  const distance = link.distanceMeters;
  const snr = link.snrDb;
  const rssi = link.receivedPowerDbm;
  const margin = link.fadeMarginDb;

  let statusLabel = "LINK PASS";
  let statusColor = "text-emerald-400";
  let statusBg = "bg-emerald-500/10 border-emerald-500/40";
  let StatusIcon = CheckCircle2;

  if (!link.isValid) {
    statusColor = "text-rose-400";
    statusBg = "bg-rose-500/10 border-rose-500/40";
    StatusIcon = XCircle;

    switch (link.issue) {
      case "frequency-mismatch":
        statusLabel = "FREQUENCY MISMATCH";
        break;

      case "near-field":
        statusLabel = "NEAR-FIELD MODEL LIMIT";
        break;

      case "antenna-disabled":
        statusLabel = "ANTENNA DISABLED";
        break;

      default:
        statusLabel = "INVALID TX/RX ROLES";
    }
  } else if ((margin ?? 0) < 0) {
    statusLabel = "LINK DOWN";
    statusColor = "text-rose-400";
    statusBg = "bg-rose-500/10 border-rose-500/40";
    StatusIcon = XCircle;
  } else if ((margin ?? 0) < 8 || (snr ?? 0) < 10) {
    statusLabel = "MARGINAL LINK";
    statusColor = "text-amber-400";
    statusBg = "bg-amber-500/10 border-amber-500/40";
    StatusIcon = AlertTriangle;
  }

  const distanceText =
    distance >= 1000
      ? `${(distance / 1000).toFixed(2)} km`
      : `${distance.toFixed(2)} m`;

  const formatDb = (value: number | null, digits = 1) =>
    value === null ? "—" : value.toFixed(digits);

  return (
    <div className="absolute top-16 left-1/2 -translate-x-1/2 z-20 w-full max-w-2xl px-4 pointer-events-auto">
      <div className="bg-slate-900/95 backdrop-blur-xl border border-slate-700/80 rounded-2xl p-3.5 shadow-2xl font-mono text-xs text-slate-200">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-800">
          <div className="flex items-center space-x-2">
            <ArrowLeftRight className="w-4 h-4 text-sky-400" />

            <span className="font-bold text-slate-100">
              Live RF Link Budget
            </span>
          </div>

          <div
            className={`px-2 py-1 rounded-full border flex items-center space-x-1 ${statusBg} ${statusColor}`}
          >
            <StatusIcon className="w-4 h-4" />
            <span>{statusLabel}</span>
          </div>
        </div>

        {/* Actual TX and RX */}
        <div className="grid grid-cols-2 gap-2 mt-3">
          <div className="bg-slate-950 p-2 rounded-xl border border-sky-500/30">
            <div className="text-sky-400 font-bold">TRANSMITTER</div>

            <div className="text-slate-200 mt-1">{link.tx.name}</div>

            <div className="text-slate-400 mt-1">
              {link.txPowerDbm.toFixed(1)} dBm
            </div>

            <div className="text-slate-500 mt-1 text-[10px]">
              {link.tx.frequencyMHz} MHz
            </div>
          </div>

          <div className="bg-slate-950 p-2 rounded-xl border border-rose-500/30">
            <div className="text-rose-400 font-bold">RECEIVER</div>

            <div className="text-slate-200 mt-1">{link.rx.name}</div>

            <div className="text-slate-400 mt-1">
              {link.rx.frequencyMHz} MHz
            </div>

            <div className="text-slate-500 mt-1 text-[10px]">
              Noise Figure: {rfEnvironment.noiseFigureDb} dB
            </div>
          </div>
        </div>

        {/* Actual TX-RX separation */}
        <div className="mt-3 bg-slate-950/70 p-3 rounded-xl border border-slate-800">
          <div className="flex justify-between items-center mb-2">
            <span className="text-slate-400">Actual TX-RX Distance</span>

            <span className="text-sky-300 font-bold text-sm">
              {distanceText}
            </span>
          </div>

          <input
            type="range"
            min="1"
            max="500"
            step="1"
            value={Math.min(500, Math.max(1, distance))}
            onChange={(e) => setLinkDistanceMeters(Number(e.target.value))}
            className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-sky-400"
          />

          <div className="flex justify-between text-[9px] text-slate-500 mt-1">
            <span>1 m</span>
            <span>250 m</span>
            <span>500 m</span>
          </div>

          <div className="text-[10px] text-slate-400 mt-2">
            Slider moves the actual receiver position.
          </div>
        </div>

        {/* Directional antenna gains */}
        <div className="grid grid-cols-2 gap-2 mt-3">
          <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
            <div className="text-slate-400 text-[10px]">
              TX Directional Gain
            </div>

            <div className="text-sky-300 font-bold">
              {formatDb(link.txGainDbi)} dBi
            </div>
          </div>

          <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
            <div className="text-slate-400 text-[10px]">
              RX Directional Gain
            </div>

            <div className="text-rose-300 font-bold">
              {formatDb(link.rxGainDbi)} dBi
            </div>
          </div>
        </div>

        {/* Link budget breakdown */}
        <div className="grid grid-cols-5 gap-1.5 text-center mt-3">
          <div className="bg-slate-950 p-2 rounded-lg">
            <div className="text-slate-500 text-[9px]">TX EIRP</div>

            <div className="text-sky-300 font-bold">
              {formatDb(link.directionalEirpDbm)}
            </div>

            <div className="text-slate-500 text-[9px]">dBm</div>
          </div>

          <div className="bg-slate-950 p-2 rounded-lg">
            <div className="text-slate-500 text-[9px]">FSPL</div>

            <div className="text-rose-300 font-bold">
              {formatDb(link.fsplDb)}
            </div>

            <div className="text-slate-500 text-[9px]">dB</div>
          </div>

          <div className="bg-slate-950 p-2 rounded-lg">
            <div className="text-slate-500 text-[9px]">Atmo Loss</div>

            <div className="text-cyan-300 font-bold">
              {formatDb(link.atmosphericLossDb, 2)}
            </div>

            <div className="text-slate-500 text-[9px]">dB</div>
          </div>

          <div className="bg-slate-950 p-2 rounded-lg">
            <div className="text-slate-500 text-[9px]">RX Gain</div>

            <div className="text-rose-300 font-bold">
              {formatDb(link.rxGainDbi)}
            </div>

            <div className="text-slate-500 text-[9px]">dBi</div>
          </div>

          <div className="bg-slate-950 p-2 rounded-lg">
            <div className="text-slate-500 text-[9px]">RX Power</div>

            <div
              className={`font-bold ${rssi !== null && rssi >= rxSensitivityDbm ? "text-emerald-300" : "text-rose-400"}`}
            >
              {formatDb(rssi)}
            </div>

            <div className="text-slate-500 text-[9px]">dBm</div>
          </div>
        </div>

        {/* Receiver SNR */}
        <div className="mt-3 bg-slate-950 p-3 rounded-xl border border-indigo-500/30">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center space-x-2">
              <Radio className="w-4 h-4 text-indigo-400" />

              <span className="text-slate-300 font-semibold">
                Receiver SNR ({link.rx.name})
              </span>
            </div>

            <div
              className={`text-2xl font-bold ${
                snr !== null && snr >= 10 ? "text-emerald-300" : "text-rose-400"
              }`}
            >
              {snr === null ? "N/A" : `${snr.toFixed(1)} dB`}
            </div>
          </div>

          <div className="flex justify-between mt-3 text-[11px]">
            <span className="text-slate-400">Noise Floor</span>

            <span className="text-indigo-300">
              {link.noiseFloorDbm.toFixed(1)} dBm
            </span>
          </div>

          <div className="flex justify-between mt-1 text-[11px]">
            <span className="text-slate-400">Receiver Sensitivity</span>

            <span className="text-slate-200">{rxSensitivityDbm} dBm</span>
          </div>

          <div className="flex justify-between mt-1 text-[11px]">
            <span className="text-slate-400">Fade Margin</span>

            <span
              className={
                margin !== null && margin >= 0
                  ? "text-emerald-400"
                  : "text-rose-400"
              }
            >
              {margin === null ? "N/A" : `${margin.toFixed(1)} dB`}
            </span>
          </div>

          <div className="flex justify-between mt-1 text-[11px]">
            <span className="text-slate-400">Modulation Estimate</span>

            <span className="text-indigo-300">{link.modulationGrade}</span>
          </div>

          {!link.isValid && (
            <p className="text-rose-400 text-[10px] mt-2">
              {link.issue === "near-field"
                ? `Distance is below the estimated far-field limit of ${link.minimumFarFieldDistanceMeters.toFixed(2)} m. FSPL-based SNR is unavailable.`
                : link.issue === "frequency-mismatch"
                  ? "TX and RX frequencies are outside the assumed receiver channel bandwidth."
                  : link.issue === "antenna-disabled"
                    ? "Both antennas must be enabled."
                    : "Select exactly one TX and one RX."}
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
