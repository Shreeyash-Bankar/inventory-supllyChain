// import React from "react";
// import { useAntennaStore } from "../store/antennaStore";
// import {
//   calculateReceivedPowerDbm,
//   calculateSNR,
//   calculateElectricField,
//   calculatePowerDensityUWCm2,
//   calculateMaxCoverageRange,
// } from "../math/rfPhysics";

// import { calculateAntennaPairLinkBudget } from "../math/linkBudget";
// import {
//   Zap,
//   Radio,
//   Compass,
//   ShieldCheck,
//   CloudRain,
//   Cpu,
//   BarChart2,
//   Pin,
//   X,
//   Lock,
// } from "lucide-react";

// export const RadiationTooltip: React.FC = () => {
//   const hoverData = useAntennaStore((s) => s.hoverData);
//   const setHoverData = useAntennaStore((s) => s.setHoverData);
//   const evalDistanceMeters = useAntennaStore((s) => s.evalDistanceMeters);
//   const setEvalDistanceMeters = useAntennaStore((s) => s.setEvalDistanceMeters);
//   const rfEnvironment = useAntennaStore((s) => s.rfEnvironment);
//   const rxSensitivityDbm = useAntennaStore((s) => s.rxSensitivityDbm);

//   const setLinkDistanceMeters = useAntennaStore((s) => s.setLinkDistanceMeters);

//   const antenna1 = useAntennaStore((s) => s.antenna1);
//   const antenna2 = useAntennaStore((s) => s.antenna2);
//   const isInspectionPinned = useAntennaStore((s) => s.isInspectionPinned);
//   const setIsInspectionPinned = useAntennaStore((s) => s.setIsInspectionPinned);
//   const setIsHoveringTooltip = useAntennaStore((s) => s.setIsHoveringTooltip);

//   if (!hoverData) {
//     return (
//       <div className="absolute top-4 right-4 pointer-events-none hidden md:flex items-center space-x-2 bg-slate-900/70 backdrop-blur-md px-3.5 py-2 rounded-xl border border-slate-800 text-xs text-slate-400">
//         <Radio className="w-4 h-4 text-sky-400 animate-pulse" />
//         <span>
//           Hover or click any 3D radiation lobe point to inspect & adjust
//           receiver distance
//         </span>
//       </div>
//     );
//   }

//   // Calculate the actual communication link.
//   const link = calculateAntennaPairLinkBudget(
//     antenna1,
//     antenna2,
//     rfEnvironment,
//     rxSensitivityDbm,
//   );

//   // Pair-level receiving metrics.
//   const rssiDbm = link.receivedPowerDbm;
//   const snrDb = link.snrDb;
//   const noiseFloorDbm = link.noiseFloorDbm;
//   const modulationGrade = link.modulationGrade;

//   const fsplDb = link.fsplDb;
//   const atmosphericLossDb = link.atmosphericLossDb;

//   const sens = rxSensitivityDbm;
//   const linkMargin = link.fadeMarginDb;

//   // Electric field and power density at the actual link distance.
//   const liveEField =
//     link.isValid && link.txEirpWatts !== null
//       ? calculateElectricField(link.txEirpWatts, link.distanceMeters)
//       : null;

//   const livePowerDensity =
//     link.isValid && link.txEirpWatts !== null
//       ? calculatePowerDensityUWCm2(link.txEirpWatts, link.distanceMeters)
//       : null;

//   // Estimate range using current directional TX/RX gains.
//   const liveMaxRange =
//     link.isValid && link.txGainDbi !== null && link.rxGainDbi !== null
//       ? calculateMaxCoverageRange(
//           link.tx.powerMilliwatts,
//           link.txGainDbi,
//           link.tx.frequencyMHz,
//           sens,
//           link.rxGainDbi,
//           rfEnvironment.weather,
//         )
//       : null;

//   // Link quality
//   let linkQuality = {
//     label: "Excellent",
//     color: "text-emerald-400",
//     bg: "bg-emerald-500/10 border-emerald-500/30",
//   };

//   if (!link.isValid) {
//     linkQuality = {
//       label:
//         link.issue === "near-field"
//           ? "Near-field"
//           : link.issue === "frequency-mismatch"
//             ? "Frequency Mismatch"
//             : "Link Unavailable",

//       color: "text-rose-400",
//       bg: "bg-rose-500/10 border-rose-500/30",
//     };
//   } else if ((linkMargin ?? 0) < 0) {
//     linkQuality = {
//       label: "Out of Range",
//       color: "text-rose-400",
//       bg: "bg-rose-500/10 border-rose-500/30",
//     };
//   } else if ((linkMargin ?? 0) < 6) {
//     linkQuality = {
//       label: "Marginal",
//       color: "text-amber-400",
//       bg: "bg-amber-500/10 border-amber-500/30",
//     };
//   } else if ((linkMargin ?? 0) < 15) {
//     linkQuality = {
//       label: "Good",
//       color: "text-sky-400",
//       bg: "bg-sky-500/10 border-sky-500/30",
//     };
//   }

//   let snrStyle = "text-emerald-300 bg-emerald-950/40 border-emerald-800/40";

//   if (snrDb === null || snrDb < 0) {
//     snrStyle = "text-rose-400 bg-rose-950/40 border-rose-800/40";
//   } else if (snrDb < 10) {
//     snrStyle = "text-amber-300 bg-amber-950/40 border-amber-800/40";
//   } else if (snrDb < 20) {
//     snrStyle = "text-sky-300 bg-sky-950/40 border-sky-800/40";
//   }

//   // // Get active antenna config
//   // const activeAntenna =
//   //   hoverData.antennaId === "antenna-1" ? antenna1 : antenna2;

//   // // Live recalculation based on current evalDistanceMeters and weather
//   // const { rssiDbm, fsplDb, atmosphericLossDb } = calculateReceivedPowerDbm(
//   //   activeAntenna.powerMilliwatts,
//   //   hoverData.dbiAtPoint,
//   //   0,
//   //   evalDistanceMeters,
//   //   activeAntenna.frequencyMHz,
//   //   rfEnvironment.weather,
//   // );

//   // const bwHz = rfEnvironment.bandwidthMHz * 1e6;
//   // const { snrDb, noiseFloorDbm, modulationGrade } = calculateSNR(
//   //   rssiDbm,
//   //   bwHz,
//   //   rfEnvironment.noiseFigureDb,
//   // );

//   // const liveEField = calculateElectricField(
//   //   hoverData.eirpWatts,
//   //   evalDistanceMeters,
//   // );
//   // const livePowerDensity = calculatePowerDensityUWCm2(
//   //   hoverData.eirpWatts,
//   //   evalDistanceMeters,
//   // );
//   // const liveMaxRange = calculateMaxCoverageRange(
//   //   activeAntenna.powerMilliwatts,
//   //   hoverData.dbiAtPoint,
//   //   activeAntenna.frequencyMHz,
//   //   hoverData.rxSensitivityDbm,
//   //   0,
//   //   rfEnvironment.weather,
//   // );

//   // // Link quality assessment
//   // const sens = hoverData.rxSensitivityDbm;
//   // const linkMargin = Math.round((rssiDbm - sens) * 10) / 10;

//   // let linkQuality = {
//   //   label: "Excellent",
//   //   color: "text-emerald-400",
//   //   bg: "bg-emerald-500/10 border-emerald-500/30",
//   // };
//   // if (linkMargin < 0) {
//   //   linkQuality = {
//   //     label: "Out of Range",
//   //     color: "text-rose-400",
//   //     bg: "bg-rose-500/10 border-rose-500/30",
//   //   };
//   // } else if (linkMargin < 6) {
//   //   linkQuality = {
//   //     label: "Marginal",
//   //     color: "text-amber-400",
//   //     bg: "bg-amber-500/10 border-amber-500/30",
//   //   };
//   // } else if (linkMargin < 15) {
//   //   linkQuality = {
//   //     label: "Good",
//   //     color: "text-sky-400",
//   //     bg: "bg-sky-500/10 border-sky-500/30",
//   //   };
//   // }

//   // let snrStyle = "text-emerald-300 bg-emerald-950/40 border-emerald-800/40";
//   // if (snrDb < 0) {
//   //   snrStyle = "text-rose-400 bg-rose-950/40 border-rose-800/40";
//   // } else if (snrDb < 10) {
//   //   snrStyle = "text-amber-300 bg-amber-950/40 border-amber-800/40";
//   // } else if (snrDb < 20) {
//   //   snrStyle = "text-sky-300 bg-sky-950/40 border-sky-800/40";
//   // }

//   return (
//     <div
//       onPointerEnter={() => setIsHoveringTooltip(true)}
//       onPointerLeave={() => setIsHoveringTooltip(false)}
//       className="absolute top-4 right-4 z-30 w-88 max-w-[calc(100vw-2rem)] bg-slate-900/95 backdrop-blur-xl border border-slate-700/80 rounded-2xl shadow-2xl p-4 transition-all duration-150 animate-in fade-in slide-in-from-top-2 pointer-events-auto"
//     >
//       {/* Header with Pin & Close Buttons */}
//       <div className="flex items-center justify-between pb-3 border-b border-slate-800/80">
//         <div className="flex items-center space-x-2">
//           <div
//             className="w-3.5 h-3.5 rounded-full shadow-sm"
//             style={{ backgroundColor: hoverData.color }}
//           />
//           <span className="font-semibold text-sm text-slate-100 tracking-wide">
//             {hoverData.antennaName}
//           </span>
//           {isInspectionPinned && (
//             <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/40 px-1.5 py-0.2 rounded font-mono flex items-center space-x-0.5">
//               <Lock className="w-2.5 h-2.5" />
//               <span>Pinned</span>
//             </span>
//           )}
//         </div>

//         <div className="flex items-center space-x-1.5">
//           <div
//             className={`px-2 py-0.5 rounded-full text-[11px] font-mono font-medium border ${linkQuality.bg} ${linkQuality.color}`}
//           >
//             {linkQuality.label}
//           </div>

//           {/* Pin Toggle Button */}
//           <button
//             onClick={() => setIsInspectionPinned(!isInspectionPinned)}
//             title={
//               isInspectionPinned
//                 ? "Unpin telemetry card (Return to hover mode)"
//                 : "Pin / Lock telemetry card"
//             }
//             className={`p-1 rounded-lg border transition-all ${
//               isInspectionPinned
//                 ? "bg-amber-500/20 text-amber-300 border-amber-500/50"
//                 : "bg-slate-800 text-slate-400 hover:text-slate-200 border-slate-700"
//             }`}
//           >
//             <Pin className="w-3.5 h-3.5" />
//           </button>

//           {/* Close Button */}
//           <button
//             onClick={() => {
//               setIsInspectionPinned(false);
//               setIsHoveringTooltip(false);
//               setHoverData(null);
//             }}
//             title="Close inspection card"
//             className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white border border-slate-700 transition-colors"
//           >
//             <X className="w-3.5 h-3.5" />
//           </button>
//         </div>
//       </div>

//       {/* Primary Highlights: Gain & Receiving RSSI */}
//       <div className="grid grid-cols-2 gap-2 mt-3">
//         {/* Realized dBi */}
//         <div className="bg-slate-950/70 rounded-xl p-2.5 border border-slate-800">
//           <div className="text-[10px] uppercase font-mono tracking-wider text-slate-400 flex items-center space-x-1">
//             <Zap className="w-3 h-3 text-amber-400" />
//             <span>Gain at Point</span>
//           </div>
//           <div className="mt-1 flex items-baseline space-x-1">
//             <span className="text-xl font-bold font-mono text-amber-300">
//               {hoverData.dbiAtPoint > 0
//                 ? `+${hoverData.dbiAtPoint}`
//                 : hoverData.dbiAtPoint}
//             </span>
//             <span className="text-xs font-mono text-slate-400">dBi</span>
//           </div>
//           <div className="text-[10px] text-slate-400 font-mono mt-0.5">
//             Rel: {(hoverData.relativeGainLinear * 100).toFixed(1)}%
//           </div>
//         </div>

//         {/* Signal Strength RSSI at Live Distance */}
//         <div className="bg-slate-950/70 rounded-xl p-2.5 border border-slate-800">
//           <div className="text-[10px] uppercase font-mono tracking-wider text-slate-400 flex items-center space-x-1">
//             <Radio className="w-3 h-3 text-sky-400" />
//             <span>Received RSSI</span>
//           </div>
//           <div className="mt-1 flex items-baseline space-x-1">
//             <span
//               className={`text-xl font-bold font-mono ${
//                 rssiDbm !== null && rssiDbm >= sens
//                   ? "text-sky-300"
//                   : "text-rose-400"
//               }`}
//             >
//               {rssiDbm === null ? "N/A" : rssiDbm.toFixed(1)}
//             </span>
//             <span className="text-xs font-mono text-slate-400">dBm</span>
//           </div>
//           <div className="text-[10px] text-slate-400 font-mono mt-0.5 flex items-center justify-between">
//             <span>@ {link.distanceMeters.toFixed(2)} m</span>

//             <span
//               className={
//                 linkMargin !== null && linkMargin >= 0
//                   ? "text-emerald-400"
//                   : "text-rose-400"
//               }
//             >
//               {linkMargin === null
//                 ? "N/A"
//                 : `${linkMargin >= 0 ? "+" : ""}${linkMargin.toFixed(1)} dB mar.`}
//             </span>
//           </div>
//         </div>
//       </div>

//       {/* SNR (Signal-to-Noise Ratio) & Modulation Grade */}
//       <div className="mt-2.5 bg-slate-950/80 rounded-xl p-2.5 border border-indigo-500/30">
//         <div className="flex items-center justify-between">
//           <div className="flex items-center space-x-1.5 text-slate-300 font-mono text-xs">
//             <BarChart2 className="w-3.5 h-3.5 text-indigo-400" />
//             <span className="font-semibold text-slate-100">
//               Signal-to-Noise Ratio (SNR)
//             </span>
//           </div>
//           <div
//             className={`px-2 py-0.5 rounded text-xs font-bold font-mono border ${snrStyle}`}
//           >
//             {snrDb === null
//               ? "N/A"
//               : `${snrDb > 0 ? "+" : ""}${snrDb.toFixed(1)} dB`}
//           </div>
//         </div>

//         <div className="mt-1.5 flex items-center justify-between text-[11px] font-mono text-slate-400">
//           <span className="flex items-center space-x-1">
//             <Cpu className="w-3 h-3 text-slate-400" />
//             <span>Modulation:</span>
//           </span>
//           <span className="font-medium text-emerald-300">
//             {modulationGrade}
//           </span>
//         </div>

//         <div className="mt-1 flex items-center justify-between text-[10px] font-mono text-slate-400 pt-1 border-t border-slate-800/60">
//           <span>
//             Noise Floor:{" "}
//             <strong className="text-slate-300">{noiseFloorDbm} dBm</strong>
//           </span>
//           <span>
//             BW:{" "}
//             <strong className="text-slate-300">
//               {rfEnvironment.bandwidthMHz} MHz
//             </strong>
//           </span>
//         </div>
//       </div>

//       {/* Interactive Receiving Distance Slider (Safe & Persistent to Interact With!) */}
//       {/* Actual TX-RX Distance */}

//       <div className="mt-2.5 bg-slate-950/70 rounded-xl p-2.5 border border-sky-500/30">
//         <div className="flex items-center justify-between text-xs font-mono text-slate-300">
//           <span className="flex items-center space-x-1.5">
//             <Compass className="w-3.5 h-3.5 text-sky-400" />
//             <span className="font-semibold text-slate-200">
//               TX-RX Separation
//             </span>
//           </span>

//           <span className="font-bold text-sky-300 bg-sky-950/80 px-2 py-0.5 rounded border border-sky-800/60">
//             {link.distanceMeters.toFixed(2)} m
//           </span>
//         </div>

//         <input
//           type="range"
//           min="1"
//           max="500"
//           step="1"
//           value={Math.min(500, Math.max(1, link.distanceMeters))}
//           onChange={(e) => setLinkDistanceMeters(Number(e.target.value))}
//           className="w-full mt-2 h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-sky-400"
//         />

//         <div className="flex justify-between text-[9px] font-mono text-slate-400 mt-1">
//           <span>1 m</span>
//           <span>250 m</span>
//           <span>500 m</span>
//         </div>
//       </div>

//       {/* Coverage Boundary Reach */}
//       <div className="mt-2.5 flex items-center justify-between bg-emerald-950/20 border border-emerald-500/20 rounded-xl p-2.5">
//         <div className="flex items-center space-x-2">
//           <div className="p-1 rounded-lg bg-emerald-500/20 text-emerald-400">
//             <ShieldCheck className="w-4 h-4" />
//           </div>
//           <div>
//             <div className="text-[11px] font-medium text-slate-200">
//               Max Usable Range
//             </div>
//             <div className="text-[9px] text-slate-400 font-mono">
//               Signal ≥ {sens} dBm (inc. Atmo)
//             </div>
//           </div>
//         </div>
//         <div className="text-right">
//           <div className="text-sm font-bold font-mono text-emerald-300">
//             {liveMaxRange === null
//               ? "N/A"
//               : liveMaxRange < 1000
//                 ? `${liveMaxRange.toFixed(1)} m`
//                 : `${(liveMaxRange / 1000).toFixed(2)} km`}
//           </div>
//         </div>
//       </div>

//       {/* Telemetry Breakdown Details */}
//       <div className="mt-2.5 pt-2 border-t border-slate-800/70 grid grid-cols-2 gap-y-1 text-[11px] font-mono text-slate-300">
//         <div className="text-slate-400">Angle (θ, φ):</div>
//         <div className="text-right text-slate-200">
//           {hoverData.thetaDeg}° elev, {hoverData.phiDeg}° az
//         </div>

//         <div className="text-slate-400">Free-Space Loss (FSPL):</div>
//         <div className="text-right text-slate-200">
//           {fsplDb === null ? "N/A" : `${fsplDb.toFixed(1)} dB`}
//         </div>

//         <div className="text-slate-400 flex items-center space-x-1">
//           <CloudRain className="w-3 h-3 text-cyan-400" />
//           <span>Atmo Loss (O₂+H₂O):</span>
//         </div>
//         <div className="text-right text-cyan-300 font-semibold">
//           {atmosphericLossDb === null
//             ? "N/A"
//             : `${atmosphericLossDb.toFixed(2)} dB`}
//         </div>

//         <div className="text-slate-400">Electric Field E:</div>
//         <div className="text-right text-slate-200">
//           {liveEField === null
//             ? "N/A"
//             : liveEField < 0.01
//               ? `${(liveEField * 1000).toFixed(1)} mV/m`
//               : `${liveEField.toFixed(2)} V/m`}
//         </div>

//         <div className="text-slate-400">Power Density S:</div>
//         <div className="text-right text-slate-200">
//           {livePowerDensity === null
//             ? "N/A"
//             : livePowerDensity < 0.001
//               ? `${(livePowerDensity * 1000).toFixed(2)} nW/cm²`
//               : `${livePowerDensity.toFixed(3)} µW/cm²`}
//         </div>

//         <div className="text-slate-400">EIRP Radiated:</div>
//         <div className="text-right text-slate-200">
//           {hoverData.eirpDbm} dBm ({hoverData.eirpWatts} W)
//         </div>
//       </div>
//     </div>
//   );
// };
import React from "react";
import { useAntennaStore } from "../store/antennaStore";
import {
  calculateElectricField,
  calculatePowerDensityUWCm2,
} from "../math/rfPhysics";
import { calculateAntennaPairLinkBudget } from "../math/linkBudget";
import {
  Zap,
  Radio,
  Compass,
  ShieldCheck,
  CloudRain,
  Cpu,
  BarChart2,
  Pin,
  X,
  Lock,
} from "lucide-react";

export const RadiationTooltip: React.FC = () => {
  const hoverData = useAntennaStore((s) => s.hoverData);
  const setHoverData = useAntennaStore((s) => s.setHoverData);
  const rfEnvironment = useAntennaStore((s) => s.rfEnvironment);
  const rxSensitivityDbm = useAntennaStore((s) => s.rxSensitivityDbm);
  const setLinkDistanceMeters = useAntennaStore((s) => s.setLinkDistanceMeters);

  const antenna1 = useAntennaStore((s) => s.antenna1);
  const antenna2 = useAntennaStore((s) => s.antenna2);
  const isInspectionPinned = useAntennaStore((s) => s.isInspectionPinned);
  const setIsInspectionPinned = useAntennaStore((s) => s.setIsInspectionPinned);
  const setIsHoveringTooltip = useAntennaStore((s) => s.setIsHoveringTooltip);

  if (!hoverData) {
    return (
      <div className="absolute top-4 right-4 pointer-events-none hidden md:flex items-center space-x-2 bg-slate-900/70 backdrop-blur-md px-3.5 py-2 rounded-xl border border-slate-800 text-xs text-slate-400">
        <Radio className="w-4 h-4 text-sky-400 animate-pulse" />
        <span>
          Hover or click any 3D radiation lobe point to inspect & adjust
          receiver distance
        </span>
      </div>
    );
  }

  // Calculate the actual communication link.
  const link = calculateAntennaPairLinkBudget(
    antenna1,
    antenna2,
    rfEnvironment,
    rxSensitivityDbm,
  );

  // Pair-level receiving metrics.
  const rssiDbm = link.receivedPowerDbm;
  const snrDb = link.snrDb;
  const noiseFloorDbm = link.noiseFloorDbm;
  const modulationGrade = link.modulationGrade;

  const fsplDb = link.fsplDb;
  const atmosphericLossDb = link.atmosphericLossDb;

  const sens = rxSensitivityDbm;
  const linkMargin = link.fadeMarginDb;

  // Electric field and power density at the actual link distance.
  const liveEField =
    link.isValid && link.txEirpWatts !== null
      ? calculateElectricField(link.txEirpWatts, link.distanceMeters)
      : null;

  const livePowerDensity =
    link.isValid && link.txEirpWatts !== null
      ? calculatePowerDensityUWCm2(link.txEirpWatts, link.distanceMeters)
      : null;

  const liveMaxRange = hoverData.coverageMaxMeters;

  // Link quality
  let linkQuality = {
    label: "Excellent",
    color: "text-emerald-400",
    bg: "bg-emerald-500/10 border-emerald-500/30",
  };

  if (!link.isValid) {
    linkQuality = {
      label:
        link.issue === "near-field"
          ? "Near-field"
          : link.issue === "frequency-mismatch"
            ? "Frequency Mismatch"
            : "Link Unavailable",
      color: "text-rose-400",
      bg: "bg-rose-500/10 border-rose-500/30",
    };
  } else if ((linkMargin ?? 0) < 0) {
    linkQuality = {
      label: "Out of Range",
      color: "text-rose-400",
      bg: "bg-rose-500/10 border-rose-500/30",
    };
  } else if ((linkMargin ?? 0) < 6) {
    linkQuality = {
      label: "Marginal",
      color: "text-amber-400",
      bg: "bg-amber-500/10 border-amber-500/30",
    };
  } else if ((linkMargin ?? 0) < 15) {
    linkQuality = {
      label: "Good",
      color: "text-sky-400",
      bg: "bg-sky-500/10 border-sky-500/30",
    };
  }

  let snrStyle = "text-emerald-300 bg-emerald-950/40 border-emerald-800/40";

  if (snrDb === null || snrDb < 0) {
    snrStyle = "text-rose-400 bg-rose-950/40 border-rose-800/40";
  } else if (snrDb < 10) {
    snrStyle = "text-amber-300 bg-amber-950/40 border-amber-800/40";
  } else if (snrDb < 20) {
    snrStyle = "text-sky-300 bg-sky-950/40 border-sky-800/40";
  }

  return (
    <div
      onPointerEnter={() => setIsHoveringTooltip(true)}
      onPointerLeave={() => setIsHoveringTooltip(false)}
      className="absolute top-4 right-4 z-30 w-88 max-w-[calc(100vw-2rem)] bg-slate-900/95 backdrop-blur-xl border border-slate-700/80 rounded-2xl shadow-2xl p-4 transition-all duration-150 animate-in fade-in slide-in-from-top-2 pointer-events-auto"
    >
      {/* Header with Pin & Close Buttons */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800/80">
        <div className="flex items-center space-x-2">
          <div
            className="w-3.5 h-3.5 rounded-full shadow-sm"
            style={{ backgroundColor: hoverData.color }}
          />
          <span className="font-semibold text-sm text-slate-100 tracking-wide">
            {hoverData.antennaName}
          </span>
          {isInspectionPinned && (
            <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/40 px-1.5 py-0.2 rounded font-mono flex items-center space-x-0.5">
              <Lock className="w-2.5 h-2.5" />
              <span>Pinned</span>
            </span>
          )}
        </div>

        <div className="flex items-center space-x-1.5">
          <div
            className={`px-2 py-0.5 rounded-full text-[11px] font-mono font-medium border ${linkQuality.bg} ${linkQuality.color}`}
          >
            {linkQuality.label}
          </div>

          <button
            onClick={() => setIsInspectionPinned(!isInspectionPinned)}
            title={
              isInspectionPinned
                ? "Unpin telemetry card (Return to hover mode)"
                : "Pin / Lock telemetry card"
            }
            className={`p-1 rounded-lg border transition-all ${
              isInspectionPinned
                ? "bg-amber-500/20 text-amber-300 border-amber-500/50"
                : "bg-slate-800 text-slate-400 hover:text-slate-200 border-slate-700"
            }`}
          >
            <Pin className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => {
              setIsInspectionPinned(false);
              setIsHoveringTooltip(false);
              setHoverData(null);
            }}
            title="Close inspection card"
            className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white border border-slate-700 transition-colors"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Primary Highlights: Gain & Receiving RSSI */}
      <div className="grid grid-cols-2 gap-2 mt-3">
        <div className="bg-slate-950/70 rounded-xl p-2.5 border border-slate-800">
          <div className="text-[10px] uppercase font-mono tracking-wider text-slate-400 flex items-center space-x-1">
            <Zap className="w-3 h-3 text-amber-400" />
            <span>Gain at Point</span>
          </div>
          <div className="mt-1 flex items-baseline space-x-1">
            <span className="text-xl font-bold font-mono text-amber-300">
              {hoverData.dbiAtPoint > 0
                ? `+${hoverData.dbiAtPoint}`
                : hoverData.dbiAtPoint}
            </span>
            <span className="text-xs font-mono text-slate-400">dBi</span>
          </div>
          <div className="text-[10px] text-slate-400 font-mono mt-0.5">
            Rel: {(hoverData.relativeGainLinear * 100).toFixed(1)}%
          </div>
        </div>

        <div className="bg-slate-950/70 rounded-xl p-2.5 border border-slate-800">
          <div className="text-[10px] uppercase font-mono tracking-wider text-slate-400 flex items-center space-x-1">
            <Radio className="w-3 h-3 text-sky-400" />
            <span>Received RSSI</span>
          </div>
          <div className="mt-1 flex items-baseline space-x-1">
            <span
              className={`text-xl font-bold font-mono ${
                rssiDbm !== null && rssiDbm >= sens
                  ? "text-sky-300"
                  : "text-rose-400"
              }`}
            >
              {rssiDbm === null ? "N/A" : rssiDbm.toFixed(1)}
            </span>
            <span className="text-xs font-mono text-slate-400">dBm</span>
          </div>
          <div className="text-[10px] text-slate-400 font-mono mt-0.5 flex items-center justify-between">
            <span>@ {link.distanceMeters.toFixed(1)} m</span>
            <span
              className={
                linkMargin !== null && linkMargin >= 0
                  ? "text-emerald-400"
                  : "text-rose-400"
              }
            >
              {linkMargin === null
                ? "N/A"
                : `${linkMargin >= 0 ? "+" : ""}${linkMargin.toFixed(1)} dB mar.`}
            </span>
          </div>
        </div>
      </div>

      {/* SNR & Modulation Grade */}
      <div className="mt-2.5 bg-slate-950/80 rounded-xl p-2.5 border border-indigo-500/30">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-1.5 text-slate-300 font-mono text-xs">
            <BarChart2 className="w-3.5 h-3.5 text-indigo-400" />
            <span className="font-semibold text-slate-100">
              Signal-to-Noise Ratio (SNR)
            </span>
          </div>
          <div
            className={`px-2 py-0.5 rounded text-xs font-bold font-mono border ${snrStyle}`}
          >
            {snrDb === null
              ? "N/A"
              : `${snrDb > 0 ? "+" : ""}${snrDb.toFixed(1)} dB`}
          </div>
        </div>

        <div className="mt-1.5 flex items-center justify-between text-[11px] font-mono text-slate-400">
          <span className="flex items-center space-x-1">
            <Cpu className="w-3 h-3 text-slate-400" />
            <span>Modulation:</span>
          </span>
          <span className="font-medium text-emerald-300">
            {modulationGrade}
          </span>
        </div>

        <div className="mt-1 flex items-center justify-between text-[10px] font-mono text-slate-400 pt-1 border-t border-slate-800/60">
          <span>
            Noise Floor:{" "}
            <strong className="text-slate-300">{noiseFloorDbm} dBm</strong>
          </span>
          <span>
            BW:{" "}
            <strong className="text-slate-300">
              {rfEnvironment.bandwidthMHz} MHz
            </strong>
          </span>
        </div>
      </div>

      {/* Expanded TX-RX Separation Slider (Up to 50,000 meters / 50 km) */}
      <div className="mt-2.5 bg-slate-950/70 rounded-xl p-2.5 border border-sky-500/30">
        <div className="flex items-center justify-between text-xs font-mono text-slate-300">
          <span className="flex items-center space-x-1.5">
            <Compass className="w-3.5 h-3.5 text-sky-400" />
            <span className="font-semibold text-slate-200">
              TX-RX Separation
            </span>
          </span>

          <span className="font-bold text-sky-300 bg-sky-950/80 px-2 py-0.5 rounded border border-sky-800/60">
            {link.distanceMeters >= 1000
              ? `${(link.distanceMeters / 1000).toFixed(2)} km`
              : `${link.distanceMeters.toFixed(1)} m`}
          </span>
        </div>

        <input
          type="range"
          min="1"
          max="50000"
          step="10"
          value={Math.min(50000, Math.max(1, link.distanceMeters))}
          onChange={(e) => setLinkDistanceMeters(Number(e.target.value))}
          className="w-full mt-2 h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-sky-400"
        />

        <div className="flex justify-between text-[9px] font-mono text-slate-400 mt-1">
          <span>1 m</span>
          <span>25 km</span>
          <span>50 km</span>
        </div>
      </div>

      {/* Coverage Boundary Reach */}
      <div className="mt-2.5 flex items-center justify-between bg-emerald-950/20 border border-emerald-500/20 rounded-xl p-2.5">
        <div className="flex items-center space-x-2">
          <div className="p-1 rounded-lg bg-emerald-500/20 text-emerald-400">
            <ShieldCheck className="w-4 h-4" />
          </div>
          <div>
            <div className="text-[11px] font-medium text-slate-200">
              Max Usable Range
            </div>
            <div className="text-[9px] text-slate-400 font-mono">
              Signal ≥ {sens} dBm (inc. Atmo)
            </div>
          </div>
        </div>
        <div className="text-right">
          <div className="text-sm font-bold font-mono text-emerald-300">
            {liveMaxRange === null
              ? "N/A"
              : liveMaxRange < 1000
                ? `${liveMaxRange.toFixed(1)} m`
                : `${(liveMaxRange / 1000).toFixed(2)} km`}
          </div>
        </div>
      </div>

      {/* Telemetry Breakdown Details */}
      <div className="mt-2.5 pt-2 border-t border-slate-800/70 grid grid-cols-2 gap-y-1 text-[11px] font-mono text-slate-300">
        <div className="text-slate-400">Angle (θ, φ):</div>
        <div className="text-right text-slate-200">
          {hoverData.thetaDeg}° elev, {hoverData.phiDeg}° az
        </div>

        <div className="text-slate-400">Free-Space Loss (FSPL):</div>
        <div className="text-right text-slate-200">
          {fsplDb === null ? "N/A" : `${fsplDb.toFixed(1)} dB`}
        </div>

        <div className="text-slate-400 flex items-center space-x-1">
          <CloudRain className="w-3 h-3 text-cyan-400" />
          <span>Atmo Loss (O₂+H₂O):</span>
        </div>
        <div className="text-right text-cyan-300 font-semibold">
          {atmosphericLossDb === null
            ? "N/A"
            : `${atmosphericLossDb.toFixed(2)} dB`}
        </div>

        <div className="text-slate-400">Electric Field E:</div>
        <div className="text-right text-slate-200">
          {liveEField === null
            ? "N/A"
            : liveEField < 0.01
              ? `${(liveEField * 1000).toFixed(1)} mV/m`
              : `${liveEField.toFixed(2)} V/m`}
        </div>

        <div className="text-slate-400">Power Density S:</div>
        <div className="text-right text-slate-200">
          {livePowerDensity === null
            ? "N/A"
            : livePowerDensity < 0.001
              ? `${(livePowerDensity * 1000).toFixed(2)} nW/cm²`
              : `${livePowerDensity.toFixed(3)} µW/cm²`}
        </div>

        <div className="text-slate-400">EIRP Radiated:</div>
        <div className="text-right text-slate-200">
          {hoverData.eirpDbm} dBm ({hoverData.eirpWatts} W)
        </div>
      </div>
    </div>
  );
};
