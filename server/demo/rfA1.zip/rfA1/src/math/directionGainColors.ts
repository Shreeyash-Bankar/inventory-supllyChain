import * as THREE from "three";
import type { AntennaConfig } from "../types/antenna";

export interface GainColorScale {
  minDbi: number;
  maxDbi: number;
}

/**
 * Build ONE absolute dBi scale for both antenna lobes.
 * Each radiation-pattern model floors its relative gain at -35 dB below
 * configured peak gain, so the lowest end is based on the lower antenna peak.
 */
export function getSharedGainColorScale(
  antennaA: AntennaConfig,
  antennaB: AntennaConfig,
): GainColorScale {
  const minPeakDbi = Math.min(antennaA.gainDbi, antennaB.gainDbi);
  const maxPeakDbi = Math.max(antennaA.gainDbi, antennaB.gainDbi);

  return {
    minDbi: minPeakDbi - 35,
    maxDbi: maxPeakDbi,
  };
}

/**
 * Map a real directional gain value to a fixed blue -> cyan -> green scale.
 * Blue is always the low end; green is always the high end.
 */
export function getDirectionalGainColor(
  gainDbi: number,
  scale: GainColorScale,
): THREE.Color {
  const span = Math.max(0.001, scale.maxDbi - scale.minDbi);
  const t = THREE.MathUtils.clamp((gainDbi - scale.minDbi) / span, 0, 1);

  const blue = new THREE.Color("#2563eb");
  const cyan = new THREE.Color("#06b6d4");
  const green = new THREE.Color("#22c55e");

  if (t <= 0.5) {
    return blue.lerp(cyan, t * 2);
  }

  return cyan.lerp(green, (t - 0.5) * 2);
}
