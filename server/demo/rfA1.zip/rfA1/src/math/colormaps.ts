import * as THREE from 'three';
import { ColormapType } from '../types/antenna';

export function getColorFromColormap(valNorm: number, type: ColormapType = 'turbo'): THREE.Color {
  const t = Math.max(0, Math.min(1, valNorm));

  switch (type) {
    case 'turbo': {
      // Approximate Turbo colormap polynomial
      const kRedVec4 = [0.13572138, 4.61539260, -42.66032258, 132.13108234];
      const kGreenVec4 = [0.09140261, 2.19418839, 4.84296658, -14.18503333];
      const kBlueVec4 = [0.10667330, 12.64194608, -60.58204836, 110.36276771];
      const kRedVec2 = [-152.94239396, 59.28637943];
      const kGreenVec2 = [4.27729857, 2.82956604];
      const kBlueVec2 = [-89.90310912, 27.34824973];

      const v4 = [1.0, t, t * t, t * t * t];
      const v2 = [v4[2] * v4[1], v4[3] * v4[1]];

      let r = (kRedVec4[0] * v4[0] + kRedVec4[1] * v4[1] + kRedVec4[2] * v4[2] + kRedVec4[3] * v4[3]) +
              (kRedVec2[0] * v2[0] + kRedVec2[1] * v2[1]);
      let g = (kGreenVec4[0] * v4[0] + kGreenVec4[1] * v4[1] + kGreenVec4[2] * v4[2] + kGreenVec4[3] * v4[3]) +
              (kGreenVec2[0] * v2[0] + kGreenVec2[1] * v2[1]);
      let b = (kBlueVec4[0] * v4[0] + kBlueVec4[1] * v4[1] + kBlueVec4[2] * v4[2] + kBlueVec4[3] * v4[3]) +
              (kBlueVec2[0] * v2[0] + kBlueVec2[1] * v2[1]);

      return new THREE.Color(
        Math.max(0, Math.min(1, r)),
        Math.max(0, Math.min(1, g)),
        Math.max(0, Math.min(1, b))
      );
    }

    case 'jet': {
      // Classic Jet: Blue -> Cyan -> Green -> Yellow -> Red
      let r = Math.min(1, Math.max(0, 1.5 - Math.abs(t * 4 - 3)));
      let g = Math.min(1, Math.max(0, 1.5 - Math.abs(t * 4 - 2)));
      let b = Math.min(1, Math.max(0, 1.5 - Math.abs(t * 4 - 1)));
      return new THREE.Color(r, g, b);
    }

    case 'viridis': {
      // Viridis colormap approximation
      const r = Math.max(0, Math.min(1, -0.009 + 0.38 * t + 0.62 * t * t));
      const g = Math.max(0, Math.min(1, 0.05 + 1.25 * t - 0.45 * t * t));
      const b = Math.max(0, Math.min(1, 0.35 + 0.8 * (1 - t) - 0.7 * Math.pow(t - 0.5, 2)));
      return new THREE.Color(r, g, b);
    }

    case 'plasma': {
      const r = Math.max(0, Math.min(1, 0.05 + 1.2 * t - 0.3 * t * t));
      const g = Math.max(0, Math.min(1, 0.01 + 0.2 * t + 0.8 * t * t * t));
      const b = Math.max(0, Math.min(1, 0.5 + 0.5 * Math.sin(t * Math.PI * 0.8)));
      return new THREE.Color(r, g, b);
    }

    case 'electric':
    default: {
      // Deep blue/purple -> Cyan -> Bright Yellow -> White
      let r = 0, g = 0, b = 0;
      if (t < 0.25) {
        b = t * 4;
      } else if (t < 0.5) {
        b = 1;
        g = (t - 0.25) * 4;
      } else if (t < 0.75) {
        g = 1;
        b = 1 - (t - 0.5) * 4;
        r = (t - 0.5) * 4;
      } else {
        r = 1;
        g = 1;
        b = (t - 0.75) * 4;
      }
      return new THREE.Color(r, g, b);
    }
  }
}
