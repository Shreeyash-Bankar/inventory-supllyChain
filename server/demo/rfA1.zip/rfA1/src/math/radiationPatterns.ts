// import { AntennaConfig } from "../types/antenna";
// import { getWavelengthMm, getVelocityFactor } from "./rfPhysics";

// export interface PatternSample {
//   gainDbi: number;
//   relativeLinear: number; // 0 to 1
//   radius: number; // distance from origin for 3D mesh vertex
// }

// /**
//  * Computes the radiation field magnitude F(theta, phi) in [0, 1]
//  * theta: polar angle from Y axis (vertical) in radians [0, PI]
//  * phi: azimuth angle in XZ plane in radians [-PI, PI]
//  */
// export function calculateRadiationPattern(
//   theta: number,
//   phi: number,
//   config: AntennaConfig,
// ): PatternSample {
//   const { type, lengthMm, frequencyMHz, diameterMm, gainDbi } = config;
//   const lambdaMm = getWavelengthMm(frequencyMHz);
//   const k = (2 * Math.PI) / Math.max(0.1, lambdaMm);
//   const vf = getVelocityFactor(lengthMm, diameterMm);
//   const effectiveLengthMm = lengthMm * vf;
//   const kH = (k * effectiveLengthMm) / 2; // half-length phase parameter

//   let field = 0;

//   switch (type) {
//     case "dipole": {
//       // Dipole wire along Y-axis (theta is angle from wire axis):
//       // F(theta) = | (cos(kH*cos(theta)) - cos(kH)) / sin(theta) |
//       const sinT = Math.sin(theta);
//       const cosT = Math.cos(theta);

//       if (Math.abs(sinT) < 1e-4) {
//         // Null along the wire ends, but thick elements have finite null depth (~ -32 dB)
//         const fatLeak = Math.min(
//           0.04,
//           (diameterMm / Math.max(10, lengthMm)) * 0.15,
//         );
//         field = fatLeak;
//       } else {
//         const num = Math.cos(kH * cosT) - Math.cos(kH);
//         const raw = Math.abs(num / sinT);

//         // Accurate normalization across electrical lengths:
//         // Peak is at theta = PI/2 if kH <= PI/2, else peaks at cos(theta) = +/- sqrt(...)
//         let peakEst = 1 - Math.cos(kH);
//         if (kH > Math.PI * 0.65) {
//           // Multi-lobe harmonic regime (L > lambda): peak splits
//           peakEst = Math.max(0.3, 1 + Math.abs(Math.cos(kH)));
//         }
//         field = raw / Math.max(0.05, peakEst);

//         // Fat antenna effect: thick wire softens sharp nulls
//         const fatSoftening = Math.min(
//           0.12,
//           diameterMm / (2.5 * Math.max(5, lengthMm)),
//         );
//         field = (1 - fatSoftening) * field + fatSoftening * Math.pow(sinT, 2);
//       }
//       break;
//     }

//     case "monopole": {
//       // Vertical whip along +Y over reflective ground plane in XZ (Y >= 0)
//       const sinT = Math.sin(theta);
//       const cosT = Math.cos(theta);

//       if (cosT < -0.01) {
//         // Below ground plane (theta > PI/2): ground shielding with edge diffraction
//         const groundRadiusMm = Math.max(40, diameterMm * 4);
//         const groundLambda = groundRadiusMm / lambdaMm;
//         const shadowDecay = Math.exp(cosT * (3.5 + groundLambda * 2.5));
//         field = 0.04 * shadowDecay;
//       } else {
//         // Upper hemisphere with ground reflection reinforcement
//         const halfImageKH = kH * 2;
//         const num = Math.cos(halfImageKH * cosT) - Math.cos(halfImageKH);
//         const raw = Math.abs(num / Math.max(1e-4, sinT));
//         const peakEst = Math.max(0.05, 1 - Math.cos(halfImageKH));
//         field = raw / peakEst;
//       }
//       break;
//     }

//     case "patch": {
//       // Microstrip Patch Antenna pointing along +X axis
//       // Coordinates: x = sin(theta)*cos(phi), y = cos(theta), z = sin(theta)*sin(phi)
//       const x = Math.sin(theta) * Math.cos(phi);
//       const y = Math.cos(theta);
//       const z = Math.sin(theta) * Math.sin(phi);

//       const cosAlpha = Math.max(-1, Math.min(1, x));
//       const alpha = Math.acos(cosAlpha);

//       if (x >= -0.05) {
//         // Forward hemisphere: realistic Cavity Model with E-plane (Y) narrower than H-plane (Z)
//         const alphaE = Math.abs(Math.atan2(y, Math.max(0.01, x))); // E-plane angle
//         const alphaH = Math.abs(Math.atan2(z, Math.max(0.01, x))); // H-plane angle

//         // E-plane factor: cos(alphaE)^m, H-plane factor: cos(alphaH)^n
//         const gainExp = Math.max(1.2, Math.pow(10, (gainDbi - 2.5) / 10));
//         const fE = Math.pow(Math.max(0, Math.cos(alphaE)), gainExp * 1.3);
//         const fH = Math.pow(Math.max(0, Math.cos(alphaH)), gainExp * 0.85);

//         // Combined pattern with smooth edge rolloff
//         field = fE * fH;
//       } else {
//         // Backlobe: Front-to-Back ratio typically ~ 20 dB (0.10 linear)
//         const ftbLinear = Math.pow(10, -20 / 20);
//         field = ftbLinear * Math.pow(Math.abs(Math.cos(alpha)), 1.8);
//       }
//       break;
//     }

//     case "yagi": {
//       // Yagi-Uda Array pointing along +X
//       const x = Math.sin(theta) * Math.cos(phi);
//       const cosAlpha = Math.max(-1, Math.min(1, x));
//       const alpha = Math.acos(cosAlpha);

//       const numDirectors = Math.max(
//         3,
//         Math.min(16, Math.round(lengthMm / (lambdaMm * 0.28))),
//       );
//       const mainBeamExp = Math.max(2.5, numDirectors * 1.1);

//       if (alpha <= Math.PI / 2) {
//         // Main forward pencil beam
//         const main = Math.pow(Math.cos(alpha), mainBeamExp);
//         // Realistic Array Factor Sidelobes (1st sidelobe at -13.5 dB, 2nd at -18 dB)
//         const u = numDirectors * Math.sin(alpha);
//         const sidelobes =
//           0.16 * Math.pow(Math.sin(u) / Math.max(1, u), 2) * Math.sin(alpha);
//         field = Math.max(0.015, main + sidelobes);
//       } else {
//         // Rear lobe (Front-to-Back ratio ~ 22 dB)
//         const ftbLinear = Math.pow(10, -22 / 20);
//         field = ftbLinear * Math.pow(Math.abs(Math.cos(alpha)), 2.2);
//       }
//       break;
//     }

//     case "horn": {
//       // Pyramidal Horn pointing along +X
//       const x = Math.sin(theta) * Math.cos(phi);
//       const y = Math.cos(theta);
//       const z = Math.sin(theta) * Math.sin(phi);

//       const cosAlpha = Math.max(-1, Math.min(1, x));
//       const alpha = Math.acos(cosAlpha);

//       if (x >= 0) {
//         // E-plane and H-plane aperture illumination
//         const bAperture = Math.max(1.0, (diameterMm * 0.8) / lambdaMm);
//         const aAperture = Math.max(1.2, (diameterMm * 1.2) / lambdaMm);

//         const uE =
//           Math.PI * bAperture * (y / Math.max(0.1, Math.sqrt(x * x + y * y)));
//         const uH =
//           Math.PI * aAperture * (z / Math.max(0.1, Math.sqrt(x * x + z * z)));

//         const fE = Math.abs(uE) > 1e-3 ? Math.sin(uE) / uE : 1.0;
//         const fH =
//           Math.abs(Math.PI * Math.PI - 4 * uH * uH) > 1e-3
//             ? Math.cos(uH) / (1 - (4 * uH * uH) / (Math.PI * Math.PI))
//             : 1.0;

//         const combined = Math.abs(fE * fH);
//         const gainExp = Math.max(2.0, Math.pow(10, (gainDbi - 10) / 10));
//         field = Math.pow(combined, gainExp * 0.35);
//       } else {
//         // Rear spillover of horn flange (~ -28 dB)
//         const rearLinear = Math.pow(10, -28 / 20);
//         field = rearLinear * Math.pow(Math.abs(Math.cos(alpha)), 1.5);
//       }
//       break;
//     }

//     case "helical": {
//       // Axial mode helical antenna along +X
//       const x = Math.sin(theta) * Math.cos(phi);
//       const cosAlpha = Math.max(-1, Math.min(1, x));
//       if (cosAlpha >= 0) {
//         const turns = Math.max(4, Math.round(lengthMm / (lambdaMm * 0.25)));
//         field = Math.pow(cosAlpha, turns * 0.45);
//       } else {
//         field = 0.05 * Math.pow(Math.abs(cosAlpha), 1.5);
//       }
//       break;
//     }

//     case "isotropic":
//     default: {
//       field = 1.0;
//       break;
//     }
//   }

//   // Realistic dynamic range floor (-35 dB below peak directivity)
//   const relativeLinear = Math.min(1.0, Math.max(0.015, field));
//   const minGainFloor = -35;
//   const relativeDb = Math.max(minGainFloor, 20 * Math.log10(relativeLinear));
//   const gainDbiAtPoint = Math.round((gainDbi + relativeDb) * 100) / 100;

//   // Lobe 3D mesh radius deformation
//   const minRadius = 0.18;
//   const maxRadius = 2.4;
//   const radius =
//     minRadius + (maxRadius - minRadius) * Math.pow(relativeLinear, 0.82);

//   return {
//     gainDbi: gainDbiAtPoint,
//     relativeLinear,
//     radius,
//   };
// }
import { AntennaConfig } from "../types/antenna";
import { getWavelengthMm, getVelocityFactor } from "./rfPhysics";

export interface PatternSample {
  gainDbi: number;
  /** Normalized electric-field magnitude (not power). */
  relativeLinear: number;
  /** Normalized display radius; this is not a link-coverage distance. */
  radius: number;
}

const clamp01 = (value: number) => Math.max(0, Math.min(1, value));

/**
 * Thin-wire sinusoidal-current pattern, with theta measured from the wire
 * axis (+Y). A cached numerical peak keeps the pattern normalized to 1.
 */
function thinWireField(theta: number, kHalfLength: number): number {
  const sinTheta = Math.sin(theta);
  if (Math.abs(sinTheta) < 1e-8) return 0;
  return Math.abs(
    (Math.cos(kHalfLength * Math.cos(theta)) - Math.cos(kHalfLength)) /
      sinTheta,
  );
}

const peakCache = new Map<string, number>();
function thinWirePeak(
  type: "dipole" | "monopole",
  kHalfLength: number,
): number {
  const key = `${type}:${kHalfLength.toFixed(8)}`;
  const cached = peakCache.get(key);
  if (cached !== undefined) return cached;
  let peak = 0;
  const end = type === "monopole" ? Math.PI / 2 : Math.PI;
  for (let i = 0; i <= 720; i++) {
    const theta = (i / 720) * end;
    peak = Math.max(peak, thinWireField(theta, kHalfLength));
  }
  const safePeak = peak > 1e-12 ? peak : 1;
  if (peakCache.size > 512) peakCache.clear();
  peakCache.set(key, safePeak);
  return safePeak;
}

/**
 * Pattern direction convention matches the scene: theta is polar angle from
 * local +Y and phi is azimuth in XZ. Patch/Yagi/horn point +X; the physical
 * helical model is built along +Y, so its axial beam is also +Y.
 *
 * These are engineering approximations, not full-wave EM solutions. In
 * particular patch/Yagi/horn/helical models need more geometry/feed/current
 * parameters before their patterns can be treated as design-grade results.
 */
export function calculateRadiationPattern(
  theta: number,
  phi: number,
  config: AntennaConfig,
): PatternSample {
  const { type, lengthMm, frequencyMHz, diameterMm, gainDbi } = config;
  const wavelengthMm = getWavelengthMm(frequencyMHz);
  if (
    !(wavelengthMm > 0) ||
    !Number.isFinite(theta) ||
    !Number.isFinite(phi) ||
    !Number.isFinite(gainDbi)
  ) {
    return { gainDbi: -Infinity, relativeLinear: 0, radius: 0.18 };
  }

  const k = (2 * Math.PI) / wavelengthMm;
  const shortening = getVelocityFactor(lengthMm, diameterMm);
  const effectiveLengthMm = Math.max(0, lengthMm) * shortening;
  const kHalfLength = (k * effectiveLengthMm) / 2;
  const sinTheta = Math.sin(theta);
  const cosTheta = Math.cos(theta);
  const x = sinTheta * Math.cos(phi);
  const y = cosTheta;
  const z = sinTheta * Math.sin(phi);
  let field = 0;

  switch (type) {
    case "dipole": {
      const peak = thinWirePeak("dipole", kHalfLength);
      field = thinWireField(theta, kHalfLength) / peak;
      break;
    }
    case "monopole": {
      // Ideal infinite PEC ground plane: no radiation into the lower hemisphere.
      if (y < 0) {
        field = 0;
        break;
      }
      // Image theory: a monopole of height L has the upper-hemisphere pattern
      // of a centre-fed dipole of total length 2L (k * L in this expression).
      const imageParameter = k * effectiveLengthMm;
      const peak = thinWirePeak("monopole", imageParameter);
      field = thinWireField(theta, imageParameter) / peak;
      break;
    }
    case "patch": {
      // Broadside patch approximation, main beam along local +X.
      const alphaE = Math.atan2(Math.abs(y), Math.max(1e-9, Math.abs(x)));
      const alphaH = Math.atan2(Math.abs(z), Math.max(1e-9, Math.abs(x)));
      const exponent = Math.max(1.2, 10 ** ((gainDbi - 2.5) / 10));
      if (x >= 0) {
        field =
          Math.cos(alphaE) ** (exponent * 1.3) *
          Math.cos(alphaH) ** (exponent * 0.85);
      } else {
        field = 10 ** (-20 / 20) * Math.abs(x) ** 1.8;
      }
      break;
    }
    case "yagi": {
      // Simplified forward-array envelope. Element currents and spacings are
      // not represented by the current AntennaConfig, so sidelobes are indicative.
      const alpha = Math.acos(Math.max(-1, Math.min(1, x)));
      const estimatedDirectors = Math.max(
        1,
        Math.min(16, Math.round(lengthMm / (wavelengthMm * 0.28))),
      );
      const beamExponent = Math.max(2.5, estimatedDirectors * 1.1);
      if (x >= 0) {
        const main = Math.cos(alpha) ** beamExponent;
        const u = estimatedDirectors * Math.sin(alpha);
        const sinc = Math.abs(u) < 1e-8 ? 1 : Math.sin(u) / u;
        const sidelobes = 0.16 * sinc ** 2 * Math.sin(alpha);
        field = Math.min(1, main + sidelobes);
      } else {
        field = 10 ** (-22 / 20) * Math.abs(x) ** 2.2;
      }
      break;
    }
    case "horn": {
      // Rectangular-aperture-inspired approximation; current config has only
      // one diameter, so E/H aperture dimensions are estimated from it.
      const a = Math.max(1, (diameterMm * 1.2) / wavelengthMm);
      const b = Math.max(1, (diameterMm * 0.8) / wavelengthMm);
      if (x < 0) {
        field = 10 ** (-28 / 20) * Math.abs(x) ** 1.5;
        break;
      }
      const uE = Math.PI * b * (y / Math.max(0.1, Math.hypot(x, y)));
      const uH = Math.PI * a * (z / Math.max(0.1, Math.hypot(x, z)));
      const sincE = Math.abs(uE) < 1e-8 ? 1 : Math.sin(uE) / uE;
      // Stable removable limit at uH = +/- pi/2 is pi/4.
      const denominator = 1 - (4 * uH * uH) / (Math.PI * Math.PI);
      const fH =
        Math.abs(denominator) < 1e-6 ? Math.PI / 4 : Math.cos(uH) / denominator;
      const aperture = Math.abs(sincE * fH);
      const exponent = Math.max(2, 10 ** ((gainDbi - 10) / 10));
      field = aperture ** (exponent * 0.35);
      break;
    }
    case "helical": {
      // Axial-mode approximation along +Y, matching the physical coil axis.
      if (y >= 0) {
        const turns = Math.max(4, Math.round(lengthMm / (wavelengthMm * 0.25)));
        field = y ** (turns * 0.45);
      } else {
        field = 0.05 * Math.abs(y) ** 1.5;
      }
      break;
    }
    case "isotropic":
    default:
      field = 1;
      break;
  }

  const relativeLinear = clamp01(Number.isFinite(field) ? field : 0);
  // Preserve true pattern nulls; the tiny numerical guard is only for log10.
  const relativeDb = 20 * Math.log10(Math.max(1e-12, relativeLinear));
  const gainDbiAtPoint = gainDbi + relativeDb;
  const radius = 0.18 + (2.4 - 0.18) * relativeLinear ** 0.82;

  return { gainDbi: gainDbiAtPoint, relativeLinear, radius };
}
