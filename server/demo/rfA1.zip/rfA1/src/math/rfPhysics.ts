// // Speed of light in m/s
// export const SPEED_OF_LIGHT = 299792458;

// export type WeatherCondition = "clear" | "fog" | "light_rain" | "heavy_rain";

// /**
//  * Convert Milliwatts to dBm
//  * e.g. 0.01 mW -> -20 dBm; 1 mW -> 0 dBm; 100 W (100,000 mW) -> +50 dBm
//  */
// export function mwToDbm(mW: number): number {
//   if (mW <= 0) return -100;
//   return 10 * Math.log10(mW);
// }

// /**
//  * Convert dBm to Milliwatts
//  */
// export function dbmToMw(dBm: number): number {
//   return Math.pow(10, dBm / 10);
// }

// /**
//  * Convert Milliwatts to Watts
//  */
// export function mwToWatts(mW: number): number {
//   return mW / 1000;
// }

// /**
//  * Calculate free space wavelength in millimeters from frequency in MHz
//  */
// export function getWavelengthMm(frequencyMHz: number): number {
//   if (frequencyMHz <= 0) return 0;
//   return (SPEED_OF_LIGHT / (frequencyMHz * 1e6)) * 1000;
// }

// /**
//  * Calculate velocity factor based on Length-to-Diameter ratio (thin vs fat dipole effect)
//  */
// export function getVelocityFactor(
//   lengthMm: number,
//   diameterMm: number,
// ): number {
//   if (diameterMm <= 0.001) return 0.98;
//   const ratio = lengthMm / Math.max(0.1, diameterMm);
//   if (ratio > 1000) return 0.98;
//   if (ratio > 500) return 0.97;
//   if (ratio > 100) return 0.95;
//   if (ratio > 50) return 0.93;
//   if (ratio > 20) return 0.91;
//   return 0.88;
// }

// /**
//  * Calculate resonant half-wave length (mm) at given frequency and diameter
//  */
// export function getResonantHalfWaveLengthMm(
//   frequencyMHz: number,
//   diameterMm: number = 2,
// ): number {
//   const lambda = getWavelengthMm(frequencyMHz);
//   const vf = getVelocityFactor(lambda / 2, diameterMm);
//   return (lambda / 2) * vf;
// }

// /**
//  * Calculate resonant quarter-wave length (mm) for monopole
//  */
// export function getResonantQuarterWaveLengthMm(
//   frequencyMHz: number,
//   diameterMm: number = 2,
// ): number {
//   const lambda = getWavelengthMm(frequencyMHz);
//   const vf = getVelocityFactor(lambda / 4, diameterMm);
//   return (lambda / 4) * vf;
// }

// /**
//  * Atmospheric Absorption & Weather Attenuation (ITU-R P.676 & ITU-R P.838 approximation)
//  * Calculates specific attenuation gamma (dB/km) due to dry air (O2), water vapor (H2O), and rain/fog.
//  */
// export function calculateAtmosphericLoss(
//   distanceMeters: number,
//   frequencyMHz: number,
//   weather: WeatherCondition = "clear",
// ): { totalAtmosphericLossDb: number; specificAttenuationDbPerKm: number } {
//   const fGHz = Math.max(0.1, frequencyMHz / 1000);
//   const distKm = Math.max(0, distanceMeters) / 1000;

//   // 1. Atmospheric gases absorption (ITU-R P.676):
//   // Baseline dry air & water vapor + resonance peaks near 22.2 GHz (H2O) and 60 GHz (O2)
//   const gasBase = 0.006 + 0.00012 * Math.pow(fGHz, 1.85);
//   const h2oResonance =
//     (0.22 * Math.pow(fGHz / 22.2, 2)) / (1 + Math.pow((fGHz - 22.2) / 2.5, 2));
//   const o2Resonance =
//     (14.5 * Math.pow(fGHz / 60, 2)) / (1 + Math.pow((fGHz - 60) / 4.0, 2));
//   const gammaGas = gasBase + h2oResonance + o2Resonance; // dB/km

//   // 2. Weather conditions attenuation (ITU-R P.838):
//   let gammaWeather = 0;
//   switch (weather) {
//     case "fog":
//       // Moderate fog (0.5 g/m^3)
//       gammaWeather = 0.0006 * Math.pow(fGHz, 1.8);
//       break;
//     case "light_rain":
//       // Light rain (2.5 mm/hr)
//       gammaWeather = 0.00015 * Math.pow(fGHz, 2.35);
//       break;
//     case "heavy_rain":
//       // Heavy tropical rain (25 mm/hr)
//       gammaWeather = 0.0028 * Math.pow(fGHz, 2.25);
//       break;
//     case "clear":
//     default:
//       gammaWeather = 0;
//       break;
//   }

//   const specificAttenuationDbPerKm = gammaGas + gammaWeather;
//   const totalAtmosphericLossDb = specificAttenuationDbPerKm * distKm;

//   return {
//     totalAtmosphericLossDb,
//     specificAttenuationDbPerKm,
//   };
// }

// /**
//  * Free Space Path Loss in dB
//  * FSPL(dB) = 20*log10(d) + 20*log10(f_MHz) - 27.55 (d in meters)
//  */
// export function calculateFSPL(
//   distanceMeters: number,
//   frequencyMHz: number,
// ): number {
//   const d = Math.max(0.01, distanceMeters);
//   const f = Math.max(1, frequencyMHz);
//   return 20 * Math.log10(d) + 20 * Math.log10(f) - 27.55;
// }

// /**
//  * Calculate Receiver Thermal Noise Floor in dBm
//  * N = -174 dBm/Hz + 10*log10(B) + NF
//  */
// export function calculateNoiseFloor(
//   bandwidthHz: number = 20e6,
//   noiseFigureDb: number = 5,
// ): number {
//   const b = Math.max(1e3, bandwidthHz);
//   const thermalNoise = -174 + 10 * Math.log10(b);
//   return thermalNoise + noiseFigureDb;
// }

// /**
//  * Calculate SNR (Signal-to-Noise Ratio in dB) and determine modulation capability
//  */
// export function calculateSNR(
//   rxPowerDbm: number,
//   bandwidthHz: number = 20e6,
//   noiseFigureDb: number = 5,
// ): { snrDb: number; noiseFloorDbm: number; modulationGrade: string } {
//   const noiseFloorDbm = calculateNoiseFloor(bandwidthHz, noiseFigureDb);
//   const snrDb = Math.round((rxPowerDbm - noiseFloorDbm) * 10) / 10;

//   let modulationGrade = "Lost in Noise";
//   if (snrDb >= 28) {
//     modulationGrade = "256-QAM (Max Throughput)";
//   } else if (snrDb >= 21) {
//     modulationGrade = "64-QAM (High Speed)";
//   } else if (snrDb >= 14) {
//     modulationGrade = "16-QAM (Medium)";
//   } else if (snrDb >= 7) {
//     modulationGrade = "QPSK (Robust Link)";
//   } else if (snrDb >= 1) {
//     modulationGrade = "BPSK (Low-Rate Safe)";
//   } else if (snrDb >= -15) {
//     modulationGrade = "Spread Spectrum / LoRa CSS";
//   }

//   return {
//     snrDb,
//     noiseFloorDbm: Math.round(noiseFloorDbm * 10) / 10,
//     modulationGrade,
//   };
// }

// /**
//  * Calculate Received Power (RSSI in dBm) taking into account:
//  * Tx Power, Tx Gain, Rx Gain, Free Space Path Loss (FSPL), and Atmospheric Loss
//  */
// export function calculateReceivedPowerDbm(
//   txPowerMw: number,
//   txGainDbi: number,
//   rxGainDbi: number,
//   distanceMeters: number,
//   frequencyMHz: number,
//   weather: WeatherCondition = "clear",
// ): {
//   rssiDbm: number;
//   fsplDb: number;
//   atmosphericLossDb: number;
//   totalPathLossDb: number;
// } {
//   const txPowerDbm = mwToDbm(txPowerMw);
//   const fspl = calculateFSPL(distanceMeters, frequencyMHz);
//   const { totalAtmosphericLossDb } = calculateAtmosphericLoss(
//     distanceMeters,
//     frequencyMHz,
//     weather,
//   );
//   const totalPathLossDb = fspl + totalAtmosphericLossDb;
//   const rssi = txPowerDbm + txGainDbi + rxGainDbi - totalPathLossDb;

//   return {
//     rssiDbm: rssi,
//     fsplDb: fspl,
//     atmosphericLossDb: totalAtmosphericLossDb,
//     totalPathLossDb,
//   };
// }

// /**
//  * Calculate EIRP (Effective Isotropic Radiated Power)
//  */
// export function calculateEIRP(
//   txPowerMw: number,
//   gainDbi: number,
// ): { eirpDbm: number; eirpWatts: number } {
//   const txPowerDbm = mwToDbm(txPowerMw);
//   const eirpDbm = txPowerDbm + gainDbi;
//   const eirpMw = Math.pow(10, eirpDbm / 10);
//   return {
//     eirpDbm,
//     eirpWatts: eirpMw / 1000,
//   };
// }

// /**
//  * Calculate Electric Field Strength in V/m
//  */
// export function calculateElectricField(
//   eirpWatts: number,
//   distanceMeters: number,
// ): number {
//   const d = Math.max(0.05, distanceMeters);
//   return Math.sqrt(30 * Math.max(0, eirpWatts)) / d;
// }

// /**
//  * Calculate Power Density in uW/cm^2
//  */
// export function calculatePowerDensityUWCm2(
//   eirpWatts: number,
//   distanceMeters: number,
// ): number {
//   const d = Math.max(0.05, distanceMeters);
//   const sWattsPerM2 = Math.max(0, eirpWatts) / (4 * Math.PI * d * d);
//   return sWattsPerM2 * 100;
// }

// /**
//  * Calculate Maximum Coverage Distance in meters accounting for atmospheric attenuation
//  */
// export function calculateMaxCoverageRange(
//   txPowerMw: number,
//   antennaGainDbiAtAngle: number,
//   frequencyMHz: number,
//   rxSensitivityDbm: number = -85,
//   rxGainDbi: number = 0,
//   weather: WeatherCondition = "clear",
// ): number {
//   const txPowerDbm = mwToDbm(txPowerMw);
//   const maxAllowedLoss =
//     txPowerDbm + antennaGainDbiAtAngle + rxGainDbi - rxSensitivityDbm;
//   if (maxAllowedLoss <= 0) return 0.1;

//   // Approximate distance using iteration to account for atmospheric loss
//   let dEst = Math.pow(
//     10,
//     (maxAllowedLoss - 20 * Math.log10(frequencyMHz) + 27.55) / 20,
//   );

//   // 2 refinement iterations with atmospheric loss included
//   for (let i = 0; i < 2; i++) {
//     const { totalAtmosphericLossDb } = calculateAtmosphericLoss(
//       dEst,
//       frequencyMHz,
//       weather,
//     );
//     const effLoss = maxAllowedLoss - totalAtmosphericLossDb;
//     if (effLoss <= 0) break;
//     dEst = Math.pow(10, (effLoss - 20 * Math.log10(frequencyMHz) + 27.55) / 20);
//   }

//   return Math.max(0.1, dEst);
// }
// Core RF calculations. Distances are metres, frequencies are MHz unless stated otherwise.
export const SPEED_OF_LIGHT = 299792458;
export const BOLTZMANN_CONSTANT = 1.380649e-23;
export type WeatherCondition = "clear" | "fog" | "light_rain" | "heavy_rain";

function isPositiveFinite(value: number): boolean {
  return Number.isFinite(value) && value > 0;
}

/** Convert milliwatts to dBm. Invalid/non-positive power is represented by -Infinity. */
export function mwToDbm(mW: number): number {
  return isPositiveFinite(mW) ? 10 * Math.log10(mW) : -Infinity;
}

export function dbmToMw(dBm: number): number {
  return Number.isFinite(dBm) ? 10 ** (dBm / 10) : 0;
}

export function mwToWatts(mW: number): number {
  return Number.isFinite(mW) && mW > 0 ? mW / 1000 : 0;
}

export function getWavelengthMm(frequencyMHz: number): number {
  if (!isPositiveFinite(frequencyMHz)) return 0;
  return (SPEED_OF_LIGHT / (frequencyMHz * 1e6)) * 1000;
}

/**
 * Approximate element-shortening factor for a thin, centre-fed wire antenna.
 * This is NOT a transmission-line velocity factor. It is retained as a
 * practical estimate for the existing dipole/monopole length controls only.
 */
export function getVelocityFactor(
  lengthMm: number,
  diameterMm: number,
): number {
  if (!isPositiveFinite(lengthMm) || !isPositiveFinite(diameterMm)) return 0.95;
  const ratio = lengthMm / diameterMm;
  if (ratio > 1000) return 0.98;
  if (ratio > 500) return 0.97;
  if (ratio > 100) return 0.95;
  if (ratio > 50) return 0.93;
  if (ratio > 20) return 0.91;
  return 0.88;
}

export function getResonantHalfWaveLengthMm(
  frequencyMHz: number,
  diameterMm = 2,
): number {
  const wavelength = getWavelengthMm(frequencyMHz);
  return wavelength > 0
    ? (wavelength / 2) * getVelocityFactor(wavelength / 2, diameterMm)
    : 0;
}

export function getResonantQuarterWaveLengthMm(
  frequencyMHz: number,
  diameterMm = 2,
): number {
  const wavelength = getWavelengthMm(frequencyMHz);
  return wavelength > 0
    ? (wavelength / 4) * getVelocityFactor(wavelength / 4, diameterMm)
    : 0;
}

/**
 * Coarse environmental-loss estimate for visualization. It is deliberately
 * labelled an approximation: the UI's weather categories do not contain the
 * pressure, water-vapour density, rain rate, and polarization inputs required
 * for a standards-grade ITU-R P.676/P.838 calculation.
 */
export function calculateAtmosphericLoss(
  distanceMeters: number,
  frequencyMHz: number,
  weather: WeatherCondition = "clear",
): { totalAtmosphericLossDb: number; specificAttenuationDbPerKm: number } {
  if (
    !Number.isFinite(distanceMeters) ||
    distanceMeters < 0 ||
    !isPositiveFinite(frequencyMHz)
  ) {
    return { totalAtmosphericLossDb: 0, specificAttenuationDbPerKm: 0 };
  }
  const fGHz = frequencyMHz / 1000;
  // Smooth, intentionally conservative visualization approximation; not an ITU-R implementation.
  const gasBase = 0.006 + 0.00012 * fGHz ** 1.85;
  const waterVapourResonance =
    (0.22 * (fGHz / 22.2) ** 2) / (1 + ((fGHz - 22.2) / 2.5) ** 2);
  const oxygenResonance =
    (14.5 * (fGHz / 60) ** 2) / (1 + ((fGHz - 60) / 4) ** 2);
  const gas = gasBase + waterVapourResonance + oxygenResonance;
  const weatherCoefficients: Record<WeatherCondition, number> = {
    clear: 0,
    fog: 0.0006,
    light_rain: 0.00015,
    heavy_rain: 0.0028,
  };
  const weatherExponent: Record<WeatherCondition, number> = {
    clear: 0,
    fog: 1.8,
    light_rain: 2.35,
    heavy_rain: 2.25,
  };
  const weatherLoss =
    weather === "clear"
      ? 0
      : weatherCoefficients[weather] * fGHz ** weatherExponent[weather];
  const specificAttenuationDbPerKm = gas + weatherLoss;
  return {
    specificAttenuationDbPerKm,
    totalAtmosphericLossDb:
      specificAttenuationDbPerKm * (distanceMeters / 1000),
  };
}

/** Free-space path loss. Returns Infinity for invalid distance/frequency. */
export function calculateFSPL(
  distanceMeters: number,
  frequencyMHz: number,
): number {
  if (!isPositiveFinite(distanceMeters) || !isPositiveFinite(frequencyMHz))
    return Infinity;
  return (
    20 * Math.log10(distanceMeters) + 20 * Math.log10(frequencyMHz) - 27.55
  );
}

/** Thermal noise from kTB, converted to dBm, plus receiver noise figure. */
export function calculateNoiseFloor(
  bandwidthHz = 20e6,
  noiseFigureDb = 5,
  temperatureK = 290,
): number {
  if (
    !isPositiveFinite(bandwidthHz) ||
    !isPositiveFinite(temperatureK) ||
    !Number.isFinite(noiseFigureDb)
  ) {
    return NaN;
  }
  const noiseWatts = BOLTZMANN_CONSTANT * temperatureK * bandwidthHz;
  return 10 * Math.log10(noiseWatts / 1e-3) + noiseFigureDb;
}

export function calculateSNR(
  rxPowerDbm: number,
  bandwidthHz = 20e6,
  noiseFigureDb = 5,
  temperatureK = 290,
): { snrDb: number; noiseFloorDbm: number; modulationGrade: string } {
  const noiseFloorDbm = calculateNoiseFloor(
    bandwidthHz,
    noiseFigureDb,
    temperatureK,
  );
  const snrDb =
    Number.isFinite(rxPowerDbm) && Number.isFinite(noiseFloorDbm)
      ? rxPowerDbm - noiseFloorDbm
      : -Infinity;
  // These are illustrative SNR bands, not guaranteed modem/MCS thresholds.
  let modulationGrade = "Lost in Noise";
  if (snrDb >= 28) modulationGrade = "256-QAM (indicative)";
  else if (snrDb >= 21) modulationGrade = "64-QAM (indicative)";
  else if (snrDb >= 14) modulationGrade = "16-QAM (indicative)";
  else if (snrDb >= 7) modulationGrade = "QPSK (indicative)";
  else if (snrDb >= 1) modulationGrade = "BPSK (indicative)";
  else if (snrDb >= -15)
    modulationGrade = "Spread Spectrum / LoRa CSS (indicative)";
  return { snrDb, noiseFloorDbm, modulationGrade };
}

export function calculateReceivedPowerDbm(
  txPowerMw: number,
  txGainDbi: number,
  rxGainDbi: number,
  distanceMeters: number,
  frequencyMHz: number,
  weather: WeatherCondition = "clear",
): {
  rssiDbm: number;
  fsplDb: number;
  atmosphericLossDb: number;
  totalPathLossDb: number;
} {
  const fsplDb = calculateFSPL(distanceMeters, frequencyMHz);
  if (
    !Number.isFinite(fsplDb) ||
    !isPositiveFinite(txPowerMw) ||
    !Number.isFinite(txGainDbi) ||
    !Number.isFinite(rxGainDbi)
  ) {
    return {
      rssiDbm: -Infinity,
      fsplDb,
      atmosphericLossDb: 0,
      totalPathLossDb: Infinity,
    };
  }
  const { totalAtmosphericLossDb } = calculateAtmosphericLoss(
    distanceMeters,
    frequencyMHz,
    weather,
  );
  const totalPathLossDb = fsplDb + totalAtmosphericLossDb;
  return {
    rssiDbm: mwToDbm(txPowerMw) + txGainDbi + rxGainDbi - totalPathLossDb,
    fsplDb,
    atmosphericLossDb: totalAtmosphericLossDb,
    totalPathLossDb,
  };
}

export function calculateEIRP(
  txPowerMw: number,
  gainDbi: number,
): { eirpDbm: number; eirpWatts: number } {
  if (!isPositiveFinite(txPowerMw) || !Number.isFinite(gainDbi))
    return { eirpDbm: -Infinity, eirpWatts: 0 };
  const eirpDbm = mwToDbm(txPowerMw) + gainDbi;
  return { eirpDbm, eirpWatts: 10 ** ((eirpDbm - 30) / 10) };
}

/** Far-field RMS electric-field approximation for EIRP in free space. */
export function calculateElectricField(
  eirpWatts: number,
  distanceMeters: number,
): number {
  if (
    !Number.isFinite(eirpWatts) ||
    eirpWatts < 0 ||
    !isPositiveFinite(distanceMeters)
  )
    return NaN;
  return Math.sqrt(30 * eirpWatts) / distanceMeters;
}

/** Free-space power density in micro-watts per square centimetre. */
export function calculatePowerDensityUWCm2(
  eirpWatts: number,
  distanceMeters: number,
): number {
  if (
    !Number.isFinite(eirpWatts) ||
    eirpWatts < 0 ||
    !isPositiveFinite(distanceMeters)
  )
    return NaN;
  return (eirpWatts / (4 * Math.PI * distanceMeters ** 2)) * 100;
}

/**
 * Solve the maximum free-space coverage distance with bisection. Returns 0
 * when inputs are invalid or even the near-boundary received power is below
 * sensitivity; it never invents a 0.1 m coverage distance.
 */
export function calculateMaxCoverageRange(
  txPowerMw: number,
  antennaGainDbiAtAngle: number,
  frequencyMHz: number,
  rxSensitivityDbm = -85,
  rxGainDbi = 0,
  weather: WeatherCondition = "clear",
): number {
  if (
    !isPositiveFinite(txPowerMw) ||
    !isPositiveFinite(frequencyMHz) ||
    !Number.isFinite(antennaGainDbiAtAngle) ||
    !Number.isFinite(rxGainDbi) ||
    !Number.isFinite(rxSensitivityDbm)
  )
    return 0;

  const receivedAt = (distance: number) =>
    calculateReceivedPowerDbm(
      txPowerMw,
      antennaGainDbiAtAngle,
      rxGainDbi,
      distance,
      frequencyMHz,
      weather,
    ).rssiDbm;

  let low = 0.01;
  if (receivedAt(low) < rxSensitivityDbm) return 0;
  let high = 1;
  while (high < 1e12 && receivedAt(high) >= rxSensitivityDbm) high *= 2;
  if (high >= 1e12 && receivedAt(high) >= rxSensitivityDbm) return high;

  for (let i = 0; i < 80; i++) {
    const mid = (low + high) / 2;
    if (receivedAt(mid) >= rxSensitivityDbm) low = mid;
    else high = mid;
  }
  return low;
}
