import { create } from "zustand";
// import { AntennaConfig, ColormapType, GizmoMode, HeatmapMetric, HoverInspectionData, RFEnvironmentConfig, ViewMode } from '../types/antenna';
import {
  AntennaConfig,
  AntennaRole,
  ColormapType,
  GizmoMode,
  HeatmapMetric,
  HoverInspectionData,
  ModulationMode,
  ModulationScheme,
  RFEnvironmentConfig,
  ViewMode,
} from "../types/antenna";
import {
  getResonantHalfWaveLengthMm,
  getResonantQuarterWaveLengthMm,
  WeatherCondition,
} from "../math/rfPhysics";

interface AntennaStoreState {
  antenna1: AntennaConfig;
  antenna2: AntennaConfig;
  selectedAntennaId: "antenna-1" | "antenna-2";

  viewMode: ViewMode;
  gizmoMode: GizmoMode;
  colormap: ColormapType;
  heatmapMetric: HeatmapMetric;
  evalDistanceMeters: number;
  rxSensitivityDbm: number; // e.g. -85 dBm

  // RF Channel & Atmospheric Environment
  rfEnvironment: RFEnvironmentConfig;

  // Visual scene toggles
  showGroundPlane: boolean;
  showIsoCoverageSphere: boolean;
  showDistanceRings: boolean;
  showAxes: boolean;
  autoRotate: boolean;
  polarCutMode: "none" | "e-plane" | "h-plane";

  // Raycast hover data & inspection pinning
  hoverData: HoverInspectionData | null;
  isInspectionPinned: boolean;
  isHoveringTooltip: boolean;

  // Link budget settings
  linkDistanceMeters: number;

  // Actions
  setAntennaRole: (
    antennaId: "antenna-1" | "antenna-2",
    role: AntennaRole,
  ) => void;
  updateAntenna1: (partial: Partial<AntennaConfig>) => void;
  updateAntenna2: (partial: Partial<AntennaConfig>) => void;
  setSelectedAntennaId: (id: "antenna-1" | "antenna-2") => void;
  setViewMode: (mode: ViewMode) => void;
  setGizmoMode: (mode: GizmoMode) => void;
  setColormap: (map: ColormapType) => void;
  setHeatmapMetric: (metric: HeatmapMetric) => void;
  setEvalDistanceMeters: (dist: number) => void;
  setRxSensitivityDbm: (sens: number) => void;
  setHoverData: (data: HoverInspectionData | null) => void;
  setIsInspectionPinned: (pinned: boolean) => void;
  setIsHoveringTooltip: (hovering: boolean) => void;
  setLinkDistanceMeters: (dist: number) => void;

  // RF Environment Actions
  setWeather: (weather: WeatherCondition) => void;
  setBandwidthMHz: (bw: number) => void;
  setNoiseFigureDb: (nf: number) => void;
  setModulationMode: (mode: ModulationMode) => void;
  setSelectedModulation: (scheme: ModulationScheme) => void;

  // Toggles
  setShowGroundPlane: (show: boolean) => void;
  setShowIsoCoverageSphere: (show: boolean) => void;
  setShowDistanceRings: (show: boolean) => void;
  setShowAxes: (show: boolean) => void;
  setAutoRotate: (rotate: boolean) => void;
  setPolarCutMode: (mode: "none" | "e-plane" | "h-plane") => void;

  // Helper actions
  flipAntenna180: (
    antennaId: "antenna-1" | "antenna-2",
    axis?: "yaw" | "pitch" | "roll",
  ) => void;
  aimAntennaAt: (
    sourceId: "antenna-1" | "antenna-2",
    targetId: "antenna-1" | "antenna-2",
  ) => void;
  resetTransform: (antennaId: "antenna-1" | "antenna-2") => void;
  autoTuneResonance: (antennaId: "antenna-1" | "antenna-2") => void;
  applyFrequencyPreset: (freqMHz: number, name?: string) => void;
  applyAntennaPreset: (
    antennaId: "antenna-1" | "antenna-2",
    presetKey: string,
  ) => void;
  resetAll: () => void;
}
function getAntennaDistance(
  antenna1: AntennaConfig,
  antenna2: AntennaConfig,
): number {
  return Math.hypot(
    antenna2.position[0] - antenna1.position[0],
    antenna2.position[1] - antenna1.position[1],
    antenna2.position[2] - antenna1.position[2],
  );
}
const defaultAntenna1: AntennaConfig = {
  id: "antenna-1",
  name: "Antenna 1 (Dipole)",
  color: "#38bdf8", // Cyan
  enabled: true,
  role: "transmitter",
  type: "dipole",
  powerMilliwatts: 100, // 100 mW = 20 dBm (standard Wi-Fi)
  gainDbi: 2.15, // Standard half-wave dipole gain
  gainMode: "rated",
  gainReferenceFrequencyMHz: 2400,
  radiationEfficiencyPercent: 85,
  lengthMm: 62.5, // ~lambda/2 at 2.4 GHz
  frequencyMHz: 2400, // 2.4 GHz ISM
  diameterMm: 2.5,
  monopoleGroundPlaneDiameterMm: 62.5,
  patchLengthMm: 31,
  patchWidthMm: 60,
  patchSubstrateEr: 4.4,
  patchSubstrateThicknessMm: 1.6,
  patchGroundMarginMm: 10,
  patchFeedInsetMm: 7.8,
  yagiElementCount: 6,
  yagiDrivenElementLengthMm: 58.8,
  yagiReflectorLengthMm: 62.5,
  yagiDirectorLengthMm: 56.3,
  hornApertureWidthMm: 156,
  hornApertureHeightMm: 125,
  hornThroatWidthMm: 56,
  hornThroatHeightMm: 38,
  helixTurns: 8,
  helixPitchMm: 31.3,
  helixCoilDiameterMm: 39.8,
  helixWireDiameterMm: 2.5,
  helixReflectorDiameterMm: 150,
  position: [-3.2, 0, 0],
  rotation: [0, 0, 0],
  showLobe: true,
  showPhysicalAntenna: true,
  wireframe: false,
  opacity: 0.88,
};

const defaultAntenna2: AntennaConfig = {
  id: "antenna-2",
  name: "Antenna 2 (Directional Patch)",
  color: "#f43f5e", // Rose
  enabled: true,
  role: "receiver",
  type: "patch",
  powerMilliwatts: 100, // 100 mW = 20 dBm
  gainDbi: 8.5, // Directional Patch gain
  gainMode: "rated",
  gainReferenceFrequencyMHz: 2400,
  radiationEfficiencyPercent: 75,
  lengthMm: 58.0,
  frequencyMHz: 2400, // 2.4 GHz ISM
  diameterMm: 12.0,
  monopoleGroundPlaneDiameterMm: 62.5,
  patchLengthMm: 31,
  patchWidthMm: 60,
  patchSubstrateEr: 4.4,
  patchSubstrateThicknessMm: 1.6,
  patchGroundMarginMm: 10,
  patchFeedInsetMm: 7.8,
  yagiElementCount: 6,
  yagiDrivenElementLengthMm: 58.8,
  yagiReflectorLengthMm: 62.5,
  yagiDirectorLengthMm: 56.3,
  hornApertureWidthMm: 156,
  hornApertureHeightMm: 125,
  hornThroatWidthMm: 56,
  hornThroatHeightMm: 38,
  helixTurns: 8,
  helixPitchMm: 31.3,
  helixCoilDiameterMm: 39.8,
  helixWireDiameterMm: 2.5,
  helixReflectorDiameterMm: 150,
  position: [3.2, 0, 0],
  rotation: [0, 0, 0],
  showLobe: true,
  showPhysicalAntenna: true,
  wireframe: false,
  opacity: 0.88,
};

export const useAntennaStore = create<AntennaStoreState>((set, get) => ({
  setAntennaRole: (antennaId, role) => {
    set((state) => {
      const oppositeRole: AntennaRole =
        role === "transmitter" ? "receiver" : "transmitter";

      if (antennaId === "antenna-1") {
        return {
          antenna1: {
            ...state.antenna1,
            role,
          },
          antenna2: {
            ...state.antenna2,
            role: oppositeRole,
          },
        };
      }

      return {
        antenna2: {
          ...state.antenna2,
          role,
        },
        antenna1: {
          ...state.antenna1,
          role: oppositeRole,
        },
      };
    });
  },

  antenna1: defaultAntenna1,
  antenna2: defaultAntenna2,
  selectedAntennaId: "antenna-1",

  viewMode: "side-by-side",
  gizmoMode: "none",
  colormap: "turbo",
  heatmapMetric: "dbi",
  evalDistanceMeters: 5.0, // 5 meters evaluation distance
  rxSensitivityDbm: -85, // -85 dBm receiver sensitivity

  // RF Channel & Atmospheric Environment
  rfEnvironment: {
    weather: "clear",
    bandwidthMHz: 20, // 20 MHz (typical Wi-Fi / LTE)
    noiseFigureDb: 5, // 5 dB typical LNA
    temperatureK: 290,
    modulationMode: "auto",
    selectedModulation: "64-QAM",
  },

  showGroundPlane: true,
  showIsoCoverageSphere: false,
  showDistanceRings: false,
  showAxes: true,
  autoRotate: false,
  polarCutMode: "none",

  hoverData: null,
  isInspectionPinned: false,
  isHoveringTooltip: false,
  linkDistanceMeters: 6.4,

  updateAntenna1: (partial) => {
    set((state) => {
      const nextAntenna1: AntennaConfig = {
        ...state.antenna1,
        ...partial,
        ...(partial.frequencyMHz !== undefined &&
        state.antenna1.gainReferenceFrequencyMHz === undefined &&
        state.antenna1.gainMode !== "estimated"
          ? { gainReferenceFrequencyMHz: state.antenna1.frequencyMHz }
          : {}),
      };

      return {
        antenna1: nextAntenna1,
        linkDistanceMeters: getAntennaDistance(nextAntenna1, state.antenna2),
      };
    });
  },

  updateAntenna2: (partial) => {
    set((state) => {
      const nextAntenna2: AntennaConfig = {
        ...state.antenna2,
        ...partial,
        ...(partial.frequencyMHz !== undefined &&
        state.antenna2.gainReferenceFrequencyMHz === undefined &&
        state.antenna2.gainMode !== "estimated"
          ? { gainReferenceFrequencyMHz: state.antenna2.frequencyMHz }
          : {}),
      };

      return {
        antenna2: nextAntenna2,
        linkDistanceMeters: getAntennaDistance(state.antenna1, nextAntenna2),
      };
    });
  },

  setSelectedAntennaId: (id) => set({ selectedAntennaId: id }),
  setGizmoMode: (gizmoMode) => set({ gizmoMode }),
  setViewMode: (mode) => {
    const isOverlaid = mode === "overlaid";

    set((state) => {
      const antenna1Position: [number, number, number] = isOverlaid
        ? [0, 0, 0]
        : [-3.2, 0, 0];

      const antenna2Position: [number, number, number] = isOverlaid
        ? [0, 0, 0]
        : [3.2, 0, 0];

      const nextAntenna1 = {
        ...state.antenna1,
        position: antenna1Position,
      };

      const nextAntenna2 = {
        ...state.antenna2,
        position: antenna2Position,
      };

      return {
        viewMode: mode,
        antenna1: nextAntenna1,
        antenna2: nextAntenna2,
        linkDistanceMeters: getAntennaDistance(nextAntenna1, nextAntenna2),
      };
    });
  },

  setColormap: (colormap) => set({ colormap }),
  setHeatmapMetric: (heatmapMetric) => set({ heatmapMetric }),
  setEvalDistanceMeters: (evalDistanceMeters) => set({ evalDistanceMeters }),
  setRxSensitivityDbm: (rxSensitivityDbm) => set({ rxSensitivityDbm }),
  setHoverData: (hoverData) => set({ hoverData }),
  setIsInspectionPinned: (isInspectionPinned) => set({ isInspectionPinned }),
  setIsHoveringTooltip: (isHoveringTooltip) => set({ isHoveringTooltip }),
  setLinkDistanceMeters: (distance) => {
    const requestedDistance = Math.max(1, Math.min(15000, distance));

    set((state) => {
      const tx =
        state.antenna1.role === "transmitter" ? state.antenna1 : state.antenna2;

      const rx =
        state.antenna1.role === "receiver" ? state.antenna1 : state.antenna2;

      let dx = rx.position[0] - tx.position[0];
      let dy = rx.position[1] - tx.position[1];
      let dz = rx.position[2] - tx.position[2];

      let currentDistance = Math.hypot(dx, dy, dz);

      // When antennas overlap, use +X as the default direction.
      if (currentDistance < 0.0001) {
        dx = 1;
        dy = 0;
        dz = 0;
        currentDistance = 1;
      }

      const nextPosition: [number, number, number] = [
        tx.position[0] + (dx / currentDistance) * requestedDistance,

        tx.position[1] + (dy / currentDistance) * requestedDistance,

        tx.position[2] + (dz / currentDistance) * requestedDistance,
      ];

      if (rx.id === "antenna-1") {
        const nextAntenna1: AntennaConfig = {
          ...state.antenna1,
          position: nextPosition,
        };

        return {
          antenna1: nextAntenna1,
          linkDistanceMeters: getAntennaDistance(nextAntenna1, state.antenna2),
        };
      }

      const nextAntenna2: AntennaConfig = {
        ...state.antenna2,
        position: nextPosition,
      };

      return {
        antenna2: nextAntenna2,
        linkDistanceMeters: getAntennaDistance(state.antenna1, nextAntenna2),
      };
    });
  },

  setWeather: (weather) =>
    set((state) => ({ rfEnvironment: { ...state.rfEnvironment, weather } })),
  setBandwidthMHz: (bandwidthMHz) =>
    set((state) => ({
      rfEnvironment: { ...state.rfEnvironment, bandwidthMHz },
    })),
  setNoiseFigureDb: (noiseFigureDb) =>
    set((state) => ({
      rfEnvironment: { ...state.rfEnvironment, noiseFigureDb },
    })),
  setModulationMode: (modulationMode) =>
    set((state) => ({
      rfEnvironment: { ...state.rfEnvironment, modulationMode },
    })),
  setSelectedModulation: (selectedModulation) =>
    set((state) => ({
      rfEnvironment: { ...state.rfEnvironment, selectedModulation },
    })),

  setShowGroundPlane: (showGroundPlane) => set({ showGroundPlane }),
  setShowIsoCoverageSphere: (showIsoCoverageSphere) =>
    set({ showIsoCoverageSphere }),
  setShowDistanceRings: (showDistanceRings) => set({ showDistanceRings }),
  setShowAxes: (showAxes) => set({ showAxes }),
  setAutoRotate: (autoRotate) => set({ autoRotate }),
  setPolarCutMode: (polarCutMode) => set({ polarCutMode }),

  flipAntenna180: (antennaId, axis = "yaw") => {
    const state = get();
    const ant = antennaId === "antenna-1" ? state.antenna1 : state.antenna2;
    let [rx, ry, rz] = ant.rotation;

    if (axis === "yaw") {
      ry = ry + 180;
      if (ry > 180) ry -= 360;
      if (ry < -180) ry += 360;
    } else if (axis === "pitch") {
      rx = -rx;
      ry = ry + 180;
      if (ry > 180) ry -= 360;
    } else if (axis === "roll") {
      rz = rz + 180;
      if (rz > 180) rz -= 360;
      if (rz < -180) rz += 360;
    }

    const roundedRot: [number, number, number] = [
      Math.round(rx * 10) / 10,
      Math.round(ry * 10) / 10,
      Math.round(rz * 10) / 10,
    ];

    if (antennaId === "antenna-1") {
      get().updateAntenna1({ rotation: roundedRot });
    } else {
      get().updateAntenna2({ rotation: roundedRot });
    }
  },

  aimAntennaAt: (sourceId, targetId) => {
    const state = get();
    const source = sourceId === "antenna-1" ? state.antenna1 : state.antenna2;
    const target = targetId === "antenna-1" ? state.antenna1 : state.antenna2;

    const dx = target.position[0] - source.position[0];
    const dy = target.position[1] - source.position[1];
    const dz = target.position[2] - source.position[2];
    const distXZ = Math.sqrt(dx * dx + dz * dz);

    // Directional antennas point initially along +X.
    // Yaw around Y-axis:
    const yawDeg =
      Math.round(((Math.atan2(-dz, dx) * 180) / Math.PI) * 10) / 10;
    // Pitch / Tilt around Z-axis:
    const pitchDeg =
      Math.round(
        ((Math.atan2(dy, Math.max(0.01, distXZ)) * 180) / Math.PI) * 10,
      ) / 10;

    const newRot: [number, number, number] = [0, yawDeg, pitchDeg];
    if (sourceId === "antenna-1") {
      get().updateAntenna1({ rotation: newRot });
    } else {
      get().updateAntenna2({ rotation: newRot });
    }
  },

  resetTransform: (antennaId) => {
    const defaultPos: [number, number, number] =
      antennaId === "antenna-1" ? [-3.2, 0, 0] : [3.2, 0, 0];
    if (antennaId === "antenna-1") {
      get().updateAntenna1({ position: defaultPos, rotation: [0, 0, 0] });
    } else {
      get().updateAntenna2({ position: defaultPos, rotation: [0, 0, 0] });
    }
  },

  autoTuneResonance: (antennaId) => {
    const state = get();
    const ant = antennaId === "antenna-1" ? state.antenna1 : state.antenna2;
    const isMonopole = ant.type === "monopole";
    const resonantMm = isMonopole
      ? getResonantQuarterWaveLengthMm(ant.frequencyMHz, ant.diameterMm)
      : getResonantHalfWaveLengthMm(ant.frequencyMHz, ant.diameterMm);

    const rounded = Math.round(resonantMm * 10) / 10;
    if (antennaId === "antenna-1") {
      get().updateAntenna1({ lengthMm: rounded });
    } else {
      get().updateAntenna2({ lengthMm: rounded });
    }
  },

  applyFrequencyPreset: (freqMHz: number) => {
    set((state) => ({
      antenna1: {
        ...state.antenna1,
        frequencyMHz: freqMHz,
        ...(state.antenna1.gainReferenceFrequencyMHz === undefined &&
        state.antenna1.gainMode !== "estimated"
          ? { gainReferenceFrequencyMHz: state.antenna1.frequencyMHz }
          : {}),
      },
      antenna2: {
        ...state.antenna2,
        frequencyMHz: freqMHz,
        ...(state.antenna2.gainReferenceFrequencyMHz === undefined &&
        state.antenna2.gainMode !== "estimated"
          ? { gainReferenceFrequencyMHz: state.antenna2.frequencyMHz }
          : {}),
      },
    }));
  },

  applyAntennaPreset: (antennaId, presetKey) => {
    const updateFn =
      antennaId === "antenna-1" ? get().updateAntenna1 : get().updateAntenna2;
    const updatePreset = (partial: Partial<AntennaConfig>) =>
      updateFn({
        gainMode: "rated",
        ...partial,
        gainReferenceFrequencyMHz: partial.frequencyMHz ??
          (antennaId === "antenna-1" ? get().antenna1.frequencyMHz : get().antenna2.frequencyMHz),
      });

    switch (presetKey) {
      case "wifi-dipole":
        updatePreset({
          name: "Wi-Fi 2.4G Dipole",
          type: "dipole",
          frequencyMHz: 2400,
          powerMilliwatts: 100, // 20 dBm
          gainDbi: 2.15,
          lengthMm: 60.5,
          diameterMm: 2.5,
        });
        break;
      case "lora-monopole":
        updatePreset({
          name: "LoRa 868/915M Monopole",
          type: "monopole",
          frequencyMHz: 868,
          powerMilliwatts: 25, // 14 dBm
          gainDbi: 3.2,
          lengthMm: 82.0,
          diameterMm: 1.8,
          monopoleGroundPlaneDiameterMm: 172.7,
        });
        break;
      case "patch-panel":
        updatePreset({
          name: "2.4G High-Gain Patch",
          type: "patch",
          frequencyMHz: 2400,
          powerMilliwatts: 200, // 23 dBm
          gainDbi: 8.5,
          lengthMm: 58.0,
          diameterMm: 15.0,
          patchLengthMm: 31.0,
          patchWidthMm: 60.0,
          patchSubstrateEr: 4.4,
          patchSubstrateThicknessMm: 1.6,
          patchGroundMarginMm: 10.0,
          patchFeedInsetMm: 7.8,
        });
        break;
      case "yagi-directional":
        updatePreset({
          name: "Yagi Long-Range (12 dBi)",
          type: "yagi",
          frequencyMHz: 2400,
          powerMilliwatts: 500, // 27 dBm
          gainDbi: 12.5,
          lengthMm: 380,
          diameterMm: 4.0,
          yagiElementCount: 6,
          yagiDrivenElementLengthMm: 58.8,
          yagiReflectorLengthMm: 62.5,
          yagiDirectorLengthMm: 56.3,
        });
        break;
      case "horn-dish":
        updatePreset({
          name: "Pyramidal Horn (18 dBi)",
          type: "horn",
          frequencyMHz: 5800,
          powerMilliwatts: 1000, // 30 dBm (1 W)
          gainDbi: 18.0,
          lengthMm: 160,
          diameterMm: 90,
          hornApertureWidthMm: 65,
          hornApertureHeightMm: 52,
          hornThroatWidthMm: 23,
          hornThroatHeightMm: 16,
        });
        break;
      case "helical-satellite":
        updatePreset({
          name: "Axial Helical (11 dBi)",
          type: "helical",
          frequencyMHz: 2400,
          powerMilliwatts: 250,
          gainDbi: 11.0,
          lengthMm: 220,
          diameterMm: 40,
          helixTurns: 7,
          helixPitchMm: 31.2,
          helixCoilDiameterMm: 39.8,
          helixWireDiameterMm: 2,
          helixReflectorDiameterMm: 150,
        });
        break;
      case "high-power-pa":
        updatePreset({
          name: "High-Power PA (50W Dipole)",
          type: "dipole",
          frequencyMHz: 433,
          powerMilliwatts: 50000, // 50 Watts!
          gainDbi: 2.15,
          lengthMm: 330,
          diameterMm: 8.0,
        });
        break;
      case "iot-micro":
        updatePreset({
          name: "Ultra Low-Power IoT (0.01 mW)",
          type: "monopole",
          frequencyMHz: 2400,
          powerMilliwatts: 0.01, // -20 dBm ultra-low
          gainDbi: 1.0,
          lengthMm: 30,
          diameterMm: 1.0,
        });
        break;
    }
  },

  resetAll: () => {
    set({
      antenna1: defaultAntenna1,
      antenna2: defaultAntenna2,
      viewMode: "side-by-side",
      colormap: "turbo",
      heatmapMetric: "dbi",
      evalDistanceMeters: 5.0,
      rxSensitivityDbm: -85,
      showGroundPlane: true,
      showIsoCoverageSphere: false,
      showDistanceRings: false,
      showAxes: true,
      autoRotate: false,
      polarCutMode: "none",
      hoverData: null,
      linkDistanceMeters: 6.4,
    });
  },
}));
