// import { AntennaConfig, RFEnvironmentConfig } from "../types/antenna";
// import {
//   calculateMaxCoverageRange,
//   calculateReceivedPowerDbm,
//   calculateSNR,
//   calculateEIRP,
// } from "./rfPhysics";

// /**
//  * A direction-dependent link budget for the antenna whose lobe is being built.
//  *
//  * TX lobe:
//  *   - the hovered direction supplies TX gain
//  *   - the remote RX is assumed to be aligned for its configured peak gain
//  *
//  * RX lobe:
//  *   - the hovered direction supplies RX gain (reciprocal antenna pattern)
//  *   - the remote TX is assumed to be aligned for its configured peak gain
//  *
//  * This creates a potential-coverage envelope. It is not a prediction of the
//  * current fixed-position TX-to-RX link; that is calculated by the Link Budget HUD.
//  */
// export interface DirectionalLinkParameters {
//   txAntenna: AntennaConfig;
//   rxAntenna: AntennaConfig;
//   txPowerMilliwatts: number;
//   txGainDbi: number;
//   rxGainDbi: number;
//   frequencyMHz: number;
//   frequencyCompatible: boolean;
// }

// export interface DirectionalCoverageMetrics extends DirectionalLinkParameters {
//   eirpDbm: number;
//   eirpWatts: number;
//   rssiDbm: number;
//   fsplDb: number;
//   atmosphericLossDb: number;
//   snrDb: number;
//   noiseFloorDbm: number;
//   modulationGrade: string;
//   coverageRangeMeters: number;
// }

// export function getDirectionalLinkParameters(
//   currentAntenna: AntennaConfig,
//   peerAntenna: AntennaConfig,
//   currentAntennaGainDbi: number,
//   rfEnvironment?: RFEnvironmentConfig,
// ): DirectionalLinkParameters {
//   const currentIsTransmitter = currentAntenna.role === "transmitter";
//   const txAntenna = currentIsTransmitter ? currentAntenna : peerAntenna;
//   const rxAntenna = currentIsTransmitter ? peerAntenna : currentAntenna;
//   const bandwidthMHz = Math.max(0, rfEnvironment?.bandwidthMHz ?? 20);

//   return {
//     txAntenna,
//     rxAntenna,
//     txPowerMilliwatts: txAntenna.powerMilliwatts,
//     txGainDbi: currentIsTransmitter ? currentAntennaGainDbi : txAntenna.gainDbi,
//     rxGainDbi: currentIsTransmitter ? rxAntenna.gainDbi : currentAntennaGainDbi,
//     frequencyMHz: txAntenna.frequencyMHz,
//     // Match the same simple channel-overlap rule used by the link-budget model.
//     frequencyCompatible:
//       Math.abs(txAntenna.frequencyMHz - rxAntenna.frequencyMHz) <=
//       bandwidthMHz / 2,
//   };
// }

// export function calculateDirectionalCoverageRangeMeters(
//   currentAntenna: AntennaConfig,
//   peerAntenna: AntennaConfig,
//   currentAntennaGainDbi: number,
//   rxSensitivityDbm: number,
//   rfEnvironment?: RFEnvironmentConfig,
// ): number {
//   if (!currentAntenna.enabled || !peerAntenna.enabled) return 0.1;

//   const link = getDirectionalLinkParameters(
//     currentAntenna,
//     peerAntenna,
//     currentAntennaGainDbi,
//     rfEnvironment,
//   );

//   // A frequency mismatch means this modeled pair has no usable coverage.
//   if (!link.frequencyCompatible) return 0.1;

//   return calculateMaxCoverageRange(
//     link.txPowerMilliwatts,
//     link.txGainDbi,
//     link.frequencyMHz,
//     rxSensitivityDbm,
//     link.rxGainDbi,
//     rfEnvironment?.weather ?? "clear",
//   );
// }

// /**
//  * The pattern models normalize their main beam to the configured peak gainDbi.
//  * This provides a conservative scene bound without scanning every mesh vertex.
//  */
// export function calculateMaximumDirectionalCoverageRangeMeters(
//   currentAntenna: AntennaConfig,
//   peerAntenna: AntennaConfig,
//   rxSensitivityDbm: number,
//   rfEnvironment?: RFEnvironmentConfig,
// ): number {
//   return calculateDirectionalCoverageRangeMeters(
//     currentAntenna,
//     peerAntenna,
//     currentAntenna.gainDbi,
//     rxSensitivityDbm,
//     rfEnvironment,
//   );
// }

// export function calculateDirectionalCoverageMetrics(
//   currentAntenna: AntennaConfig,
//   peerAntenna: AntennaConfig,
//   currentAntennaGainDbi: number,
//   evaluationDistanceMeters: number,
//   rxSensitivityDbm: number,
//   rfEnvironment?: RFEnvironmentConfig,
// ): DirectionalCoverageMetrics {
//   const link = getDirectionalLinkParameters(
//     currentAntenna,
//     peerAntenna,
//     currentAntennaGainDbi,
//     rfEnvironment,
//   );
//   const weather = rfEnvironment?.weather ?? "clear";
//   const bandwidthHz = Math.max(1e3, (rfEnvironment?.bandwidthMHz ?? 20) * 1e6);
//   const noiseFigureDb = rfEnvironment?.noiseFigureDb ?? 5;
//   const safeDistance = Math.max(0.05, evaluationDistanceMeters);

//   const eirp = calculateEIRP(link.txPowerMilliwatts, link.txGainDbi);
//   const received = calculateReceivedPowerDbm(
//     link.txPowerMilliwatts,
//     link.txGainDbi,
//     link.rxGainDbi,
//     safeDistance,
//     link.frequencyMHz,
//     weather,
//   );
//   const snr = calculateSNR(received.rssiDbm, bandwidthHz, noiseFigureDb);
//   const coverageRangeMeters =
//     currentAntenna.enabled && peerAntenna.enabled && link.frequencyCompatible
//       ? calculateMaxCoverageRange(
//           link.txPowerMilliwatts,
//           link.txGainDbi,
//           link.frequencyMHz,
//           rxSensitivityDbm,
//           link.rxGainDbi,
//           weather,
//         )
//       : 0.1;

//   return {
//     ...link,
//     eirpDbm: eirp.eirpDbm,
//     eirpWatts: eirp.eirpWatts,
//     rssiDbm: received.rssiDbm,
//     fsplDb: received.fsplDb,
//     atmosphericLossDb: received.atmosphericLossDb,
//     snrDb: snr.snrDb,
//     noiseFloorDbm: snr.noiseFloorDbm,
//     modulationGrade: snr.modulationGrade,
//     coverageRangeMeters,
//   };
// }
import { AntennaConfig, RFEnvironmentConfig } from "../types/antenna";
import { getAntennaPeakGainDbi } from "./radiationPatterns";
import {
  calculateMaxCoverageRange,
  calculateReceivedPowerDbm,
  calculateSNR,
  calculateEIRP,
} from "./rfPhysics";

/**
 * A direction-dependent link budget for the antenna whose lobe is being built.
 *
 * TX lobe:
 *   - the hovered direction supplies TX gain
 *   - the remote RX is assumed to be aligned for its configured peak gain
 *
 * RX lobe:
 *   - the hovered direction supplies RX gain (reciprocal antenna pattern)
 *   - the remote TX is assumed to be aligned for its configured peak gain
 *
 * This creates a potential-coverage envelope. It is not a prediction of the
 * current fixed-position TX-to-RX link; that is calculated by the Link Budget HUD.
 */
export interface DirectionalLinkParameters {
  txAntenna: AntennaConfig;
  rxAntenna: AntennaConfig;
  txPowerMilliwatts: number;
  txGainDbi: number;
  rxGainDbi: number;
  frequencyMHz: number;
  frequencyCompatible: boolean;
}

export interface DirectionalCoverageMetrics extends DirectionalLinkParameters {
  eirpDbm: number;
  eirpWatts: number;
  rssiDbm: number;
  fsplDb: number;
  atmosphericLossDb: number;
  snrDb: number;
  noiseFloorDbm: number;
  modulationGrade: string;
  coverageRangeMeters: number;
}

export function getDirectionalLinkParameters(
  currentAntenna: AntennaConfig,
  peerAntenna: AntennaConfig,
  currentAntennaGainDbi: number,
  rfEnvironment?: RFEnvironmentConfig,
): DirectionalLinkParameters {
  const currentIsTransmitter = currentAntenna.role === "transmitter";
  const txAntenna = currentIsTransmitter ? currentAntenna : peerAntenna;
  const rxAntenna = currentIsTransmitter ? peerAntenna : currentAntenna;
  const complementaryRoles =
    (currentAntenna.role === "transmitter" &&
      peerAntenna.role === "receiver") ||
    (currentAntenna.role === "receiver" && peerAntenna.role === "transmitter");
  const bandwidthMHz = Math.max(0, rfEnvironment?.bandwidthMHz ?? 20);

  return {
    txAntenna,
    rxAntenna,
    txPowerMilliwatts: txAntenna.powerMilliwatts,
    txGainDbi: currentIsTransmitter
      ? currentAntennaGainDbi
      : getAntennaPeakGainDbi(txAntenna),
    rxGainDbi: currentIsTransmitter
      ? getAntennaPeakGainDbi(rxAntenna)
      : currentAntennaGainDbi,
    frequencyMHz: txAntenna.frequencyMHz,
    // Match the same simple channel-overlap rule used by the link-budget model.
    frequencyCompatible:
      complementaryRoles &&
      Number.isFinite(txAntenna.frequencyMHz) &&
      Number.isFinite(rxAntenna.frequencyMHz) &&
      txAntenna.frequencyMHz > 0 &&
      rxAntenna.frequencyMHz > 0 &&
      Math.abs(txAntenna.frequencyMHz - rxAntenna.frequencyMHz) <=
        bandwidthMHz / 2,
  };
}

export function calculateDirectionalCoverageRangeMeters(
  currentAntenna: AntennaConfig,
  peerAntenna: AntennaConfig,
  currentAntennaGainDbi: number,
  rxSensitivityDbm: number,
  rfEnvironment?: RFEnvironmentConfig,
): number {
  if (!currentAntenna.enabled || !peerAntenna.enabled) return 0;

  const link = getDirectionalLinkParameters(
    currentAntenna,
    peerAntenna,
    currentAntennaGainDbi,
    rfEnvironment,
  );

  // A frequency mismatch means this modeled pair has no usable coverage.
  if (!link.frequencyCompatible) return 0;

  return calculateMaxCoverageRange(
    link.txPowerMilliwatts,
    link.txGainDbi,
    link.frequencyMHz,
    rxSensitivityDbm,
    link.rxGainDbi,
    rfEnvironment?.weather ?? "clear",
  );
}

/**
 * The pattern models normalize their main beam to the configured peak gainDbi.
 * This provides a conservative scene bound without scanning every mesh vertex.
 */
export function calculateMaximumDirectionalCoverageRangeMeters(
  currentAntenna: AntennaConfig,
  peerAntenna: AntennaConfig,
  rxSensitivityDbm: number,
  rfEnvironment?: RFEnvironmentConfig,
): number {
  return calculateDirectionalCoverageRangeMeters(
    currentAntenna,
    peerAntenna,
    getAntennaPeakGainDbi(currentAntenna),
    rxSensitivityDbm,
    rfEnvironment,
  );
}

export function calculateDirectionalCoverageMetrics(
  currentAntenna: AntennaConfig,
  peerAntenna: AntennaConfig,
  currentAntennaGainDbi: number,
  evaluationDistanceMeters: number,
  rxSensitivityDbm: number,
  rfEnvironment?: RFEnvironmentConfig,
  includeCoverageRange = true,
): DirectionalCoverageMetrics {
  const link = getDirectionalLinkParameters(
    currentAntenna,
    peerAntenna,
    currentAntennaGainDbi,
    rfEnvironment,
  );
  const weather = rfEnvironment?.weather ?? "clear";
  const bandwidthHz = Math.max(1e3, (rfEnvironment?.bandwidthMHz ?? 20) * 1e6);
  const noiseFigureDb = rfEnvironment?.noiseFigureDb ?? 5;
  const safeDistance = Math.max(0.05, evaluationDistanceMeters);

  const linkUsable =
    currentAntenna.enabled && peerAntenna.enabled && link.frequencyCompatible;
  const eirp = linkUsable
    ? calculateEIRP(link.txPowerMilliwatts, link.txGainDbi)
    : { eirpDbm: -Infinity, eirpWatts: 0 };
  const received = linkUsable
    ? calculateReceivedPowerDbm(
        link.txPowerMilliwatts,
        link.txGainDbi,
        link.rxGainDbi,
        safeDistance,
        link.frequencyMHz,
        weather,
      )
    : {
        rssiDbm: -Infinity,
        fsplDb: Infinity,
        atmosphericLossDb: 0,
        totalPathLossDb: Infinity,
      };
  const temperatureK = rfEnvironment?.temperatureK ?? 290;
  const snr = calculateSNR(
    received.rssiDbm,
    bandwidthHz,
    noiseFigureDb,
    temperatureK,
    rfEnvironment?.modulationMode,
    rfEnvironment?.selectedModulation,
  );
  const coverageRangeMeters = linkUsable && includeCoverageRange
    ? calculateMaxCoverageRange(
        link.txPowerMilliwatts,
        link.txGainDbi,
        link.frequencyMHz,
        rxSensitivityDbm,
        link.rxGainDbi,
        weather,
      )
    : 0;

  return {
    ...link,
    eirpDbm: eirp.eirpDbm,
    eirpWatts: eirp.eirpWatts,
    rssiDbm: received.rssiDbm,
    fsplDb: received.fsplDb,
    atmosphericLossDb: received.atmosphericLossDb,
    snrDb: snr.snrDb,
    noiseFloorDbm: snr.noiseFloorDbm,
    modulationGrade: snr.modulationGrade,
    coverageRangeMeters,
  };
}
