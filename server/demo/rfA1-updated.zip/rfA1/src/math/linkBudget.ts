// import * as THREE from "three";

// import type { AntennaConfig, RFEnvironmentConfig } from "../types/antenna";

// import {
//   calculateFSPL,
//   calculateAtmosphericLoss,
//   calculateNoiseFloor,
//   calculateSNR,
//   getWavelengthMm,
//   mwToDbm,
// } from "./rfPhysics";

// import { calculateRadiationPattern } from "./radiationPatterns";

// export type LinkBudgetIssue =
//   | "role-conflict"
//   | "antenna-disabled"
//   | "frequency-mismatch"
//   | "near-field";

// export interface AntennaPairLinkBudget {
//   tx: AntennaConfig;
//   rx: AntennaConfig;

//   distanceMeters: number;
//   minimumFarFieldDistanceMeters: number;

//   isValid: boolean;
//   issue: LinkBudgetIssue | null;

//   txPowerDbm: number;

//   txGainDbi: number | null;
//   rxGainDbi: number | null;

//   directionalEirpDbm: number | null;
//   txEirpWatts: number | null;

//   fsplDb: number | null;
//   atmosphericLossDb: number | null;
//   totalPathLossDb: number | null;

//   receivedPowerDbm: number | null;
//   noiseFloorDbm: number;
//   snrDb: number | null;

//   modulationGrade: string;

//   fadeMarginDb: number | null;
// }

// function calculateDistance(a: AntennaConfig, b: AntennaConfig): number {
//   return Math.hypot(
//     b.position[0] - a.position[0],
//     b.position[1] - a.position[1],
//     b.position[2] - a.position[2],
//   );
// }

// /**
//  * Approximate Fraunhofer far-field boundary.
//  *
//  * R = 2D² / lambda
//  *
//  * D is approximated from the largest configured
//  * physical antenna dimension.
//  */
// function getMinimumFarFieldDistance(antenna: AntennaConfig): number {
//   const wavelengthMeters = getWavelengthMm(antenna.frequencyMHz) / 1000;

//   if (wavelengthMeters <= 0) {
//     return Infinity;
//   }

//   const largestDimensionMeters =
//     Math.max(antenna.lengthMm, antenna.diameterMm) / 1000;

//   const fraunhoferDistance =
//     (2 * largestDimensionMeters ** 2) / wavelengthMeters;

//   return Math.max(0.1, fraunhoferDistance);
// }

// /**
//  * Calculate antenna gain towards a world-space direction.
//  *
//  * The inverse rotation converts the world direction
//  * into the antenna's local coordinate system.
//  */
// export function getDirectionalGainDbi(
//   antenna: AntennaConfig,
//   worldDirection: THREE.Vector3,
// ): number {
//   const [rotX, rotY, rotZ] = antenna.rotation;

//   // Match Canvas3D's Euler XYZ rotation convention.
//   const euler = new THREE.Euler(
//     THREE.MathUtils.degToRad(rotX),
//     THREE.MathUtils.degToRad(rotY),
//     THREE.MathUtils.degToRad(rotZ),
//     "XYZ",
//   );

//   const inverseRotation = new THREE.Quaternion().setFromEuler(euler).invert();

//   const localDirection = worldDirection
//     .clone()
//     .normalize()
//     .applyQuaternion(inverseRotation);

//   // Your existing radiationPatterns.ts uses Y
//   // as the polar axis.
//   const theta = Math.acos(THREE.MathUtils.clamp(localDirection.y, -1, 1));

//   const phi = Math.atan2(localDirection.z, localDirection.x);

//   return calculateRadiationPattern(theta, phi, antenna).gainDbi;
// }

// /**
//  * Calculate the actual one-way TX -> RX communication link.
//  */
// export function calculateAntennaPairLinkBudget(
//   antenna1: AntennaConfig,
//   antenna2: AntennaConfig,
//   environment: RFEnvironmentConfig,
//   rxSensitivityDbm: number,
// ): AntennaPairLinkBudget {
//   // Resolve transmitter and receiver from their roles.
//   const tx = antenna1.role === "transmitter" ? antenna1 : antenna2;

//   const rx = tx.id === antenna1.id ? antenna2 : antenna1;

//   const distanceMeters = calculateDistance(tx, rx);

//   const txPowerDbm = mwToDbm(tx.powerMilliwatts);

//   const bandwidthHz = environment.bandwidthMHz * 1e6;

//   const noiseFloorDbm =
//     Math.round(
//       calculateNoiseFloor(bandwidthHz, environment.noiseFigureDb) * 10,
//     ) / 10;

//   const minimumFarFieldDistanceMeters = Math.max(
//     getMinimumFarFieldDistance(tx),
//     getMinimumFarFieldDistance(rx),
//   );

//   // Default result when a valid RF link cannot be calculated.
//   const unavailable = (
//     issue: LinkBudgetIssue,
//     txGainDbi: number | null = null,
//     rxGainDbi: number | null = null,
//   ): AntennaPairLinkBudget => ({
//     tx,
//     rx,

//     distanceMeters,
//     minimumFarFieldDistanceMeters,

//     isValid: false,
//     issue,

//     txPowerDbm,

//     txGainDbi,
//     rxGainDbi,

//     directionalEirpDbm: null,
//     txEirpWatts: null,

//     fsplDb: null,
//     atmosphericLossDb: null,
//     totalPathLossDb: null,

//     receivedPowerDbm: null,
//     noiseFloorDbm,
//     snrDb: null,

//     modulationGrade: "Unavailable",

//     fadeMarginDb: null,
//   });

//   // Ensure one transmitter and one receiver.
//   if (tx.role !== "transmitter" || rx.role !== "receiver") {
//     return unavailable("role-conflict");
//   }

//   if (!tx.enabled || !rx.enabled) {
//     return unavailable("antenna-disabled");
//   }

//   // Simplified ideal channel-overlap check.
//   const frequencyOffsetMHz = Math.abs(tx.frequencyMHz - rx.frequencyMHz);

//   if (frequencyOffsetMHz > environment.bandwidthMHz / 2) {
//     return unavailable("frequency-mismatch");
//   }

//   // Direction from transmitter to receiver.
//   const txPosition = new THREE.Vector3(...tx.position);

//   const rxPosition = new THREE.Vector3(...rx.position);

//   const txToRx = rxPosition.clone().sub(txPosition);

//   // We cannot use a free-space far-field model
//   // when the antennas are too close.
//   if (distanceMeters <= minimumFarFieldDistanceMeters) {
//     return unavailable("near-field");
//   }

//   txToRx.normalize();

//   // TX gain towards the receiver.
//   const txGainDbi = getDirectionalGainDbi(tx, txToRx);

//   // RX gain towards the incoming transmitter signal.
//   const rxGainDbi = getDirectionalGainDbi(rx, txToRx.clone().negate());

//   // Directional EIRP.
//   const directionalEirpDbm = txPowerDbm + txGainDbi;

//   const txEirpWatts = Math.pow(10, (directionalEirpDbm - 30) / 10);

//   // Propagation losses.
//   const fsplDb = calculateFSPL(distanceMeters, tx.frequencyMHz);

//   const { totalAtmosphericLossDb } = calculateAtmosphericLoss(
//     distanceMeters,
//     tx.frequencyMHz,
//     environment.weather,
//   );

//   const totalPathLossDb = fsplDb + totalAtmosphericLossDb;

//   // Received power at the RX antenna.
//   const receivedPowerDbm = txPowerDbm + txGainDbi + rxGainDbi - totalPathLossDb;

//   // Calculate SNR using the receiver noise figure.
//   const snrResult = calculateSNR(
//     receivedPowerDbm,
//     bandwidthHz,
//     environment.noiseFigureDb,
//   );

//   const fadeMarginDb = receivedPowerDbm - rxSensitivityDbm;

//   return {
//     tx,
//     rx,

//     distanceMeters,
//     minimumFarFieldDistanceMeters,

//     isValid: true,
//     issue: null,

//     txPowerDbm,

//     txGainDbi,
//     rxGainDbi,

//     directionalEirpDbm,
//     txEirpWatts,

//     fsplDb,
//     atmosphericLossDb: totalAtmosphericLossDb,
//     totalPathLossDb,

//     receivedPowerDbm,
//     noiseFloorDbm: snrResult.noiseFloorDbm,
//     snrDb: snrResult.snrDb,

//     modulationGrade: snrResult.modulationGrade,

//     fadeMarginDb,
//   };
// }
import * as THREE from "three";

import type { AntennaConfig, RFEnvironmentConfig } from "../types/antenna";

import {
  calculateFSPL,
  calculateAtmosphericLoss,
  calculateNoiseFloor,
  calculateSNR,
  getWavelengthMm,
  mwToDbm,
} from "./rfPhysics";

import { calculateRadiationPattern } from "./radiationPatterns";

export type LinkBudgetIssue =
  | "role-conflict"
  | "antenna-disabled"
  | "frequency-mismatch"
  | "near-field";

export interface AntennaPairLinkBudget {
  tx: AntennaConfig;
  rx: AntennaConfig;

  distanceMeters: number;
  minimumFarFieldDistanceMeters: number;

  isValid: boolean;
  issue: LinkBudgetIssue | null;

  txPowerDbm: number;

  txGainDbi: number | null;
  rxGainDbi: number | null;

  directionalEirpDbm: number | null;
  txEirpWatts: number | null;

  fsplDb: number | null;
  atmosphericLossDb: number | null;
  totalPathLossDb: number | null;

  receivedPowerDbm: number | null;
  noiseFloorDbm: number;
  snrDb: number | null;

  modulationGrade: string;

  fadeMarginDb: number | null;
}

function calculateDistance(a: AntennaConfig, b: AntennaConfig): number {
  return Math.hypot(
    b.position[0] - a.position[0],
    b.position[1] - a.position[1],
    b.position[2] - a.position[2],
  );
}

/**
 * Approximate Fraunhofer far-field boundary.
 *
 * R = 2D² / lambda
 *
 * D is approximated from the largest configured
 * physical antenna dimension.
 */
function getMinimumFarFieldDistance(antenna: AntennaConfig): number {
  const wavelengthMeters = getWavelengthMm(antenna.frequencyMHz) / 1000;

  if (wavelengthMeters <= 0) {
    return Infinity;
  }

  const wavelengthMm = wavelengthMeters * 1000;
  const largestDimensionMm = (() => {
    switch (antenna.type) {
      case "monopole":
        return Math.max(
          antenna.lengthMm,
          antenna.monopoleGroundPlaneDiameterMm ?? wavelengthMm * 0.5,
        );
      case "patch": {
        const margin = antenna.patchGroundMarginMm ?? 8;
        return Math.max(
          (antenna.patchLengthMm ?? antenna.lengthMm) + 2 * margin,
          (antenna.patchWidthMm ?? antenna.diameterMm) + 2 * margin,
        );
      }
      case "yagi":
        return Math.max(antenna.lengthMm, wavelengthMm / 2);
      case "horn":
        return Math.max(
          antenna.lengthMm,
          antenna.hornApertureWidthMm ?? antenna.diameterMm,
          antenna.hornApertureHeightMm ?? antenna.diameterMm * 0.8,
        );
      case "helical":
        return Math.max(
          (antenna.helixTurns ?? 8) *
            (antenna.helixPitchMm ?? wavelengthMm * 0.25),
          antenna.helixReflectorDiameterMm ?? wavelengthMm * 1.2,
        );
      case "isotropic":
        return 0;
      case "dipole":
      default:
        return Math.max(antenna.lengthMm, antenna.diameterMm);
    }
  })();
  const largestDimensionMeters = largestDimensionMm / 1000;

  const fraunhoferDistance =
    (2 * largestDimensionMeters ** 2) / wavelengthMeters;

  return Math.max(0.1, fraunhoferDistance);
}

/**
 * Calculate antenna gain towards a world-space direction.
 *
 * The inverse rotation converts the world direction
 * into the antenna's local coordinate system.
 */
export function getDirectionalGainDbi(
  antenna: AntennaConfig,
  worldDirection: THREE.Vector3,
): number {
  const [rotX, rotY, rotZ] = antenna.rotation;

  // Match Canvas3D's Euler XYZ rotation convention.
  const euler = new THREE.Euler(
    THREE.MathUtils.degToRad(rotX),
    THREE.MathUtils.degToRad(rotY),
    THREE.MathUtils.degToRad(rotZ),
    "XYZ",
  );

  const inverseRotation = new THREE.Quaternion().setFromEuler(euler).invert();

  const localDirection = worldDirection
    .clone()
    .normalize()
    .applyQuaternion(inverseRotation);

  // Your existing radiationPatterns.ts uses Y
  // as the polar axis.
  const theta = Math.acos(THREE.MathUtils.clamp(localDirection.y, -1, 1));

  const phi = Math.atan2(localDirection.z, localDirection.x);

  return calculateRadiationPattern(theta, phi, antenna).gainDbi;
}

/**
 * Calculate the actual one-way TX -> RX communication link.
 */
export function calculateAntennaPairLinkBudget(
  antenna1: AntennaConfig,
  antenna2: AntennaConfig,
  environment: RFEnvironmentConfig,
  rxSensitivityDbm: number,
): AntennaPairLinkBudget {
  // Resolve transmitter and receiver from their roles.
  const tx = antenna1.role === "transmitter" ? antenna1 : antenna2;

  const rx = tx.id === antenna1.id ? antenna2 : antenna1;

  const distanceMeters = calculateDistance(tx, rx);

  const txPowerDbm = mwToDbm(tx.powerMilliwatts);

  const bandwidthHz = environment.bandwidthMHz * 1e6;

  const noiseFloorDbm =
    Math.round(
      calculateNoiseFloor(
        bandwidthHz,
        environment.noiseFigureDb,
        environment.temperatureK,
      ) * 10,
    ) / 10;
  const unavailableModulation = calculateSNR(
    -Infinity,
    bandwidthHz,
    environment.noiseFigureDb,
    environment.temperatureK,
    environment.modulationMode,
    environment.selectedModulation,
  ).modulationGrade;

  const minimumFarFieldDistanceMeters = Math.max(
    getMinimumFarFieldDistance(tx),
    getMinimumFarFieldDistance(rx),
  );

  // Default result when a valid RF link cannot be calculated.
  const unavailable = (
    issue: LinkBudgetIssue,
    txGainDbi: number | null = null,
    rxGainDbi: number | null = null,
  ): AntennaPairLinkBudget => ({
    tx,
    rx,

    distanceMeters,
    minimumFarFieldDistanceMeters,

    isValid: false,
    issue,

    txPowerDbm,

    txGainDbi,
    rxGainDbi,

    directionalEirpDbm: null,
    txEirpWatts: null,

    fsplDb: null,
    atmosphericLossDb: null,
    totalPathLossDb: null,

    receivedPowerDbm: null,
    noiseFloorDbm,
    snrDb: null,

    modulationGrade: unavailableModulation,

    fadeMarginDb: null,
  });

  // Ensure one transmitter and one receiver.
  if (tx.role !== "transmitter" || rx.role !== "receiver") {
    return unavailable("role-conflict");
  }

  if (!tx.enabled || !rx.enabled) {
    return unavailable("antenna-disabled");
  }

  // Simplified ideal channel-overlap check.
  const frequencyOffsetMHz = Math.abs(tx.frequencyMHz - rx.frequencyMHz);

  if (frequencyOffsetMHz > environment.bandwidthMHz / 2) {
    return unavailable("frequency-mismatch");
  }

  // Direction from transmitter to receiver.
  const txPosition = new THREE.Vector3(...tx.position);

  const rxPosition = new THREE.Vector3(...rx.position);

  const txToRx = rxPosition.clone().sub(txPosition);

  // We cannot use a free-space far-field model
  // when the antennas are too close.
  if (distanceMeters <= minimumFarFieldDistanceMeters) {
    return unavailable("near-field");
  }

  txToRx.normalize();

  // TX gain towards the receiver.
  const txGainDbi = getDirectionalGainDbi(tx, txToRx);

  // RX gain towards the incoming transmitter signal.
  const rxGainDbi = getDirectionalGainDbi(rx, txToRx.clone().negate());

  // Directional EIRP.
  const directionalEirpDbm = txPowerDbm + txGainDbi;

  const txEirpWatts = Math.pow(10, (directionalEirpDbm - 30) / 10);

  // Propagation losses.
  const fsplDb = calculateFSPL(distanceMeters, tx.frequencyMHz);

  const { totalAtmosphericLossDb } = calculateAtmosphericLoss(
    distanceMeters,
    tx.frequencyMHz,
    environment.weather,
  );

  const totalPathLossDb = fsplDb + totalAtmosphericLossDb;

  // Received power at the RX antenna.
  const receivedPowerDbm = txPowerDbm + txGainDbi + rxGainDbi - totalPathLossDb;

  // Calculate SNR using the receiver noise figure.
  const snrResult = calculateSNR(
    receivedPowerDbm,
    bandwidthHz,
    environment.noiseFigureDb,
    environment.temperatureK,
    environment.modulationMode,
    environment.selectedModulation,
  );

  const fadeMarginDb = receivedPowerDbm - rxSensitivityDbm;

  return {
    tx,
    rx,

    distanceMeters,
    minimumFarFieldDistanceMeters,

    isValid: true,
    issue: null,

    txPowerDbm,

    txGainDbi,
    rxGainDbi,

    directionalEirpDbm,
    txEirpWatts,

    fsplDb,
    atmosphericLossDb: totalAtmosphericLossDb,
    totalPathLossDb,

    receivedPowerDbm,
    noiseFloorDbm: snrResult.noiseFloorDbm,
    snrDb: snrResult.snrDb,

    modulationGrade: snrResult.modulationGrade,

    fadeMarginDb,
  };
}
