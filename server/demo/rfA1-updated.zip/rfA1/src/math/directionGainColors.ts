import * as THREE from "three";
import type { AntennaConfig } from "../types/antenna";
import { getAntennaPeakGainDbi } from "./radiationPatterns";

export interface GainColorScale {
  minDbi: number;
  maxDbi: number;
}

/**
 * Build ONE absolute dBi scale for both antenna lobes.
 * Keep both lobes comparable in absolute dBi. The low end shows a 30 dB
 * pattern window below the weaker antenna's rated peak.
 */
export function getSharedGainColorScale(
  antennaA: AntennaConfig,
  antennaB: AntennaConfig,
): GainColorScale {
  const peakA = getAntennaPeakGainDbi(antennaA);
  const peakB = getAntennaPeakGainDbi(antennaB);
  const minPeakDbi = Math.min(peakA, peakB);
  const maxPeakDbi = Math.max(peakA, peakB);

  return {
    minDbi: minPeakDbi - 30,
    maxDbi: maxPeakDbi,
  };
}

/**
 * Map a real directional gain value to a fixed blue -> cyan -> green scale.
 * Blue is always the low end; green is always the high end.
 */
export function getDirectionalGainColor(
  gainDbi: number,
  scale: GainColorScale,
): THREE.Color {
  const span = Math.max(0.001, scale.maxDbi - scale.minDbi);
  const t = THREE.MathUtils.clamp((gainDbi - scale.minDbi) / span, 0, 1);

  const blue = new THREE.Color("#2563eb");
  const cyan = new THREE.Color("#06b6d4");
  const green = new THREE.Color("#22c55e");

  if (t <= 0.5) {
    return blue.lerp(cyan, t * 2);
  }

  return cyan.lerp(green, (t - 0.5) * 2);
}
