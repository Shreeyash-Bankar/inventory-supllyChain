import * as THREE from 'three';
import { ColormapType } from '../types/antenna';

export function getColorFromColormap(valNorm: number, type: ColormapType = 'turbo'): THREE.Color {
  const t = Math.max(0, Math.min(1, valNorm));

  switch (type) {
    case 'turbo': {
      // RF strength palette: blue is weakest and green is strongest. Red and
      // yellow sit in the middle so the lobe reads like a strength scale.
      const stops = [
        { at: 0, color: new THREE.Color('#2563eb') },
        { at: 0.25, color: new THREE.Color('#06b6d4') },
        { at: 0.5, color: new THREE.Color('#ef4444') },
        { at: 0.75, color: new THREE.Color('#facc15') },
        { at: 1, color: new THREE.Color('#22c55e') },
      ];
      const upperIndex = stops.findIndex((stop) => stop.at >= t);
      if (upperIndex <= 0) return stops[0].color.clone();
      const lower = stops[upperIndex - 1];
      const upper = stops[upperIndex];
      return lower.color
        .clone()
        .lerp(upper.color, (t - lower.at) / (upper.at - lower.at));
    }

    case 'jet': {
      // Classic Jet: Blue -> Cyan -> Green -> Yellow -> Red
      let r = Math.min(1, Math.max(0, 1.5 - Math.abs(t * 4 - 3)));
      let g = Math.min(1, Math.max(0, 1.5 - Math.abs(t * 4 - 2)));
      let b = Math.min(1, Math.max(0, 1.5 - Math.abs(t * 4 - 1)));
      return new THREE.Color(r, g, b);
    }

    case 'viridis': {
      // Viridis colormap approximation
      const r = Math.max(0, Math.min(1, -0.009 + 0.38 * t + 0.62 * t * t));
      const g = Math.max(0, Math.min(1, 0.05 + 1.25 * t - 0.45 * t * t));
      const b = Math.max(0, Math.min(1, 0.35 + 0.8 * (1 - t) - 0.7 * Math.pow(t - 0.5, 2)));
      return new THREE.Color(r, g, b);
    }

    case 'plasma': {
      const r = Math.max(0, Math.min(1, 0.05 + 1.2 * t - 0.3 * t * t));
      const g = Math.max(0, Math.min(1, 0.01 + 0.2 * t + 0.8 * t * t * t));
      const b = Math.max(0, Math.min(1, 0.5 + 0.5 * Math.sin(t * Math.PI * 0.8)));
      return new THREE.Color(r, g, b);
    }

    case 'electric':
    default: {
      // Deep blue/purple -> Cyan -> Bright Yellow -> White
      let r = 0, g = 0, b = 0;
      if (t < 0.25) {
        b = t * 4;
      } else if (t < 0.5) {
        b = 1;
        g = (t - 0.25) * 4;
      } else if (t < 0.75) {
        g = 1;
        b = 1 - (t - 0.5) * 4;
        r = (t - 0.5) * 4;
      } else {
        r = 1;
        g = 1;
        b = (t - 0.75) * 4;
      }
      return new THREE.Color(r, g, b);
    }
  }
}
