import {
  AntennaConfig,
  AntennaType,
  MeasuredPatternData,
  MeasuredPatternPoint,
} from "../types/antenna";
import { getWavelengthMm } from "./rfPhysics";

export interface PatternSample {
  /** Peak gain plus the pattern in dB. Peak of the pattern is `gainDbi`. */
  gainDbi: number;
  /**
   * Normalized power pattern, 1 at the main-beam peak and 0 in a true null.
   * This is gain relative to the peak, not electric-field magnitude.
   */
  relativeLinear: number;
  /** Same normalized power, kept for callers that size a pattern radius. */
  radius: number;
}

/**
 * Local frame used everywhere (mesh, polar cuts, link budget):
 * theta is polar angle from +Y, phi is azimuth in the XZ plane.
 * +Y is the wire axis of a dipole/monopole.
 * +X is boresight for patch, Yagi, horn, and axial helix.
 */

const clamp = (value: number, min: number, max: number) =>
  Math.max(min, Math.min(max, value));

const clamp01 = (value: number) => clamp(value, 0, 1);

interface MeasuredPatternGrid {
  thetaAngles: number[];
  phiAngles: number[];
  gainLinearByTheta: Float64Array[];
  peakGainDbi: number;
}

const measuredPatternGridCache = new WeakMap<
  MeasuredPatternPoint[],
  MeasuredPatternGrid | null
>();

function normalizeAzimuth(phiDeg: number): number {
  return ((phiDeg % 360) + 360) % 360;
}

function getMeasuredPatternGrid(
  points: MeasuredPatternPoint[] | undefined,
): MeasuredPatternGrid | null {
  if (!points || points.length === 0) return null;
  const cached = measuredPatternGridCache.get(points);
  if (cached !== undefined) return cached;

  const thetaAngles = [...new Set(points.map((point) => point.thetaDeg))].sort(
    (a, b) => a - b,
  );
  const phiAngles = [
    ...new Set(points.map((point) => normalizeAzimuth(point.phiDeg))),
  ].sort((a, b) => a - b);
  const invalid = (): null => {
    measuredPatternGridCache.set(points, null);
    return null;
  };

  if (
    thetaAngles.length < 3 ||
    phiAngles.length < 4 ||
    Math.abs(thetaAngles[0]) > 1e-6 ||
    Math.abs(thetaAngles[thetaAngles.length - 1] - 180) > 1e-6 ||
    points.length !== thetaAngles.length * phiAngles.length
  ) {
    return invalid();
  }

  const maxAzimuthGap = Math.max(
    ...phiAngles.slice(1).map((phi, index) => phi - phiAngles[index]),
    phiAngles[0] + 360 - phiAngles[phiAngles.length - 1],
  );
  if (maxAzimuthGap > 90) return invalid();

  const pointByAngle = new Map<string, MeasuredPatternPoint>();
  let peakGainDbi = -Infinity;
  for (const point of points) {
    if (
      !Number.isFinite(point.thetaDeg) ||
      !Number.isFinite(point.phiDeg) ||
      !Number.isFinite(point.gainDbi) ||
      point.thetaDeg < 0 ||
      point.thetaDeg > 180
    ) {
      return invalid();
    }
    const phi = normalizeAzimuth(point.phiDeg);
    const key = `${point.thetaDeg.toFixed(6)}:${phi.toFixed(6)}`;
    if (pointByAngle.has(key)) return invalid();
    pointByAngle.set(key, point);
    peakGainDbi = Math.max(peakGainDbi, point.gainDbi);
  }

  const gainLinearByTheta = thetaAngles.map((theta) => {
    const row = new Float64Array(phiAngles.length);
    for (let phiIndex = 0; phiIndex < phiAngles.length; phiIndex++) {
      const point = pointByAngle.get(
        `${theta.toFixed(6)}:${phiAngles[phiIndex].toFixed(6)}`,
      );
      if (!point) return null;
      row[phiIndex] = 10 ** (point.gainDbi / 10);
    }
    return row;
  });
  if (gainLinearByTheta.some((row) => row === null)) return invalid();

  const grid: MeasuredPatternGrid = {
    thetaAngles,
    phiAngles,
    gainLinearByTheta: gainLinearByTheta as Float64Array[],
    peakGainDbi,
  };
  measuredPatternGridCache.set(points, grid);
  return grid;
}

export function getAntennaDesignSignature(config: AntennaConfig): string {
  return [
    config.type,
    config.frequencyMHz,
    config.lengthMm,
    config.diameterMm,
    config.monopoleGroundPlaneDiameterMm,
    config.patchLengthMm,
    config.patchWidthMm,
    config.patchSubstrateEr,
    config.patchSubstrateThicknessMm,
    config.patchGroundMarginMm,
    config.patchFeedInsetMm,
    config.yagiElementCount,
    config.yagiDrivenElementLengthMm,
    config.yagiReflectorLengthMm,
    config.yagiDirectorLengthMm,
    config.hornApertureWidthMm,
    config.hornApertureHeightMm,
    config.hornThroatWidthMm,
    config.hornThroatHeightMm,
    config.helixTurns,
    config.helixPitchMm,
    config.helixCoilDiameterMm,
    config.helixWireDiameterMm,
    config.helixReflectorDiameterMm,
  ].join("|");
}

function getConfiguredMeasuredPattern(
  config: AntennaConfig,
): MeasuredPatternGrid | null {
  const data = config.measuredPattern;
  if (
    !data ||
    !Number.isFinite(data.frequencyMHz) ||
    data.designSignature !== getAntennaDesignSignature(config)
  ) {
    return null;
  }
  const frequencyToleranceMHz = Math.max(1e-6, data.frequencyMHz * 1e-6);
  if (Math.abs(config.frequencyMHz - data.frequencyMHz) > frequencyToleranceMHz) {
    return null;
  }
  return getMeasuredPatternGrid(data.points);
}

function findInterval(angles: number[], value: number): [number, number, number] {
  if (value <= angles[0]) return [0, 0, 0];
  const lastIndex = angles.length - 1;
  if (value >= angles[lastIndex]) return [lastIndex, lastIndex, 0];
  let low = 0;
  let high = lastIndex;
  while (low + 1 < high) {
    const middle = (low + high) >> 1;
    if (angles[middle] <= value) low = middle;
    else high = middle;
  }
  return [low, high, (value - angles[low]) / (angles[high] - angles[low])];
}

function sampleMeasuredPattern(
  grid: MeasuredPatternGrid,
  thetaDeg: number,
  phiDeg: number,
): number {
  const [thetaLow, thetaHigh, thetaMix] = findInterval(
    grid.thetaAngles,
    clamp(thetaDeg, 0, 180),
  );
  const phi = normalizeAzimuth(phiDeg);
  let searchLow = 0;
  let searchHigh = grid.phiAngles.length;
  while (searchLow < searchHigh) {
    const middle = (searchLow + searchHigh) >> 1;
    if (grid.phiAngles[middle] < phi) searchLow = middle + 1;
    else searchHigh = middle;
  }
  const phiUpper = searchLow === grid.phiAngles.length ? -1 : searchLow;
  let phiLowIndex: number;
  let phiHighIndex: number;
  let phiMix: number;
  if (phiUpper === 0) {
    phiLowIndex = grid.phiAngles.length - 1;
    phiHighIndex = 0;
    const lowerAngle = grid.phiAngles[phiLowIndex] - 360;
    phiMix = (phi - lowerAngle) / (grid.phiAngles[0] - lowerAngle);
  } else if (phiUpper === -1) {
    phiLowIndex = grid.phiAngles.length - 1;
    phiHighIndex = 0;
    const upperAngle = grid.phiAngles[0] + 360;
    phiMix = (phi - grid.phiAngles[phiLowIndex]) / (upperAngle - grid.phiAngles[phiLowIndex]);
  } else {
    phiLowIndex = phiUpper - 1;
    phiHighIndex = phiUpper;
    phiMix =
      (phi - grid.phiAngles[phiLowIndex]) /
      (grid.phiAngles[phiHighIndex] - grid.phiAngles[phiLowIndex]);
  }

  const lowRow = grid.gainLinearByTheta[thetaLow];
  const highRow = grid.gainLinearByTheta[thetaHigh];
  const lowPower =
    lowRow[phiLowIndex] * (1 - phiMix) + lowRow[phiHighIndex] * phiMix;
  const highPower =
    highRow[phiLowIndex] * (1 - phiMix) + highRow[phiHighIndex] * phiMix;
  const power = lowPower * (1 - thetaMix) + highPower * thetaMix;
  return 10 * Math.log10(Math.max(1e-30, power));
}

/**
 * Parse a full-sphere measured gain CSV with columns thetaDeg,phiDeg,gainDbi.
 * Angles use the app's local frame: theta from +Y, phi from +X toward +Z.
 */
export function parseMeasuredPatternCsv(
  csv: string,
): Omit<MeasuredPatternData, "designSignature"> {
  const lines = csv
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter((line) => line.length > 0 && !line.startsWith("#"));
  if (lines.length < 2) throw new Error("The file must contain a header and data rows.");
  const delimiter = lines[0].includes(";") ? ";" : ",";
  const headers = lines[0].split(delimiter).map((header) =>
    header.replace(/^\uFEFF/, "").toLowerCase().replace(/[ _()-]/g, ""),
  );
  const thetaIndex = headers.findIndex((header) => ["thetadeg", "theta"].includes(header));
  const phiIndex = headers.findIndex((header) => ["phideg", "phi"].includes(header));
  const gainIndex = headers.findIndex((header) => ["gaindbi", "gaindb", "gain"].includes(header));
  const frequencyIndex = headers.findIndex((header) => ["frequencymhz", "freqmhz"].includes(header));
  if (thetaIndex < 0 || phiIndex < 0 || gainIndex < 0 || frequencyIndex < 0) {
    throw new Error("CSV headers must identify frequencyMHz, thetaDeg, phiDeg, and gainDbi columns.");
  }

  const points: MeasuredPatternPoint[] = [];
  let frequencyMHz: number | null = null;
  for (let lineIndex = 1; lineIndex < lines.length; lineIndex++) {
    const cells = lines[lineIndex].split(delimiter).map((cell) => cell.trim());
    const thetaDeg = Number(cells[thetaIndex]);
    const phiDeg = Number(cells[phiIndex]);
    const gainDbi = Number(cells[gainIndex]);
    const rowFrequencyMHz = Number(cells[frequencyIndex]);
    if (![thetaDeg, phiDeg, gainDbi, rowFrequencyMHz].every(Number.isFinite)) {
      throw new Error(`Row ${lineIndex + 1} contains a non-numeric frequency, angle, or gain.`);
    }
    if (!(rowFrequencyMHz > 0)) throw new Error(`Row ${lineIndex + 1} has an invalid frequency.`);
    if (frequencyMHz === null) frequencyMHz = rowFrequencyMHz;
    else if (Math.abs(frequencyMHz - rowFrequencyMHz) > Math.max(1e-6, frequencyMHz * 1e-6)) {
      throw new Error("All rows in one file must use the same measurement frequency.");
    }
    points.push({ thetaDeg, phiDeg, gainDbi });
  }

  if (!getMeasuredPatternGrid(points)) {
    throw new Error(
      "Pattern data must be a complete full-sphere grid, include theta 0° and 180°, and have azimuth gaps no larger than 90°.",
    );
  }
  return { frequencyMHz: frequencyMHz!, points };
}

interface Direction {
  x: number;
  y: number;
  z: number;
}

function direction(theta: number, phi: number): Direction {
  const sinTheta = Math.sin(theta);
  const x = sinTheta * Math.cos(phi);
  const y = Math.cos(theta);
  const z = sinTheta * Math.sin(phi);
  const magnitude = Math.hypot(x, y, z);
  if (!(magnitude > 0)) return { x: 1, y: 0, z: 0 };
  return { x: x / magnitude, y: y / magnitude, z: z / magnitude };
}

function polarFromY(dir: Direction): number {
  return Math.acos(clamp(dir.y, -1, 1));
}

/** sin(u)/u with the removable limit 1 at the origin. */
function sinc(u: number): number {
  return Math.abs(u) < 1e-6 ? 1 : Math.sin(u) / u;
}

/**
 * Thin-wire sinusoidal current. `kHalf` is k*L/2 for a dipole of length L
 * (the usual Balanis argument). Peak is not 1; callers normalize.
 */
function wireField(polar: number, kHalf: number): number {
  const sinPolar = Math.sin(polar);
  if (sinPolar < 1e-6) return 0;
  if (kHalf < 1e-3) return sinPolar;
  return Math.abs(
    (Math.cos(kHalf * Math.cos(polar)) - Math.cos(kHalf)) / sinPolar,
  );
}

const wirePeakCache = new Map<string, number>();

function wirePeak(kHalf: number, upperOnly: boolean): number {
  const key = `${upperOnly ? "m" : "d"}:${kHalf.toFixed(6)}`;
  const cached = wirePeakCache.get(key);
  if (cached !== undefined) return cached;
  let peak = 0;
  const end = upperOnly ? Math.PI / 2 : Math.PI;
  for (let i = 0; i <= 720; i++) {
    peak = Math.max(peak, wireField((i / 720) * end, kHalf));
  }
  const safe = peak > 1e-8 ? peak : 1;
  if (wirePeakCache.size > 512) wirePeakCache.clear();
  wirePeakCache.set(key, safe);
  return safe;
}

/** Half-wave dipole power, already 1 at the horizon and 0 on the wire axis. */
function halfWavePower(polar: number): number {
  const sinPolar = Math.sin(polar);
  if (sinPolar < 1e-5) return 0;
  const field = Math.cos((Math.PI / 2) * Math.cos(polar)) / sinPolar;
  return field * field;
}

function smoothstep(edge0: number, edge1: number, value: number): number {
  const t = clamp01((value - edge0) / (edge1 - edge0));
  return t * t * (3 - 2 * t);
}

/** cos^n power pattern whose half-power points sit at ±halfAngleRad from +X. */
function boresightExponent(halfAngleRad: number): number {
  const half = clamp(halfAngleRad, (4 * Math.PI) / 180, (80 * Math.PI) / 180);
  const cosine = Math.cos(half);
  if (cosine <= 0.02) return 1;
  return Math.log(0.5) / Math.log(cosine);
}

function wirePower(
  dir: Direction,
  lengthMm: number,
  diameterMm: number,
  wavelengthMm: number,
  monopole: boolean,
  groundPlaneDiameterMm = 0,
): number {
  const polar = polarFromY(dir);

  const electrical = lengthMm / wavelengthMm;
  // Image theory: monopole height h matches a dipole of length 2h, so the
  // half-length argument is k*h rather than k*h/2.
  const kHalf = monopole ? 2 * Math.PI * electrical : Math.PI * electrical;
  const field = wireField(polar, kHalf) / wirePeak(kHalf, monopole);
  const power = field * field;
  if (monopole && dir.y < -1e-4) {
    // A finite circular ground plane leaks and diffracts energy into the rear
    // hemisphere. Larger electrical diameter approaches the ideal image plane.
    const groundWavelengths = Math.max(0, groundPlaneDiameterMm / wavelengthMm);
    const frontToBackDb = clamp(5 + 13 * groundWavelengths, 5, 24);
    const rearPower = power * 10 ** (-frontToBackDb / 10);
    const edgeWeight = smoothstep(-0.08, 0.04, dir.y);
    return rearPower * (1 - edgeWeight) + power * edgeWeight;
  }
  // Preserve the model's true nulls; do not add an artificial power floor.
  return power;
}

/**
 * Rectangular patch, cavity / two-slot model.
 * Length is the E-plane (resonant) dimension along Y.
 * Diameter is the H-plane width along Z.
 * Infinite-ground principal planes, plus a finite-ground back lobe.
 */
function patchPower(
  dir: Direction,
  lengthMm: number,
  widthMm: number,
  groundLengthMm: number,
  groundWidthMm: number,
  wavelengthMm: number,
): number {
  const { x, y, z } = dir;
  const transverse = Math.hypot(y, z);
  const obliquity =
    transverse < 1e-6 ? 1 : (y * y + x * x * z * z) / (transverse * transverse);
  const ePlane = Math.cos((Math.PI * lengthMm * y) / wavelengthMm);
  const hArgument = (Math.PI * widthMm * z) / wavelengthMm;
  const hPlane = sinc(hArgument);
  const front = x > 0 ? ePlane * ePlane * hPlane * hPlane * Math.max(0, obliquity) : 0;

  // Finite ground: about 16–20 dB front-to-back, stronger when the patch is wide.
  const groundElectricalSize = Math.min(
    groundLengthMm / wavelengthMm,
    groundWidthMm / wavelengthMm,
  );
  const frontToBackDb = clamp(5 + 14 * groundElectricalSize, 5, 24);
  const back =
    10 ** (-frontToBackDb / 10) * (0.35 + 0.65 * ((1 - x) / 2) ** 2);
  const forwardWeight = smoothstep(-0.06, 0.14, x);
  return forwardWeight * front + (1 - forwardWeight) * back;
}

/**
 * Yagi-Uda. Boom length sets the main-beam width (about 55°/sqrt(L/λ)).
 * Vertical elements multiply by a half-wave dipole factor, so the E-plane
 * is narrower than the H-plane and the wire axis stays a null.
 * Diameter only softens that element null.
 */
function yagiPower(
  dir: Direction,
  lengthMm: number,
  diameterMm: number,
  requestedElementCount: number,
  drivenElementLengthMm: number,
  reflectorLengthMm: number,
  directorLengthMm: number,
  wavelengthMm: number,
): number {
  const { x } = dir;
  const boomWavelengths = Math.max(0, lengthMm / wavelengthMm);
  // Match the physical model: reflector, driven element, and four directors
  // spread over the configured boom. End-fire phasing points the array +X.
  const elementCount = clamp(Math.round(requestedElementCount), 3, 16);
  const spacing = boomWavelengths / (elementCount - 1);
  const reflectorWavelengths = reflectorLengthMm / wavelengthMm;
  const directorWavelengths = directorLengthMm / wavelengthMm;
  const weights = Array.from({ length: elementCount }, (_, index) => {
    if (index === 0) {
      return clamp(0.82 + (reflectorWavelengths - 0.5) * 0.3, 0.6, 1);
    }
    if (index === 1) return 1;
    return clamp(
      0.97 - Math.abs(directorWavelengths - 0.45) * 0.4 - (index - 2) * 0.03,
      0.55,
      0.98,
    );
  });
  let arrayReal = 0;
  let arrayImaginary = 0;
  let weightTotal = 0;
  for (let n = 0; n < elementCount; n++) {
    const phase = 2 * Math.PI * spacing * (x - 1) * n;
    arrayReal += weights[n] * Math.cos(phase);
    arrayImaginary += weights[n] * Math.sin(phase);
    weightTotal += weights[n];
  }
  const arrayAmplitude = Math.hypot(arrayReal, arrayImaginary) / weightTotal;
  const arrayPower = arrayAmplitude * arrayAmplitude;

  const frontToBackDb = clamp(
    12 + 3.2 * boomWavelengths + 12 * (reflectorWavelengths - 0.5),
    8,
    28,
  );
  const back =
    x < 0 ? 10 ** (-frontToBackDb / 10) * Math.abs(x) ** 2 : 0;
  const element = wirePower(
    dir,
    drivenElementLengthMm,
    diameterMm,
    wavelengthMm,
    false,
  );
  // A Yagi reflector suppresses the rear array response while preserving
  // sidelobes produced by the six-element end-fire array.
  const directionalArray = x < 0 ? Math.min(arrayPower, back) : arrayPower;
  return directionalArray * element;
}

/**
 * Pyramidal horn along +X.
 * Diameter is the mouth width. Length is the axial length and sets flare
 * phase error (a short horn of the same mouth has a wider, messier beam).
 */
function hornPower(
  dir: Direction,
  lengthMm: number,
  apertureWidthMm: number,
  apertureHeightMm: number,
  throatWidthMm: number,
  throatHeightMm: number,
  wavelengthMm: number,
): number {
  const { x, y, z } = dir;
  const aWavelengths = Math.max(0.05, apertureWidthMm / wavelengthMm);
  const bWavelengths = Math.max(0.05, apertureHeightMm / wavelengthMm);
  const axialWavelengths = Math.max(0.2, lengthMm / wavelengthMm);

  const thetaE = Math.atan2(y, Math.max(1e-6, x));
  const thetaH = Math.atan2(z, Math.max(1e-6, x));
  const uE = Math.PI * bWavelengths * Math.sin(thetaE);
  const uH = Math.PI * aWavelengths * Math.sin(thetaH);
  const ePlane = sinc(uE);
  // TE10 H-plane factor. The 0/0 limit at u = ±π/2 is π/4.
  const hRawDenominator = 1 - (4 * uH * uH) / Math.PI ** 2;
  const hPlane =
    Math.abs(hRawDenominator) < 1e-4
      ? Math.PI / 4
      : Math.cos(uH) / hRawDenominator;
  const obliquity = (1 + Math.max(0, x)) / 2;
  let field = Math.abs(ePlane * hPlane) * obliquity;

  // Quadratic phase error s = a^2 / (8 λ R). Large error broadens the beam
  // without moving the peak off boresight.
  const phaseErrorWidth =
    ((apertureWidthMm - throatWidthMm) / wavelengthMm) ** 2 /
    (8 * axialWavelengths);
  const phaseErrorHeight =
    ((apertureHeightMm - throatHeightMm) / wavelengthMm) ** 2 /
    (8 * axialWavelengths);
  const phaseError = Math.max(phaseErrorWidth, phaseErrorHeight);
  const broaden = clamp((phaseError - 0.2) / 1.4, 0, 0.65);
  field = field ** (1 - broaden) * obliquity ** broaden;

  const front = x > 0 ? Math.min(1, field * field) : 0;
  const back = 10 ** (-2.7) * (0.4 + 0.6 * ((1 - x) / 2) ** 2);
  const forwardWeight = smoothstep(-0.02, 0.08, x);
  return forwardWeight * front + (1 - forwardWeight) * back;
}

/**
 * Helix along +X.
 * Diameter is the coil diameter: near λ/π the helix is axial-mode (endfire);
 * a small circumference falls back to normal mode (doughnut around the axis).
 * Length sets the number of turns at a 0.25λ pitch.
 */
function helicalRaw(
  dir: Direction,
  turns: number,
  pitchMm: number,
  coilDiameterMm: number,
  reflectorDiameterMm: number,
  wavelengthMm: number,
): number {
  const { x } = dir;
  const circumference = (Math.PI * coilDiameterMm) / wavelengthMm;
  const normalizedTurns = clamp(turns, 1, 40);
  const axiality =
    smoothstep(0.45, 0.8, circumference) *
    (1 - smoothstep(1.35, 2.0, circumference)) *
    smoothstep(2, 4, normalizedTurns);

  const halfPowerRad =
    (104 /
      (Math.max(0.55, circumference) * Math.sqrt(normalizedTurns)) /
      2) *
    (Math.PI / 180);
  const exponent = boresightExponent(halfPowerRad);
  const axialFront = x >= 0 ? Math.max(0, x) ** exponent : 0;
  const reflectorElectricalSize = reflectorDiameterMm / wavelengthMm;
  const frontToBackDb = clamp(6 + 10 * reflectorElectricalSize, 6, 24);
  const axialBack =
    x < 0 ? 10 ** (-frontToBackDb / 10) * Math.abs(x) ** 2 : 0;
  const axial = axialFront + axialBack;
  // Normal mode radiates broadside; the reflector also suppresses rear power.
  const normalBack = 10 ** (-frontToBackDb / 10);
  const normal = Math.max(0, 1 - x * x) * (x < 0 ? normalBack : 1);
  return axiality * axial + (1 - axiality) * normal;
}

const shapePeakCache = new Map<string, number>();

function shapePeak(
  key: string,
  sample: (theta: number, phi: number) => number,
): number {
  const cached = shapePeakCache.get(key);
  if (cached !== undefined) return cached;
  let peak = 1e-9;
  for (let i = 0; i <= 72; i++) {
    const theta = (i / 72) * Math.PI;
    for (let j = 0; j <= 36; j++) {
      const phi = (j / 36) * 2 * Math.PI - Math.PI;
      peak = Math.max(peak, sample(theta, phi));
    }
  }
  if (shapePeakCache.size > 256) shapePeakCache.clear();
  shapePeakCache.set(key, peak);
  return peak;
}

function normalizedPower(
  theta: number,
  phi: number,
  config: AntennaConfig,
  wavelengthMm: number,
): number {
  const dir = direction(theta, phi);
  const { type, lengthMm, diameterMm } = config;
  const length = Math.max(0, lengthMm);
  const diameter = Math.max(0.05, diameterMm);

  switch (type as AntennaType) {
    case "dipole":
      return wirePower(dir, length, diameter, wavelengthMm, false);
    case "monopole":
      return wirePower(
        dir,
        length,
        diameter,
        wavelengthMm,
        true,
        config.monopoleGroundPlaneDiameterMm ?? wavelengthMm * 0.5,
      );
    case "patch": {
      const patchLength = config.patchLengthMm ?? Math.max(1, length);
      const patchWidth = config.patchWidthMm ?? diameter;
      const margin = config.patchGroundMarginMm ?? Math.min(patchLength, patchWidth) * 0.08;
      return patchPower(
        dir,
        patchLength,
        patchWidth,
        patchLength + margin * 2,
        patchWidth + margin * 2,
        wavelengthMm,
      );
    }
    case "yagi":
      return yagiPower(
        dir,
        length,
        diameter,
        config.yagiElementCount ?? 6,
        config.yagiDrivenElementLengthMm ?? wavelengthMm * 0.47,
        config.yagiReflectorLengthMm ?? wavelengthMm * 0.5,
        config.yagiDirectorLengthMm ?? wavelengthMm * 0.45,
        wavelengthMm,
      );
    case "horn":
      return hornPower(
        dir,
        length,
        config.hornApertureWidthMm ?? diameter,
        config.hornApertureHeightMm ?? diameter * 0.8,
        config.hornThroatWidthMm ?? diameter * 0.45,
        config.hornThroatHeightMm ?? diameter * 0.3,
        wavelengthMm,
      );
    case "helical": {
      const turns = config.helixTurns ?? length / (0.25 * wavelengthMm);
      const pitch = config.helixPitchMm ?? wavelengthMm * 0.25;
      const coilDiameter = config.helixCoilDiameterMm ?? diameter;
      const reflectorDiameter = config.helixReflectorDiameterMm ?? wavelengthMm * 1.2;
      const key = `helical:${turns.toFixed(3)}:${(pitch / wavelengthMm).toFixed(4)}:${(coilDiameter / wavelengthMm).toFixed(4)}:${(reflectorDiameter / wavelengthMm).toFixed(4)}`;
      const raw = helicalRaw(
        dir,
        turns,
        pitch,
        coilDiameter,
        reflectorDiameter,
        wavelengthMm,
      );
      const peak = shapePeak(key, (sampleTheta, samplePhi) =>
        helicalRaw(
          direction(sampleTheta, samplePhi),
          turns,
          pitch,
          coilDiameter,
          reflectorDiameter,
          wavelengthMm,
        ),
      );
      return clamp01(raw / peak);
    }
    case "isotropic":
    default:
      return 1;
  }
}

const estimatedGainCache = new Map<string, number>();

function getPatchDetuneEfficiency(config: AntennaConfig): number {
  const length = config.patchLengthMm ?? config.lengthMm;
  const width = config.patchWidthMm ?? config.diameterMm;
  const thickness = config.patchSubstrateThicknessMm ?? 1.6;
  const er = Math.max(1, config.patchSubstrateEr ?? 4.4);
  const effectiveEr =
    (er + 1) / 2 + (er - 1) / (2 * Math.sqrt(1 + (12 * thickness) / width));
  const ratio = width / thickness;
  const fringeRatio =
    (0.412 * ((effectiveEr + 0.3) * (ratio + 0.264))) /
    ((effectiveEr - 0.258) * (ratio + 0.8));
  const effectiveLength = length + 2 * thickness * fringeRatio;
  const resonantMHz = 299792.458 / (2 * effectiveLength * Math.sqrt(effectiveEr));
  const fractionalDetune =
    Math.abs(config.frequencyMHz - resonantMHz) / Math.max(1, resonantMHz);
  const estimatedFractionalBandwidth = clamp(
    1.5 * thickness / (length * Math.sqrt(effectiveEr)),
    0.005,
    0.15,
  );
  const detuneEfficiency =
    1 / (1 + (2 * fractionalDetune / estimatedFractionalBandwidth) ** 2);
  const feedFraction = clamp(
    (config.patchFeedInsetMm ?? length * 0.25) / Math.max(1, length),
    0,
    0.49,
  );
  const estimatedInputOhms = 300 * Math.cos(Math.PI * feedFraction) ** 2;
  const mismatchEfficiency =
    (4 * estimatedInputOhms * 50) / (estimatedInputOhms + 50) ** 2;
  return detuneEfficiency * clamp(mismatchEfficiency, 0, 1);
}

/** Estimated realized peak gain from pattern directivity and user-set efficiency. */
export function getAntennaPeakGainDbi(config: AntennaConfig): number {
  const measuredPattern = getConfiguredMeasuredPattern(config);
  if (measuredPattern) return measuredPattern.peakGainDbi;
  if (config.type === "isotropic") return 0;
  const ratedFrequencyMHz = config.gainReferenceFrequencyMHz;
  const ratedGainApplies =
    config.gainMode !== "estimated" &&
    (ratedFrequencyMHz === undefined ||
      Math.abs(config.frequencyMHz - ratedFrequencyMHz) <=
        Math.max(1e-6, ratedFrequencyMHz * 1e-6));
  if (ratedGainApplies) return config.gainDbi;
  const wavelengthMm = getWavelengthMm(config.frequencyMHz);
  if (!(wavelengthMm > 0)) return -Infinity;
  const designKey = [
    config.type,
    config.frequencyMHz,
    config.lengthMm,
    config.diameterMm,
    config.monopoleGroundPlaneDiameterMm,
    config.patchLengthMm,
    config.patchWidthMm,
    config.patchSubstrateEr,
    config.patchSubstrateThicknessMm,
    config.patchGroundMarginMm,
    config.patchFeedInsetMm,
    config.yagiElementCount,
    config.yagiDrivenElementLengthMm,
    config.yagiReflectorLengthMm,
    config.yagiDirectorLengthMm,
    config.hornApertureWidthMm,
    config.hornApertureHeightMm,
    config.hornThroatWidthMm,
    config.hornThroatHeightMm,
    config.helixTurns,
    config.helixPitchMm,
    config.helixCoilDiameterMm,
    config.radiationEfficiencyPercent,
  ].join(":");
  const cached = estimatedGainCache.get(designKey);
  if (cached !== undefined) return cached;

  // Numerically integrate the power pattern over solid angle to estimate D.
  const thetaSteps = 60;
  const phiSteps = 120;
  const dTheta = Math.PI / thetaSteps;
  const dPhi = (2 * Math.PI) / phiSteps;
  let integral = 0;
  let peak = 0;
  for (let i = 0; i < thetaSteps; i++) {
    const theta = (i + 0.5) * dTheta;
    const sinTheta = Math.sin(theta);
    for (let j = 0; j < phiSteps; j++) {
      const phi = (j + 0.5) * dPhi - Math.PI;
      const power = normalizedPower(theta, phi, config, wavelengthMm);
      integral += power * sinTheta * dTheta * dPhi;
      peak = Math.max(peak, power);
    }
  }
  const directivity = integral > 0 ? (4 * Math.PI * peak) / integral : 1;
  const efficiency = clamp(config.radiationEfficiencyPercent ?? 75, 1, 100) / 100;
  const mismatchEfficiency = config.type === "patch" ? getPatchDetuneEfficiency(config) : 1;
  const gainDbi = 10 * Math.log10(Math.max(1e-6, directivity * efficiency * mismatchEfficiency));
  if (estimatedGainCache.size > 128) estimatedGainCache.clear();
  estimatedGainCache.set(designKey, gainDbi);
  return gainDbi;
}

export function calculateRadiationPattern(
  theta: number,
  phi: number,
  config: AntennaConfig,
): PatternSample {
  const wavelengthMm = getWavelengthMm(config.frequencyMHz);
  const measuredPattern = getConfiguredMeasuredPattern(config);
  if (measuredPattern && Number.isFinite(theta) && Number.isFinite(phi)) {
    const thetaDeg = (theta * 180) / Math.PI;
    const phiDeg = (phi * 180) / Math.PI;
    const gainDbi = sampleMeasuredPattern(measuredPattern, thetaDeg, phiDeg);
    const relativeLinear = clamp01(
      10 ** ((gainDbi - measuredPattern.peakGainDbi) / 10),
    );
    return { gainDbi, relativeLinear, radius: relativeLinear };
  }
  if (
    !(wavelengthMm > 0) ||
    !Number.isFinite(theta) ||
    !Number.isFinite(phi) ||
    !Number.isFinite(config.gainDbi)
  ) {
    return { gainDbi: -Infinity, relativeLinear: 0, radius: 0 };
  }

  const power = normalizedPower(theta, phi, config, wavelengthMm);
  const relativeLinear = clamp01(Number.isFinite(power) ? power : 0);
  const relativeDb = 10 * Math.log10(Math.max(1e-12, relativeLinear));
  const peakGainDbi = getAntennaPeakGainDbi(config);
  return {
    gainDbi: peakGainDbi + relativeDb,
    relativeLinear,
    radius: relativeLinear,
  };
}
