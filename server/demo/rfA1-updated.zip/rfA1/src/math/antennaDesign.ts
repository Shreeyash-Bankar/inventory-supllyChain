import type { AntennaConfig, AntennaType } from "../types/antenna";
import { getWavelengthMm } from "./rfPhysics";

/** Reasonable first-cut geometry when switching antenna topologies. */
export function getAntennaDesignDefaults(
  type: AntennaType,
  frequencyMHz: number,
  lengthMm: number,
  diameterMm: number,
): Partial<AntennaConfig> {
  const wavelengthMm = getWavelengthMm(frequencyMHz) || 125;
  const round = (value: number) => Math.round(value * 10) / 10;

  switch (type) {
    case "monopole":
      return {
        lengthMm: round(wavelengthMm * 0.24),
        monopoleGroundPlaneDiameterMm: round(wavelengthMm * 0.5),
      };
    case "patch": {
      const substrateEr = 4.4;
      const patchWidthMm = wavelengthMm * 0.48;
      const substrateThicknessMm = 1.6;
      const effectiveEr =
        (substrateEr + 1) / 2 +
        (substrateEr - 1) /
          (2 * Math.sqrt(1 + (12 * substrateThicknessMm) / patchWidthMm));
      const patchLengthMm = wavelengthMm / (2 * Math.sqrt(effectiveEr)) - 1.2;
      return {
        patchLengthMm: round(patchLengthMm),
        patchWidthMm: round(patchWidthMm),
        patchSubstrateEr: substrateEr,
        patchSubstrateThicknessMm: substrateThicknessMm,
        patchGroundMarginMm: round(wavelengthMm * 0.08),
        patchFeedInsetMm: round(patchLengthMm * 0.25),
      };
    }
    case "yagi":
      return {
        lengthMm: round(wavelengthMm * 1.5),
        yagiElementCount: 6,
        yagiDrivenElementLengthMm: round(wavelengthMm * 0.47),
        yagiReflectorLengthMm: round(wavelengthMm * 0.5),
        yagiDirectorLengthMm: round(wavelengthMm * 0.45),
      };
    case "horn":
      return {
        lengthMm: round(wavelengthMm * 1.5),
        hornApertureWidthMm: round(wavelengthMm * 1.25),
        hornApertureHeightMm: round(wavelengthMm),
        hornThroatWidthMm: round(wavelengthMm * 0.45),
        hornThroatHeightMm: round(wavelengthMm * 0.3),
      };
    case "helical":
      return {
        helixTurns: 8,
        helixPitchMm: round(wavelengthMm * 0.25),
        helixCoilDiameterMm: round(wavelengthMm / Math.PI),
        helixWireDiameterMm: diameterMm,
        helixReflectorDiameterMm: round(wavelengthMm * 1.2),
      };
    case "dipole":
      return { lengthMm: round(wavelengthMm * 0.475), diameterMm };
    case "isotropic":
    default:
      return { lengthMm, diameterMm };
  }
}
