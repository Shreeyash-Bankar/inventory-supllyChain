// import React, { useState } from "react";
// import { useAntennaStore } from "../store/antennaStore";
// import {
//   AntennaConfig,
//   AntennaRole,
//   AntennaType,
//   GizmoMode,
// } from "../types/antenna";
// import {
//   mwToDbm,
//   getWavelengthMm,
//   getResonantHalfWaveLengthMm,
//   getVelocityFactor,
//   calculateEIRP,
//   calculateAtmosphericLoss,
//   calculateNoiseFloor,
//   WeatherCondition,
// } from "../math/rfPhysics";
// import {
//   Zap,
//   Radio,
//   Ruler,
//   CircleDot,
//   Layers,
//   Wand2,
//   Eye,
//   EyeOff,
//   Flame,
//   Move,
//   Compass,
//   Target,
//   RotateCcw,
//   Crosshair,
//   ArrowUpDown,
//   CloudRain,
//   Sliders,
//   ChevronDown,
//   ChevronUp,
// } from "lucide-react";

// interface AntennaSingleTabProps {
//   antenna: AntennaConfig;
//   updateAntenna: (partial: Partial<AntennaConfig>) => void;
//   antennaKey: "antenna-1" | "antenna-2";
// }

// const ANTENNA_TYPES: { id: AntennaType; label: string; defaultGain: number }[] =
//   [
//     { id: "dipole", label: "Dipole (Half-wave)", defaultGain: 2.15 },
//     { id: "monopole", label: "Monopole (Ground Plane)", defaultGain: 3.2 },
//     { id: "patch", label: "Microstrip Patch", defaultGain: 8.5 },
//     { id: "yagi", label: "Yagi-Uda Array", defaultGain: 12.0 },
//     { id: "horn", label: "Pyramidal Horn", defaultGain: 18.0 },
//     { id: "helical", label: "Axial Helical", defaultGain: 10.5 },
//     { id: "isotropic", label: "Isotropic (Reference)", defaultGain: 0.0 },
//   ];

// const POWER_PRESETS = [
//   { mw: 0.01, label: "0.01 mW (-20 dBm IoT)" },
//   { mw: 1, label: "1 mW (0 dBm BLE)" },
//   { mw: 25, label: "25 mW (14 dBm LoRa)" },
//   { mw: 100, label: "100 mW (20 dBm Wi-Fi)" },
//   { mw: 1000, label: "1 W (30 dBm PA)" },
//   { mw: 10000, label: "10 W (40 dBm Tx)" },
//   { mw: 100000, label: "100 W (50 dBm Max)" },
// ];

// const FREQ_PRESETS = [
//   { mhz: 433, label: "433M ISM" },
//   { mhz: 868, label: "868M LoRa" },
//   { mhz: 915, label: "915M US" },
//   { mhz: 2400, label: "2.4G Wi-Fi" },
//   { mhz: 3500, label: "3.5G 5G" },
//   { mhz: 5800, label: "5.8G ISM" },
// ];

// const HEIGHT_PRESETS = [
//   { h: 0, label: "0m Ground" },
//   { h: 1.5, label: "1.5m Handheld" },
//   { h: 3.0, label: "3m Mast" },
//   { h: 8.0, label: "8m Tower" },
// ];

// const AntennaSingleTab: React.FC<AntennaSingleTabProps> = ({
//   antenna,
//   updateAntenna,
//   antennaKey,
// }) => {
//   const autoTuneResonance = useAntennaStore((s) => s.autoTuneResonance);
//   const aimAntennaAt = useAntennaStore((s) => s.aimAntennaAt);
//   const flipAntenna180 = useAntennaStore((s) => s.flipAntenna180);
//   const resetTransform = useAntennaStore((s) => s.resetTransform);
//   const gizmoMode = useAntennaStore((s) => s.gizmoMode);
//   const setGizmoMode = useAntennaStore((s) => s.setGizmoMode);
//   const setAntennaRole = useAntennaStore((s) => s.setAntennaRole);
//   const otherAntennaKey =
//     antennaKey === "antenna-1" ? "antenna-2" : "antenna-1";

//   const lambdaMm = Math.round(getWavelengthMm(antenna.frequencyMHz) * 10) / 10;
//   const resonantMm =
//     Math.round(
//       getResonantHalfWaveLengthMm(antenna.frequencyMHz, antenna.diameterMm) *
//         10,
//     ) / 10;
//   const electricalLength =
//     Math.round((antenna.lengthMm / (lambdaMm || 1)) * 100) / 100;
//   const vf = getVelocityFactor(antenna.lengthMm, antenna.diameterMm);
//   const powerDbm = Math.round(mwToDbm(antenna.powerMilliwatts) * 10) / 10;
//   const { eirpWatts, eirpDbm } = calculateEIRP(
//     antenna.powerMilliwatts,
//     antenna.gainDbi,
//   );

//   // Logarithmic slider for power: 0.01 mW to 100,000 mW
//   const logPower = Math.log10(Math.max(0.01, antenna.powerMilliwatts));

//   const handleLogPowerSlider = (e: React.ChangeEvent<HTMLInputElement>) => {
//     const logVal = parseFloat(e.target.value);
//     const mw = Math.pow(10, logVal);
//     let cleanMw = mw;
//     if (mw >= 1000) {
//       cleanMw = Math.round(mw / 100) * 100;
//     } else if (mw >= 10) {
//       cleanMw = Math.round(mw * 10) / 10;
//     } else {
//       cleanMw = Math.round(mw * 100) / 100;
//     }
//     updateAntenna({
//       powerMilliwatts: Math.min(100000, Math.max(0.01, cleanMw)),
//     });
//   };

//   // Position updates
//   const setPosX = (val: number) => {
//     updateAntenna({
//       position: [val, antenna.position[1], antenna.position[2]],
//     });
//   };
//   const setPosY = (val: number) => {
//     updateAntenna({
//       position: [antenna.position[0], val, antenna.position[2]],
//     });
//   };
//   const setPosZ = (val: number) => {
//     updateAntenna({
//       position: [antenna.position[0], antenna.position[1], val],
//     });
//   };

//   // Rotation updates [Pitch X, Yaw Y, Roll Z] in degrees
//   const setRotX = (val: number) => {
//     updateAntenna({
//       rotation: [val, antenna.rotation[1], antenna.rotation[2]],
//     });
//   };
//   const setRotY = (val: number) => {
//     updateAntenna({
//       rotation: [antenna.rotation[0], val, antenna.rotation[2]],
//     });
//   };
//   const setRotZ = (val: number) => {
//     updateAntenna({
//       rotation: [antenna.rotation[0], antenna.rotation[1], val],
//     });
//   };

//   return (
//     <div className="space-y-4 text-xs">
//       {/* Visibility & Gizmo Toolbar */}
//       <div className="bg-slate-950/70 p-2.5 rounded-xl border border-slate-800 space-y-2">
//         <div className="flex items-center justify-between">
//           <div className="flex items-center space-x-2">
//             <button
//               onClick={() => updateAntenna({ enabled: !antenna.enabled })}
//               className={`px-2.5 py-1 rounded text-[11px] font-semibold flex items-center space-x-1.5 transition-colors ${
//                 antenna.enabled
//                   ? "bg-sky-500/20 text-sky-400 border border-sky-500/40"
//                   : "bg-slate-800 text-slate-500"
//               }`}
//             >
//               {antenna.enabled ? (
//                 <Eye className="w-3.5 h-3.5" />
//               ) : (
//                 <EyeOff className="w-3.5 h-3.5" />
//               )}
//               <span>{antenna.enabled ? "Active" : "Disabled"}</span>
//             </button>
//             <span className="text-slate-300 font-medium">{antenna.name}</span>
//           </div>

//           <button
//             onClick={() => updateAntenna({ wireframe: !antenna.wireframe })}
//             className={`px-2 py-0.5 rounded text-[10px] font-mono border ${
//               antenna.wireframe
//                 ? "bg-amber-500/20 text-amber-400 border-amber-500/40"
//                 : "bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200"
//             }`}
//           >
//             Wireframe
//           </button>
//         </div>

//         {/* 3D Interactive Canvas Gizmo Selector */}
//         <div className="flex items-center justify-between pt-1 border-t border-slate-800/60 font-mono text-[10px]">
//           <span className="text-slate-400 flex items-center space-x-1">
//             <Crosshair className="w-3 h-3 text-sky-400" />
//             <span>3D Canvas Gizmo:</span>
//           </span>
//           <div className="flex space-x-1">
//             <button
//               onClick={() => setGizmoMode("translate")}
//               className={`px-2 py-0.5 rounded border transition-all ${
//                 gizmoMode === "translate"
//                   ? "bg-sky-500/20 text-sky-300 border-sky-500/50"
//                   : "bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200"
//               }`}
//             >
//               Move (XYZ)
//             </button>
//             <button
//               onClick={() => setGizmoMode("rotate")}
//               className={`px-2 py-0.5 rounded border transition-all ${
//                 gizmoMode === "rotate"
//                   ? "bg-indigo-500/20 text-indigo-300 border-indigo-500/50"
//                   : "bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200"
//               }`}
//             >
//               Rotate (Aim)
//             </button>
//             <button
//               onClick={() => setGizmoMode("none")}
//               className={`px-2 py-0.5 rounded border transition-all ${
//                 gizmoMode === "none"
//                   ? "bg-slate-800 text-slate-300 border-slate-700"
//                   : "bg-slate-900 text-slate-500 border-slate-800 hover:text-slate-300"
//               }`}
//             >
//               Off
//             </button>
//           </div>
//         </div>
//       </div>

//       {/* TX / RX Communication Role */}
//       <div className="bg-slate-950/70 p-3 rounded-xl border border-indigo-500/30 space-y-2">
//         <div className="flex items-center justify-between">
//           <span className="text-slate-200 font-semibold">
//             Communication Role
//           </span>

//           <span
//             className={`text-[10px] font-bold ${
//               antenna.role === "transmitter" ? "text-sky-400" : "text-rose-400"
//             }`}
//           >
//             {antenna.role === "transmitter" ? "TX" : "RX"}
//           </span>
//         </div>

//         <select
//           value={antenna.role}
//           onChange={(e) =>
//             setAntennaRole(antennaKey, e.target.value as AntennaRole)
//           }
//           className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
//         >
//           <option value="transmitter">Transmitter (TX)</option>

//           <option value="receiver">Receiver (RX)</option>
//         </select>

//         <p className="text-[10px] text-slate-400">
//           The other antenna automatically receives the opposite role. Both
//           antennas retain their individual power and gain settings.
//         </p>
//       </div>

//       {/* 1. 3D POSITION IN ANY AXIS (X, Y, Z) */}
//       <div className="bg-slate-950/70 p-3 rounded-xl border border-sky-500/30 space-y-2.5">
//         <div className="flex items-center justify-between font-mono">
//           <span className="text-slate-200 font-semibold flex items-center space-x-1.5">
//             <Move className="w-3.5 h-3.5 text-sky-400" />
//             <span>3D Position (Any Axis)</span>
//           </span>
//           <span className="text-sky-300 font-bold bg-sky-950/40 border border-sky-800/40 px-2 py-0.5 rounded text-[10px]">
//             [{antenna.position[0].toFixed(1)}, {antenna.position[1].toFixed(1)},{" "}
//             {antenna.position[2].toFixed(1)}] m
//           </span>
//         </div>

//         {/* X Axis (Lateral Left/Right) */}
//         <div>
//           <div className="flex justify-between items-center text-[10px] font-mono text-slate-400 mb-0.5">
//             <span className="text-rose-400 font-bold">X Axis (Lateral):</span>
//             <span>{antenna.position[0].toFixed(2)} m</span>
//           </div>
//           <input
//             type="range"
//             min="-25000"
//             max="25000"
//             step="0.1"
//             value={antenna.position[0]}
//             onChange={(e) => setPosX(parseFloat(e.target.value))}
//             className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-rose-400"
//           />
//         </div>

//         {/* Y Axis (Elevation / Height above Ground) */}
//         <div>
//           <div className="flex justify-between items-center text-[10px] font-mono text-slate-400 mb-0.5">
//             <span className="text-emerald-400 font-bold">
//               Y Axis (Height above Ground):
//             </span>
//             <span>{antenna.position[1].toFixed(2)} m</span>
//           </div>
//           <input
//             type="range"
//             min="0"
//             max="12"
//             step="0.1"
//             value={antenna.position[1]}
//             onChange={(e) => setPosY(parseFloat(e.target.value))}
//             className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-400"
//           />
//           <div className="flex flex-wrap gap-1 pt-1">
//             {HEIGHT_PRESETS.map((hp) => (
//               <button
//                 key={hp.h}
//                 onClick={() => setPosY(hp.h)}
//                 className={`px-1.5 py-0.5 rounded text-[9px] font-mono border transition-all ${
//                   Math.abs(antenna.position[1] - hp.h) < 0.05
//                     ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/50"
//                     : "bg-slate-900/80 text-slate-400 border-slate-800 hover:text-slate-200"
//                 }`}
//               >
//                 {hp.label}
//               </button>
//             ))}
//           </div>
//         </div>

//         {/* Z Axis (Depth Front/Back) */}
//         <div>
//           <div className="flex justify-between items-center text-[10px] font-mono text-slate-400 mb-0.5">
//             <span className="text-sky-400 font-bold">Z Axis (Depth):</span>
//             <span>{antenna.position[2].toFixed(2)} m</span>
//           </div>
//           <input
//             type="range"
//             min="-25000"
//             max="25000"
//             step="0.1"
//             value={antenna.position[2]}
//             onChange={(e) => setPosZ(parseFloat(e.target.value))}
//             className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-sky-400"
//           />
//         </div>
//       </div>

//       {/* 2. 3D ORIENTATION & ROTATION (WITH 180° FLIP BUTTONS) */}
//       <div className="bg-slate-950/70 p-3 rounded-xl border border-indigo-500/30 space-y-2.5">
//         <div className="flex items-center justify-between font-mono">
//           <span className="text-slate-200 font-semibold flex items-center space-x-1.5">
//             <Compass className="w-3.5 h-3.5 text-indigo-400" />
//             <span>3D Rotation & Aim (Any Axis)</span>
//           </span>
//           <span className="text-indigo-300 font-bold bg-indigo-950/40 border border-indigo-800/40 px-2 py-0.5 rounded text-[10px]">
//             [{antenna.rotation[0]}°, {antenna.rotation[1]}°,{" "}
//             {antenna.rotation[2]}°]
//           </span>
//         </div>

//         {/* 180° QUICK FLIP CONTROLS */}
//         <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-900/80 rounded-xl border border-indigo-500/30">
//           <button
//             onClick={() => flipAntenna180(antennaKey, "yaw")}
//             title="Flip radiation lobe 180 degrees horizontally (Reverse Boresight Heading)"
//             className="px-2.5 py-1.5 rounded-lg bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 border border-indigo-500/50 font-mono text-[10px] font-bold flex items-center justify-center space-x-1.5 transition-all shadow-sm"
//           >
//             <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
//             <span>Flip 180° Boresight</span>
//           </button>

//           <button
//             onClick={() => flipAntenna180(antennaKey, "pitch")}
//             title="Invert antenna upside down (Flip 180 degrees vertically)"
//             className="px-2.5 py-1.5 rounded-lg bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 border border-indigo-500/50 font-mono text-[10px] font-bold flex items-center justify-center space-x-1.5 transition-all shadow-sm"
//           >
//             <ArrowUpDown className="w-3.5 h-3.5 text-emerald-400" />
//             <span>Invert 180° (Flip V)</span>
//           </button>
//         </div>

//         {/* Pitch / Tilt Elevation (X-Axis) */}
//         <div>
//           <div className="flex justify-between items-center text-[10px] font-mono text-slate-400 mb-0.5">
//             <span>Elevation / Tilt (Pitch X):</span>
//             <span className="text-indigo-300 font-semibold">
//               {antenna.rotation[0]}°
//             </span>
//           </div>
//           <input
//             type="range"
//             min="-90"
//             max="90"
//             step="1"
//             value={antenna.rotation[0]}
//             onChange={(e) => setRotX(parseFloat(e.target.value))}
//             className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-400"
//           />
//           <div className="flex justify-between text-[8px] font-mono text-slate-500">
//             <span>-90° (Down-tilt)</span>
//             <span>0° (Horizon)</span>
//             <span>+90° (Zenith/Sky)</span>
//           </div>
//         </div>

//         {/* Yaw / Azimuth Heading (Y-Axis) */}
//         <div>
//           <div className="flex justify-between items-center text-[10px] font-mono text-slate-400 mb-0.5">
//             <span>Azimuth Heading (Yaw Y):</span>
//             <span className="text-indigo-300 font-semibold">
//               {antenna.rotation[1]}°
//             </span>
//           </div>
//           <input
//             type="range"
//             min="-180"
//             max="180"
//             step="1"
//             value={antenna.rotation[1]}
//             onChange={(e) => setRotY(parseFloat(e.target.value))}
//             className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-400"
//           />
//           <div className="flex justify-between text-[8px] font-mono text-slate-500">
//             <span>-180° (South)</span>
//             <span>0° (East / Forward)</span>
//             <span>+180° (South)</span>
//           </div>
//         </div>

//         {/* Roll / Polarization (Z-Axis) */}
//         <div>
//           <div className="flex justify-between items-center text-[10px] font-mono text-slate-400 mb-0.5">
//             <span>Polarization / Roll (Z):</span>
//             <span className="text-indigo-300 font-semibold">
//               {antenna.rotation[2]}°
//             </span>
//           </div>
//           <input
//             type="range"
//             min="-90"
//             max="90"
//             step="1"
//             value={antenna.rotation[2]}
//             onChange={(e) => setRotZ(parseFloat(e.target.value))}
//             className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-400"
//           />
//         </div>

//         {/* Quick Aim & Polarization Alignment Tools */}
//         <div className="pt-1 border-t border-slate-800/60 flex flex-wrap gap-1 font-mono text-[9px]">
//           <button
//             onClick={() => setRotZ(0)}
//             className="px-2 py-1 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded border border-slate-800"
//           >
//             Vert Pol (0°)
//           </button>
//           <button
//             onClick={() => setRotZ(90)}
//             className="px-2 py-1 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded border border-slate-800"
//           >
//             Horiz Pol (90°)
//           </button>
//           <button
//             onClick={() => setRotZ(45)}
//             className="px-2 py-1 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded border border-slate-800"
//           >
//             Slant (45°)
//           </button>
//           <button
//             onClick={() => aimAntennaAt(antennaKey, otherAntennaKey)}
//             title="Automatically point main beam boresight at the other antenna in 3D"
//             className="px-2 py-1 bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 rounded border border-indigo-500/40 flex items-center space-x-1"
//           >
//             <Target className="w-2.5 h-2.5" />
//             <span>Aim at Target</span>
//           </button>
//           <button
//             onClick={() => resetTransform(antennaKey)}
//             title="Reset position and rotation to default"
//             className="px-2 py-1 bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 rounded border border-slate-800 flex items-center space-x-1"
//           >
//             <RotateCcw className="w-2.5 h-2.5" />
//             <span>Reset Pos/Rot</span>
//           </button>
//         </div>
//       </div>

//       {/* Antenna Type Selection */}
//       <div>
//         <label className="text-[11px] font-mono text-slate-400 mb-1.5 flex items-center space-x-1.5">
//           <Layers className="w-3.5 h-3.5 text-sky-400" />
//           <span>Antenna Topology</span>
//         </label>
//         <select
//           value={antenna.type}
//           onChange={(e) => {
//             const newType = e.target.value as AntennaType;
//             const def = ANTENNA_TYPES.find((t) => t.id === newType);
//             updateAntenna({
//               type: newType,
//               gainDbi: def ? def.defaultGain : antenna.gainDbi,
//             });
//           }}
//           className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200 font-mono focus:outline-none focus:border-sky-500"
//         >
//           {ANTENNA_TYPES.map((t) => (
//             <option key={t.id} value={t.id}>
//               {t.label} (Typ: {t.defaultGain} dBi)
//             </option>
//           ))}
//         </select>
//       </div>

//       {/* 3. Transmit Power (0.01 mW to 100,000 mW / 100 W) */}
//       <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800/80 space-y-2">
//         <div className="flex items-center justify-between font-mono">
//           <span className="text-slate-300 flex items-center space-x-1.5">
//             <Flame className="w-3.5 h-3.5 text-amber-400" />
//             <span className="font-semibold text-slate-200">Transmit Power</span>
//           </span>
//           <span className="text-amber-300 font-bold bg-amber-950/40 border border-amber-800/40 px-2 py-0.5 rounded text-[11px]">
//             {antenna.powerMilliwatts >= 1000
//               ? `${(antenna.powerMilliwatts / 1000).toFixed(antenna.powerMilliwatts >= 10000 ? 0 : 2)} W`
//               : `${antenna.powerMilliwatts} mW`}{" "}
//             ({powerDbm > 0 ? `+${powerDbm}` : powerDbm} dBm)
//           </span>
//         </div>

//         <input
//           type="range"
//           min="-2"
//           max="5"
//           step="0.01"
//           value={logPower}
//           onChange={handleLogPowerSlider}
//           className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
//         />

//         <div className="flex justify-between text-[9px] font-mono text-slate-400">
//           <span>0.01 mW (-20dBm)</span>
//           <span>100 mW (+20dBm)</span>
//           <span>100 W (+50dBm)</span>
//         </div>

//         <div className="flex flex-wrap gap-1 pt-1">
//           {POWER_PRESETS.map((p) => (
//             <button
//               key={p.mw}
//               onClick={() => updateAntenna({ powerMilliwatts: p.mw })}
//               className={`px-1.5 py-0.5 rounded text-[10px] font-mono border transition-all ${
//                 Math.abs(antenna.powerMilliwatts - p.mw) < 0.001
//                   ? "bg-amber-500/20 text-amber-300 border-amber-500/50"
//                   : "bg-slate-900/80 text-slate-400 border-slate-800 hover:text-slate-200"
//               }`}
//             >
//               {p.mw >= 1000 ? `${p.mw / 1000}W` : `${p.mw}mW`}
//             </button>
//           ))}
//         </div>
//       </div>

//       {/* 4. Antenna Gain (dBi) */}
//       <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800/80 space-y-2">
//         <div className="flex items-center justify-between font-mono">
//           <span className="text-slate-300 flex items-center space-x-1.5">
//             <Zap className="w-3.5 h-3.5 text-sky-400" />
//             <span className="font-semibold text-slate-200">
//               Antenna Gain (dBi)
//             </span>
//           </span>
//           <span className="text-sky-300 font-bold bg-sky-950/40 border border-sky-800/40 px-2 py-0.5 rounded text-[11px]">
//             {antenna.gainDbi > 0 ? `+${antenna.gainDbi}` : antenna.gainDbi} dBi
//           </span>
//         </div>

//         <input
//           type="range"
//           min="-5"
//           max="30"
//           step="0.1"
//           value={antenna.gainDbi}
//           onChange={(e) =>
//             updateAntenna({ gainDbi: parseFloat(e.target.value) })
//           }
//           className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-sky-400"
//         />

//         <div className="flex justify-between items-center text-[10px] font-mono text-slate-400">
//           <span>-5 dBi</span>
//           <span className="text-slate-300">
//             EIRP:{" "}
//             <strong className="text-sky-300">
//               {Math.round(eirpDbm * 10) / 10} dBm
//             </strong>{" "}
//             ({Math.round(eirpWatts * 100) / 100}W)
//           </span>
//           <span>+30 dBi</span>
//         </div>
//       </div>

//       {/* 5. Frequency (MHz) */}
//       <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800/80 space-y-2">
//         <div className="flex items-center justify-between font-mono">
//           <span className="text-slate-300 flex items-center space-x-1.5">
//             <Radio className="w-3.5 h-3.5 text-indigo-400" />
//             <span className="font-semibold text-slate-200">
//               Operating Frequency
//             </span>
//           </span>
//           <span className="text-indigo-300 font-bold bg-indigo-950/40 border border-indigo-800/40 px-2 py-0.5 rounded text-[11px]">
//             {antenna.frequencyMHz >= 1000
//               ? `${(antenna.frequencyMHz / 1000).toFixed(2)} GHz`
//               : `${antenna.frequencyMHz} MHz`}
//           </span>
//         </div>

//         <input
//           type="range"
//           min="100"
//           max="10000"
//           step="25"
//           value={antenna.frequencyMHz}
//           onChange={(e) =>
//             updateAntenna({ frequencyMHz: parseFloat(e.target.value) })
//           }
//           className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-400"
//         />

//         <div className="flex flex-wrap gap-1 pt-1">
//           {FREQ_PRESETS.map((f) => (
//             <button
//               key={f.mhz}
//               onClick={() => {
//                 updateAntenna({
//                   frequencyMHz: f.mhz,
//                   lengthMm:
//                     Math.round(
//                       getResonantHalfWaveLengthMm(f.mhz, antenna.diameterMm) *
//                         10,
//                     ) / 10,
//                 });
//               }}
//               className={`px-1.5 py-0.5 rounded text-[10px] font-mono border transition-all ${
//                 antenna.frequencyMHz === f.mhz
//                   ? "bg-indigo-500/20 text-indigo-300 border-indigo-500/50"
//                   : "bg-slate-900/80 text-slate-400 border-slate-800 hover:text-slate-200"
//               }`}
//             >
//               {f.label}
//             </button>
//           ))}
//         </div>

//         <div className="text-[10px] font-mono text-slate-400 flex items-center justify-between pt-1 border-t border-slate-800/50">
//           <span>
//             λ: <strong className="text-slate-200">{lambdaMm} mm</strong>
//           </span>
//           <span>
//             λ/2 Dipole:{" "}
//             <strong className="text-slate-200">
//               {Math.round((lambdaMm / 2) * 10) / 10} mm
//             </strong>
//           </span>
//         </div>
//       </div>

//       {/* 6. Antenna Length (mm) */}
//       <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800/80 space-y-2">
//         <div className="flex items-center justify-between font-mono">
//           <span className="text-slate-300 flex items-center space-x-1.5">
//             <Ruler className="w-3.5 h-3.5 text-emerald-400" />
//             <span className="font-semibold text-slate-200">
//               Physical Length (L)
//             </span>
//           </span>
//           <div className="flex items-center space-x-2">
//             <button
//               onClick={() => autoTuneResonance(antennaKey)}
//               title="Auto-tune length to resonant λ/2 or λ/4"
//               className="text-[10px] text-emerald-400 bg-emerald-950/60 hover:bg-emerald-900/80 px-2 py-0.5 rounded border border-emerald-800/50 flex items-center space-x-1"
//             >
//               <Wand2 className="w-3 h-3" />
//               <span>Resonate</span>
//             </button>
//             <span className="text-emerald-300 font-bold bg-emerald-950/40 border border-emerald-800/40 px-2 py-0.5 rounded text-[11px]">
//               {antenna.lengthMm} mm
//             </span>
//           </div>
//         </div>

//         <input
//           type="range"
//           min="5"
//           max="800"
//           step="1"
//           value={antenna.lengthMm}
//           onChange={(e) =>
//             updateAntenna({ lengthMm: parseFloat(e.target.value) })
//           }
//           className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-400"
//         />

//         <div className="flex items-center justify-between text-[10px] font-mono">
//           <span className="text-slate-400">
//             Electrical:{" "}
//             <strong className="text-emerald-300">{electricalLength} λ</strong>
//           </span>
//           <span
//             className={`px-1.5 py-0.5 rounded text-[9px] ${
//               Math.abs(electricalLength - 0.5) < 0.05
//                 ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
//                 : electricalLength > 1.0
//                   ? "bg-amber-500/20 text-amber-300 border border-amber-500/40"
//                   : "bg-slate-800 text-slate-400"
//             }`}
//           >
//             {Math.abs(electricalLength - 0.5) < 0.05
//               ? "Resonant (λ/2)"
//               : electricalLength > 1.0
//                 ? "Multi-Lobe Mode"
//                 : "Short Dipole"}
//           </span>
//         </div>
//       </div>

//       {/* 7. Antenna Diameter (mm) */}
//       <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800/80 space-y-2">
//         <div className="flex items-center justify-between font-mono">
//           <span className="text-slate-300 flex items-center space-x-1.5">
//             <CircleDot className="w-3.5 h-3.5 text-purple-400" />
//             <span className="font-semibold text-slate-200">
//               Element Diameter (d)
//             </span>
//           </span>
//           <span className="text-purple-300 font-bold bg-purple-950/40 border border-purple-800/40 px-2 py-0.5 rounded text-[11px]">
//             {antenna.diameterMm} mm
//           </span>
//         </div>

//         <input
//           type="range"
//           min="0.2"
//           max="40"
//           step="0.2"
//           value={antenna.diameterMm}
//           onChange={(e) =>
//             updateAntenna({ diameterMm: parseFloat(e.target.value) })
//           }
//           className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-purple-400"
//         />

//         <div className="flex items-center justify-between text-[10px] font-mono text-slate-400">
//           <span>
//             Ratio L/d:{" "}
//             {(antenna.lengthMm / Math.max(0.1, antenna.diameterMm)).toFixed(0)}
//           </span>
//           <span>
//             Velocity Factor:{" "}
//             <strong className="text-slate-200">{(vf * 100).toFixed(1)}%</strong>
//           </span>
//         </div>
//       </div>

//       {/* Opacity & Visual Scale */}
//       <div className="grid grid-cols-2 gap-2 pt-1 font-mono text-[11px] text-slate-400">
//         <div>
//           <div className="flex justify-between mb-1">
//             <span>Opacity:</span>
//             <span>{Math.round(antenna.opacity * 100)}%</span>
//           </div>
//           <input
//             type="range"
//             min="0.2"
//             max="1.0"
//             step="0.05"
//             value={antenna.opacity}
//             onChange={(e) =>
//               updateAntenna({ opacity: parseFloat(e.target.value) })
//             }
//             className="w-full h-1 bg-slate-800 rounded appearance-none cursor-pointer accent-slate-400"
//           />
//         </div>

//         <div>
//           <div className="flex justify-between mb-1">
//             <span>Lobe Scale:</span>
//             <span>{antenna.scaleLobe?.toFixed(1) || "1.0"}x</span>
//           </div>
//           <input
//             type="range"
//             min="0.5"
//             max="2.0"
//             step="0.1"
//             value={antenna.scaleLobe || 1.0}
//             onChange={(e) =>
//               updateAntenna({ scaleLobe: parseFloat(e.target.value) })
//             }
//             className="w-full h-1 bg-slate-800 rounded appearance-none cursor-pointer accent-slate-400"
//           />
//         </div>
//       </div>
//     </div>
//   );
// };

// export const AntennaControlPanel: React.FC = () => {
//   const antenna1 = useAntennaStore((s) => s.antenna1);
//   const antenna2 = useAntennaStore((s) => s.antenna2);
//   const updateAntenna1 = useAntennaStore((s) => s.updateAntenna1);
//   const updateAntenna2 = useAntennaStore((s) => s.updateAntenna2);
//   const selectedTab = useAntennaStore((s) => s.selectedAntennaId);
//   const setSelectedTab = useAntennaStore((s) => s.setSelectedAntennaId);

//   // Environment Store
//   const rfEnvironment = useAntennaStore((s) => s.rfEnvironment);
//   const setWeather = useAntennaStore((s) => s.setWeather);
//   const setBandwidthMHz = useAntennaStore((s) => s.setBandwidthMHz);
//   const setNoiseFigureDb = useAntennaStore((s) => s.setNoiseFigureDb);
//   const evalDistanceMeters = useAntennaStore((s) => s.evalDistanceMeters);
//   const setEvalDistanceMeters = useAntennaStore((s) => s.setEvalDistanceMeters);

//   const [envOpen, setEnvOpen] = useState(true);

//   const noiseFloor = calculateNoiseFloor(
//     rfEnvironment.bandwidthMHz * 1e6,
//     rfEnvironment.noiseFigureDb,
//   );
//   const { specificAttenuationDbPerKm } = calculateAtmosphericLoss(
//     1000,
//     2400,
//     rfEnvironment.weather,
//   );

//   return (
//     <div className="h-full flex flex-col bg-slate-900/90 backdrop-blur-xl border-r border-slate-800 select-none overflow-hidden">
//       {/* Tab Switcher */}
//       <div className="p-3 border-b border-slate-800 grid grid-cols-2 gap-2 bg-slate-950/40">
//         <button
//           onClick={() => setSelectedTab("antenna-1")}
//           className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center justify-center space-x-2 transition-all ${
//             selectedTab === "antenna-1"
//               ? "bg-sky-500/15 text-sky-400 border border-sky-500/40 shadow-sm"
//               : "text-slate-400 hover:text-slate-200 border border-transparent hover:bg-slate-800/40"
//           }`}
//         >
//           <div className="w-2.5 h-2.5 rounded-full bg-sky-400 shadow-sm" />
//           <span>Antenna 1 (Tx A)</span>
//         </button>

//         <button
//           onClick={() => setSelectedTab("antenna-2")}
//           className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center justify-center space-x-2 transition-all ${
//             selectedTab === "antenna-2"
//               ? "bg-rose-500/15 text-rose-400 border border-rose-500/40 shadow-sm"
//               : "text-slate-400 hover:text-slate-200 border border-transparent hover:bg-slate-800/40"
//           }`}
//         >
//           <div className="w-2.5 h-2.5 rounded-full bg-rose-400 shadow-sm" />
//           <span>Antenna 2 (Tx B)</span>
//         </button>
//       </div>

//       {/* Scrollable Control Content */}
//       <div className="flex-1 overflow-y-auto p-4 space-y-4">
//         {selectedTab === "antenna-1" ? (
//           <AntennaSingleTab
//             antenna={antenna1}
//             updateAntenna={updateAntenna1}
//             antennaKey="antenna-1"
//           />
//         ) : (
//           <AntennaSingleTab
//             antenna={antenna2}
//             updateAntenna={updateAntenna2}
//             antennaKey="antenna-2"
//           />
//         )}

//         {/* Global Atmospheric Loss & RF Channel Noise Floor Card */}
//         <div className="bg-slate-950/80 rounded-2xl border border-cyan-500/30 p-3.5 space-y-3 font-mono text-xs">
//           <button
//             onClick={() => setEnvOpen(!envOpen)}
//             className="w-full flex items-center justify-between text-slate-200 font-bold"
//           >
//             <div className="flex items-center space-x-2">
//               <CloudRain className="w-4 h-4 text-cyan-400" />
//               <span>Atmospheric & Channel SNR</span>
//             </div>
//             {envOpen ? (
//               <ChevronUp className="w-3.5 h-3.5" />
//             ) : (
//               <ChevronDown className="w-3.5 h-3.5" />
//             )}
//           </button>

//           {envOpen && (
//             <div className="space-y-3 pt-1 border-t border-slate-800/80">
//               {/* Receiver Distance (D) */}
//               <div>
//                 <div className="flex justify-between text-[10px] text-slate-400 mb-1">
//                   <span>Receiver Distance (D):</span>
//                   <span className="text-cyan-300 font-bold bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/40">
//                     {evalDistanceMeters < 1000
//                       ? `${evalDistanceMeters.toFixed(1)} m`
//                       : `${(evalDistanceMeters / 1000).toFixed(2)} km`}
//                   </span>
//                 </div>
//                 <input
//                   type="range"
//                   min="0.5"
//                   max="200"
//                   step="0.5"
//                   value={Math.min(200, evalDistanceMeters)}
//                   onChange={(e) =>
//                     setEvalDistanceMeters(parseFloat(e.target.value))
//                   }
//                   className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
//                 />
//                 <div className="flex justify-between text-[8px] text-slate-500">
//                   <span>0.5m (Near-field)</span>
//                   <span>50m</span>
//                   <span>200m (Far-field)</span>
//                 </div>
//               </div>

//               {/* Weather Conditions (ITU-R P.676 & P.838) */}
//               <div>
//                 <label className="text-[10px] text-slate-400 block mb-1">
//                   Weather & Atmosphere Condition:
//                 </label>
//                 <div className="grid grid-cols-2 gap-1">
//                   {[
//                     { id: "clear", label: "Clear Sky" },
//                     { id: "fog", label: "Moderate Fog" },
//                     { id: "light_rain", label: "Light Rain (2.5mm)" },
//                     { id: "heavy_rain", label: "Tropical Rain (25mm)" },
//                   ].map((w) => (
//                     <button
//                       key={w.id}
//                       onClick={() => setWeather(w.id as WeatherCondition)}
//                       className={`px-2 py-1.5 rounded-lg text-[10px] border transition-all text-left ${
//                         rfEnvironment.weather === w.id
//                           ? "bg-cyan-500/20 text-cyan-300 border-cyan-500/50 font-bold"
//                           : "bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200"
//                       }`}
//                     >
//                       {w.label}
//                     </button>
//                   ))}
//                 </div>
//                 <div className="text-[9px] text-slate-400 mt-1 flex justify-between">
//                   <span>Atmo Attenuation (2.4G):</span>
//                   <span className="text-cyan-300 font-bold">
//                     {specificAttenuationDbPerKm.toFixed(3)} dB/km
//                   </span>
//                 </div>
//               </div>

//               {/* Channel Bandwidth for Noise Floor (B) */}
//               <div>
//                 <div className="flex justify-between text-[10px] text-slate-400 mb-1">
//                   <span>Channel Bandwidth (B):</span>
//                   <span className="text-indigo-300 font-bold">
//                     {rfEnvironment.bandwidthMHz} MHz
//                   </span>
//                 </div>
//                 <div className="flex flex-wrap gap-1">
//                   {[
//                     { bw: 0.125, label: "125k LoRa" },
//                     { bw: 1.0, label: "1M BLE" },
//                     { bw: 20, label: "20M Wi-Fi" },
//                     { bw: 40, label: "40M Wi-Fi" },
//                     { bw: 100, label: "100M 5G" },
//                   ].map((item) => (
//                     <button
//                       key={item.bw}
//                       onClick={() => setBandwidthMHz(item.bw)}
//                       className={`px-1.5 py-0.5 rounded text-[10px] border transition-all ${
//                         rfEnvironment.bandwidthMHz === item.bw
//                           ? "bg-indigo-500/20 text-indigo-300 border-indigo-500/50 font-bold"
//                           : "bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200"
//                       }`}
//                     >
//                       {item.label}
//                     </button>
//                   ))}
//                 </div>
//               </div>

//               {/* Receiver Noise Figure (NF) */}
//               <div>
//                 <div className="flex justify-between text-[10px] text-slate-400 mb-0.5">
//                   <span>LNA Noise Figure (NF):</span>
//                   <span className="text-slate-200 font-bold">
//                     +{rfEnvironment.noiseFigureDb} dB
//                   </span>
//                 </div>
//                 <input
//                   type="range"
//                   min="2"
//                   max="12"
//                   step="0.5"
//                   value={rfEnvironment.noiseFigureDb}
//                   onChange={(e) => setNoiseFigureDb(parseFloat(e.target.value))}
//                   className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-400"
//                 />
//               </div>

//               {/* Live Noise Floor Output */}
//               <div className="bg-slate-900 p-2 rounded-xl border border-slate-800 flex items-center justify-between text-[11px]">
//                 <span className="text-slate-400">
//                   Total Noise Floor (kTB + NF):
//                 </span>
//                 <span className="text-indigo-300 font-bold">
//                   {noiseFloor.toFixed(1)} dBm
//                 </span>
//               </div>
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// };
import React, { useState } from "react";
import { useAntennaStore } from "../store/antennaStore";
import {
  AntennaConfig,
  AntennaRole,
  AntennaType,
  GizmoMode,
} from "../types/antenna";
import {
  mwToDbm,
  getWavelengthMm,
  getVelocityFactor,
  calculateEIRP,
  calculateAtmosphericLoss,
  calculateNoiseFloor,
  WeatherCondition,
} from "../math/rfPhysics";
import { getAntennaDesignDefaults } from "../math/antennaDesign";
import {
  getAntennaDesignSignature,
  getAntennaPeakGainDbi,
} from "../math/radiationPatterns";
import { MeasuredPatternControl } from "./MeasuredPatternControl";
import {
  Zap,
  Radio,
  Ruler,
  CircleDot,
  Layers,
  Wand2,
  Eye,
  EyeOff,
  Flame,
  Move,
  Compass,
  Target,
  RotateCcw,
  Crosshair,
  ArrowUpDown,
  CloudRain,
  Sliders,
  ChevronDown,
  ChevronUp,
} from "lucide-react";

interface AntennaSingleTabProps {
  antenna: AntennaConfig;
  updateAntenna: (partial: Partial<AntennaConfig>) => void;
  antennaKey: "antenna-1" | "antenna-2";
}

const ANTENNA_TYPES: { id: AntennaType; label: string; defaultGain: number }[] =
  [
    { id: "dipole", label: "Dipole (Half-wave)", defaultGain: 2.15 },
    { id: "monopole", label: "Monopole (Ground Plane)", defaultGain: 3.2 },
    { id: "patch", label: "Microstrip Patch", defaultGain: 8.5 },
    { id: "yagi", label: "Yagi-Uda Array", defaultGain: 12.0 },
    { id: "horn", label: "Pyramidal Horn", defaultGain: 18.0 },
    { id: "helical", label: "Axial Helical", defaultGain: 10.5 },
    { id: "isotropic", label: "Isotropic (Reference)", defaultGain: 0.0 },
  ];

const POWER_PRESETS = [
  { mw: 0.01, label: "0.01 mW (-20 dBm IoT)" },
  { mw: 1, label: "1 mW (0 dBm BLE)" },
  { mw: 25, label: "25 mW (14 dBm LoRa)" },
  { mw: 100, label: "100 mW (20 dBm Wi-Fi)" },
  { mw: 1000, label: "1 W (30 dBm PA)" },
  { mw: 10000, label: "10 W (40 dBm Tx)" },
  { mw: 100000, label: "100 W (50 dBm Max)" },
];

const FREQ_PRESETS = [
  { mhz: 433, label: "433M ISM" },
  { mhz: 868, label: "868M LoRa" },
  { mhz: 915, label: "915M US" },
  { mhz: 2400, label: "2.4G Wi-Fi" },
  { mhz: 3500, label: "3.5G 5G" },
  { mhz: 5800, label: "5.8G ISM" },
];

const HEIGHT_PRESETS = [
  { h: 0, label: "0m Ground" },
  { h: 1.5, label: "1.5m Handheld" },
  { h: 3.0, label: "3m Mast" },
  { h: 8.0, label: "8m Tower" },
];

const DesignNumberField: React.FC<{
  label: string;
  value: number;
  unit: string;
  min: number;
  max: number;
  step?: number;
  onChange: (value: number) => void;
}> = ({ label, value, unit, min, max, step = 0.1, onChange }) => (
  <label className="space-y-1 text-[10px] font-mono text-slate-400">
    <span className="block">{label}</span>
    <span className="flex items-center gap-1.5">
      <input
        type="number"
        min={min}
        max={max}
        step={step}
        value={Number.isFinite(value) ? value : min}
        onChange={(event) => {
          const next = Number.parseFloat(event.target.value);
          if (Number.isFinite(next)) onChange(Math.max(min, Math.min(max, next)));
        }}
        className="w-full min-w-0 rounded-md border border-slate-700 bg-slate-900 px-2 py-1 text-slate-100 focus:border-sky-500 focus:outline-none"
      />
      <span>{unit}</span>
    </span>
  </label>
);

const AntennaSingleTab: React.FC<AntennaSingleTabProps> = ({
  antenna,
  updateAntenna,
  antennaKey,
}) => {
  const autoTuneResonance = useAntennaStore((s) => s.autoTuneResonance);
  const aimAntennaAt = useAntennaStore((s) => s.aimAntennaAt);
  const flipAntenna180 = useAntennaStore((s) => s.flipAntenna180);
  const resetTransform = useAntennaStore((s) => s.resetTransform);
  const gizmoMode = useAntennaStore((s) => s.gizmoMode);
  const setGizmoMode = useAntennaStore((s) => s.setGizmoMode);
  const setAntennaRole = useAntennaStore((s) => s.setAntennaRole);
  const otherAntennaKey =
    antennaKey === "antenna-1" ? "antenna-2" : "antenna-1";
  const designDefaults = getAntennaDesignDefaults(
    antenna.type,
    antenna.frequencyMHz,
    antenna.lengthMm,
    antenna.diameterMm,
  );

  const lambdaMm = Math.round(getWavelengthMm(antenna.frequencyMHz) * 10) / 10;
  const electricalLength =
    Math.round((antenna.lengthMm / (lambdaMm || 1)) * 100) / 100;
  const resonantFraction = antenna.type === "monopole" ? 0.25 : 0.5;
  const isWireResonant = Math.abs(electricalLength - resonantFraction) < 0.05;
  const vf = getVelocityFactor(antenna.lengthMm, antenna.diameterMm);
  const powerDbm = Math.round(mwToDbm(antenna.powerMilliwatts) * 10) / 10;
  const peakGainDbi = getAntennaPeakGainDbi(antenna);
  const ratedGainIsOffFrequency = Boolean(
    antenna.gainMode !== "estimated" &&
      antenna.gainReferenceFrequencyMHz !== undefined &&
      Math.abs(antenna.frequencyMHz - antenna.gainReferenceFrequencyMHz) >
        Math.max(1e-6, antenna.gainReferenceFrequencyMHz * 1e-6),
  );
  const hasActiveMeasuredPattern = Boolean(
    antenna.measuredPattern &&
      antenna.measuredPattern.points.length > 0 &&
      antenna.measuredPattern.designSignature ===
        getAntennaDesignSignature(antenna) &&
      Math.abs(antenna.frequencyMHz - antenna.measuredPattern.frequencyMHz) <=
        Math.max(1e-6, antenna.measuredPattern.frequencyMHz * 1e-6),
  );
  const { eirpWatts, eirpDbm } = calculateEIRP(
    antenna.powerMilliwatts,
    peakGainDbi,
  );

  // Logarithmic slider for power: 0.01 mW to 100,000 mW
  const logPower = Math.log10(Math.max(0.01, antenna.powerMilliwatts));

  const handleLogPowerSlider = (e: React.ChangeEvent<HTMLInputElement>) => {
    const logVal = parseFloat(e.target.value);
    const mw = Math.pow(10, logVal);
    let cleanMw = mw;
    if (mw >= 1000) {
      cleanMw = Math.round(mw / 100) * 100;
    } else if (mw >= 10) {
      cleanMw = Math.round(mw * 10) / 10;
    } else {
      cleanMw = Math.round(mw * 100) / 100;
    }
    updateAntenna({
      powerMilliwatts: Math.min(100000, Math.max(0.01, cleanMw)),
    });
  };

  // Position updates
  const setPosX = (val: number) => {
    updateAntenna({
      position: [val, antenna.position[1], antenna.position[2]],
    });
  };
  const setPosY = (val: number) => {
    updateAntenna({
      position: [antenna.position[0], val, antenna.position[2]],
    });
  };
  const setPosZ = (val: number) => {
    updateAntenna({
      position: [antenna.position[0], antenna.position[1], val],
    });
  };

  // Rotation updates [Pitch X, Yaw Y, Roll Z] in degrees
  const setRotX = (val: number) => {
    updateAntenna({
      rotation: [val, antenna.rotation[1], antenna.rotation[2]],
    });
  };
  const setRotY = (val: number) => {
    updateAntenna({
      rotation: [antenna.rotation[0], val, antenna.rotation[2]],
    });
  };
  const setRotZ = (val: number) => {
    updateAntenna({
      rotation: [antenna.rotation[0], antenna.rotation[1], val],
    });
  };

  return (
    <div className="space-y-4 text-xs">
      {/* Visibility & Gizmo Toolbar */}
      <div className="bg-slate-950/70 p-2.5 rounded-xl border border-slate-800 space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <button
              onClick={() => updateAntenna({ enabled: !antenna.enabled })}
              className={`px-2.5 py-1 rounded text-[11px] font-semibold flex items-center space-x-1.5 transition-colors ${
                antenna.enabled
                  ? "bg-sky-500/20 text-sky-400 border border-sky-500/40"
                  : "bg-slate-800 text-slate-500"
              }`}
            >
              {antenna.enabled ? (
                <Eye className="w-3.5 h-3.5" />
              ) : (
                <EyeOff className="w-3.5 h-3.5" />
              )}
              <span>{antenna.enabled ? "Active" : "Disabled"}</span>
            </button>
            <span className="text-slate-300 font-medium">{antenna.name}</span>
          </div>

          <button
            onClick={() => updateAntenna({ wireframe: !antenna.wireframe })}
            className={`px-2 py-0.5 rounded text-[10px] font-mono border ${
              antenna.wireframe
                ? "bg-amber-500/20 text-amber-400 border-amber-500/40"
                : "bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200"
            }`}
          >
            Wireframe
          </button>
        </div>

        {/* 3D Interactive Canvas Gizmo Selector */}
        <div className="flex items-center justify-between pt-1 border-t border-slate-800/60 font-mono text-[10px]">
          <span className="text-slate-400 flex items-center space-x-1">
            <Crosshair className="w-3 h-3 text-sky-400" />
            <span>3D Canvas Gizmo:</span>
          </span>
          <div className="flex space-x-1">
            <button
              onClick={() => setGizmoMode("translate")}
              className={`px-2 py-0.5 rounded border transition-all ${
                gizmoMode === "translate"
                  ? "bg-sky-500/20 text-sky-300 border-sky-500/50"
                  : "bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200"
              }`}
            >
              Move (XYZ)
            </button>
            <button
              onClick={() => setGizmoMode("rotate")}
              className={`px-2 py-0.5 rounded border transition-all ${
                gizmoMode === "rotate"
                  ? "bg-indigo-500/20 text-indigo-300 border-indigo-500/50"
                  : "bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200"
              }`}
            >
              Rotate (Aim)
            </button>
            <button
              onClick={() => setGizmoMode("none")}
              className={`px-2 py-0.5 rounded border transition-all ${
                gizmoMode === "none"
                  ? "bg-slate-800 text-slate-300 border-slate-700"
                  : "bg-slate-900 text-slate-500 border-slate-800 hover:text-slate-300"
              }`}
            >
              Off
            </button>
          </div>
        </div>
      </div>

      {/* TX / RX Communication Role */}
      <div className="bg-slate-950/70 p-3 rounded-xl border border-indigo-500/30 space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-slate-200 font-semibold">
            Communication Role
          </span>

          <span
            className={`text-[10px] font-bold ${
              antenna.role === "transmitter" ? "text-sky-400" : "text-rose-400"
            }`}
          >
            {antenna.role === "transmitter" ? "TX" : "RX"}
          </span>
        </div>

        <select
          value={antenna.role}
          onChange={(e) =>
            setAntennaRole(antennaKey, e.target.value as AntennaRole)
          }
          className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
        >
          <option value="transmitter">Transmitter (TX)</option>

          <option value="receiver">Receiver (RX)</option>
        </select>

        <p className="text-[10px] text-slate-400">
          The other antenna automatically receives the opposite role. Both
          antennas retain their individual power and gain settings.
        </p>
      </div>

      {/* 1. 3D POSITION IN ANY AXIS (X, Y, Z) */}
      <div className="bg-slate-950/70 p-3 rounded-xl border border-sky-500/30 space-y-2.5">
        <div className="flex items-center justify-between font-mono">
          <span className="text-slate-200 font-semibold flex items-center space-x-1.5">
            <Move className="w-3.5 h-3.5 text-sky-400" />
            <span>3D Position (Any Axis)</span>
          </span>
          <span className="text-sky-300 font-bold bg-sky-950/40 border border-sky-800/40 px-2 py-0.5 rounded text-[10px]">
            [{antenna.position[0].toFixed(1)}, {antenna.position[1].toFixed(1)},{" "}
            {antenna.position[2].toFixed(1)}] m
          </span>
        </div>

        {/* X Axis (Lateral Left/Right) */}
        <div>
          <div className="flex justify-between items-center text-[10px] font-mono text-slate-400 mb-0.5">
            <span className="text-rose-400 font-bold">X Axis (Lateral):</span>
            <span>{antenna.position[0].toFixed(2)} m</span>
          </div>
          <input
            type="range"
            min="-25000"
            max="25000"
            step="0.1"
            value={antenna.position[0]}
            onChange={(e) => setPosX(parseFloat(e.target.value))}
            className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-rose-400"
          />
        </div>

        {/* Y Axis (Elevation / Height above Ground) */}
        <div>
          <div className="flex justify-between items-center text-[10px] font-mono text-slate-400 mb-0.5">
            <span className="text-emerald-400 font-bold">
              Y Axis (Height above Ground):
            </span>
            <span>{antenna.position[1].toFixed(2)} m</span>
          </div>
          <input
            type="range"
            min="0"
            max="12"
            step="0.1"
            value={antenna.position[1]}
            onChange={(e) => setPosY(parseFloat(e.target.value))}
            className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-400"
          />
          <div className="flex flex-wrap gap-1 pt-1">
            {HEIGHT_PRESETS.map((hp) => (
              <button
                key={hp.h}
                onClick={() => setPosY(hp.h)}
                className={`px-1.5 py-0.5 rounded text-[9px] font-mono border transition-all ${
                  Math.abs(antenna.position[1] - hp.h) < 0.05
                    ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/50"
                    : "bg-slate-900/80 text-slate-400 border-slate-800 hover:text-slate-200"
                }`}
              >
                {hp.label}
              </button>
            ))}
          </div>
        </div>

        {/* Z Axis (Depth Front/Back) */}
        <div>
          <div className="flex justify-between items-center text-[10px] font-mono text-slate-400 mb-0.5">
            <span className="text-sky-400 font-bold">Z Axis (Depth):</span>
            <span>{antenna.position[2].toFixed(2)} m</span>
          </div>
          <input
            type="range"
            min="-25000"
            max="25000"
            step="0.1"
            value={antenna.position[2]}
            onChange={(e) => setPosZ(parseFloat(e.target.value))}
            className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-sky-400"
          />
        </div>
      </div>

      {/* 2. 3D ORIENTATION & ROTATION (WITH 180° FLIP BUTTONS) */}
      <div className="bg-slate-950/70 p-3 rounded-xl border border-indigo-500/30 space-y-2.5">
        <div className="flex items-center justify-between font-mono">
          <span className="text-slate-200 font-semibold flex items-center space-x-1.5">
            <Compass className="w-3.5 h-3.5 text-indigo-400" />
            <span>3D Rotation & Aim (Any Axis)</span>
          </span>
          <span className="text-indigo-300 font-bold bg-indigo-950/40 border border-indigo-800/40 px-2 py-0.5 rounded text-[10px]">
            [{antenna.rotation[0]}°, {antenna.rotation[1]}°,{" "}
            {antenna.rotation[2]}°]
          </span>
        </div>

        {/* 180° QUICK FLIP CONTROLS */}
        <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-900/80 rounded-xl border border-indigo-500/30">
          <button
            onClick={() => flipAntenna180(antennaKey, "yaw")}
            title="Flip radiation lobe 180 degrees horizontally (Reverse Boresight Heading)"
            className="px-2.5 py-1.5 rounded-lg bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 border border-indigo-500/50 font-mono text-[10px] font-bold flex items-center justify-center space-x-1.5 transition-all shadow-sm"
          >
            <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
            <span>Flip 180° Boresight</span>
          </button>

          <button
            onClick={() => flipAntenna180(antennaKey, "pitch")}
            title="Invert antenna upside down (Flip 180 degrees vertically)"
            className="px-2.5 py-1.5 rounded-lg bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 border border-indigo-500/50 font-mono text-[10px] font-bold flex items-center justify-center space-x-1.5 transition-all shadow-sm"
          >
            <ArrowUpDown className="w-3.5 h-3.5 text-emerald-400" />
            <span>Invert 180° (Flip V)</span>
          </button>
        </div>

        {/* Pitch / Tilt Elevation (X-Axis) */}
        <div>
          <div className="flex justify-between items-center text-[10px] font-mono text-slate-400 mb-0.5">
            <span>Elevation / Tilt (Pitch X):</span>
            <span className="text-indigo-300 font-semibold">
              {antenna.rotation[0]}°
            </span>
          </div>
          <input
            type="range"
            min="-90"
            max="90"
            step="1"
            value={antenna.rotation[0]}
            onChange={(e) => setRotX(parseFloat(e.target.value))}
            className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-400"
          />
          <div className="flex justify-between text-[8px] font-mono text-slate-500">
            <span>-90° (Down-tilt)</span>
            <span>0° (Horizon)</span>
            <span>+90° (Zenith/Sky)</span>
          </div>
        </div>

        {/* Yaw / Azimuth Heading (Y-Axis) */}
        <div>
          <div className="flex justify-between items-center text-[10px] font-mono text-slate-400 mb-0.5">
            <span>Azimuth Heading (Yaw Y):</span>
            <span className="text-indigo-300 font-semibold">
              {antenna.rotation[1]}°
            </span>
          </div>
          <input
            type="range"
            min="-180"
            max="180"
            step="1"
            value={antenna.rotation[1]}
            onChange={(e) => setRotY(parseFloat(e.target.value))}
            className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-400"
          />
          <div className="flex justify-between text-[8px] font-mono text-slate-500">
            <span>-180° (South)</span>
            <span>0° (East / Forward)</span>
            <span>+180° (South)</span>
          </div>
        </div>

        {/* Roll / Polarization (Z-Axis) */}
        <div>
          <div className="flex justify-between items-center text-[10px] font-mono text-slate-400 mb-0.5">
            <span>Polarization / Roll (Z):</span>
            <span className="text-indigo-300 font-semibold">
              {antenna.rotation[2]}°
            </span>
          </div>
          <input
            type="range"
            min="-90"
            max="90"
            step="1"
            value={antenna.rotation[2]}
            onChange={(e) => setRotZ(parseFloat(e.target.value))}
            className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-400"
          />
        </div>

        {/* Quick Aim & Polarization Alignment Tools */}
        <div className="pt-1 border-t border-slate-800/60 flex flex-wrap gap-1 font-mono text-[9px]">
          <button
            onClick={() => setRotZ(0)}
            className="px-2 py-1 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded border border-slate-800"
          >
            Vert Pol (0°)
          </button>
          <button
            onClick={() => setRotZ(90)}
            className="px-2 py-1 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded border border-slate-800"
          >
            Horiz Pol (90°)
          </button>
          <button
            onClick={() => setRotZ(45)}
            className="px-2 py-1 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded border border-slate-800"
          >
            Slant (45°)
          </button>
          <button
            onClick={() => aimAntennaAt(antennaKey, otherAntennaKey)}
            title="Automatically point main beam boresight at the other antenna in 3D"
            className="px-2 py-1 bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 rounded border border-indigo-500/40 flex items-center space-x-1"
          >
            <Target className="w-2.5 h-2.5" />
            <span>Aim at Target</span>
          </button>
          <button
            onClick={() => resetTransform(antennaKey)}
            title="Reset position and rotation to default"
            className="px-2 py-1 bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 rounded border border-slate-800 flex items-center space-x-1"
          >
            <RotateCcw className="w-2.5 h-2.5" />
            <span>Reset Pos/Rot</span>
          </button>
        </div>
      </div>

      {/* Antenna Type Selection */}
      <div>
        <label className="text-[11px] font-mono text-slate-400 mb-1.5 flex items-center space-x-1.5">
          <Layers className="w-3.5 h-3.5 text-sky-400" />
          <span>Antenna Topology</span>
        </label>
        <select
          value={antenna.type}
          onChange={(e) => {
            const newType = e.target.value as AntennaType;
            const def = ANTENNA_TYPES.find((t) => t.id === newType);
            updateAntenna({
              type: newType,
              gainDbi: def ? def.defaultGain : antenna.gainDbi,
              gainMode: "rated",
              gainReferenceFrequencyMHz: antenna.frequencyMHz,
              radiationEfficiencyPercent: antenna.radiationEfficiencyPercent ?? 75,
              ...getAntennaDesignDefaults(
                newType,
                antenna.frequencyMHz,
                antenna.lengthMm,
                antenna.diameterMm,
              ),
            });
          }}
          className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200 font-mono focus:outline-none focus:border-sky-500"
        >
          {ANTENNA_TYPES.map((t) => (
            <option key={t.id} value={t.id}>
              {t.label} (Typ: {t.defaultGain} dBi)
            </option>
          ))}
        </select>
      </div>

      <div className="rounded-lg border border-slate-800 bg-slate-950/60 p-3 space-y-2">
        <div className="text-[10px] font-mono font-semibold uppercase tracking-wide text-sky-300">
          {antenna.type === "patch"
            ? "Patch geometry"
            : antenna.type === "helical"
              ? "Helix geometry"
              : antenna.type === "horn"
                ? "Horn geometry"
                : antenna.type === "yagi"
                  ? "Yagi geometry"
                  : antenna.type === "monopole"
                    ? "Ground plane"
                    : "Radiator geometry"}
        </div>
        {antenna.type === "patch" && (
          <>
            <div className="grid grid-cols-2 gap-2">
              <DesignNumberField label="Patch length" value={antenna.patchLengthMm ?? Number(designDefaults.patchLengthMm)} unit="mm" min={1} max={1000} onChange={(value) => updateAntenna({ patchLengthMm: value })} />
              <DesignNumberField label="Patch width" value={antenna.patchWidthMm ?? Number(designDefaults.patchWidthMm)} unit="mm" min={1} max={1000} onChange={(value) => updateAntenna({ patchWidthMm: value })} />
              <DesignNumberField label="Substrate εr" value={antenna.patchSubstrateEr ?? 4.4} unit="" min={1} max={20} step={0.1} onChange={(value) => updateAntenna({ patchSubstrateEr: value })} />
              <DesignNumberField label="Substrate thickness" value={antenna.patchSubstrateThicknessMm ?? 1.6} unit="mm" min={0.1} max={20} onChange={(value) => updateAntenna({ patchSubstrateThicknessMm: value })} />
              <DesignNumberField label="Ground margin" value={antenna.patchGroundMarginMm ?? Number(designDefaults.patchGroundMarginMm)} unit="mm" min={0} max={500} onChange={(value) => updateAntenna({ patchGroundMarginMm: value })} />
              <DesignNumberField label="Feed inset" value={antenna.patchFeedInsetMm ?? Number(designDefaults.patchFeedInsetMm)} unit="mm" min={0} max={500} onChange={(value) => updateAntenna({ patchFeedInsetMm: value })} />
            </div>
            <p className="text-[9px] leading-relaxed text-slate-500">Length and width are planar dimensions. εr and substrate thickness set the approximate resonant size; feed inset is shown on the source model.</p>
          </>
        )}
        {antenna.type === "helical" && (
          <>
            <div className="grid grid-cols-2 gap-2">
              <DesignNumberField label="Turns" value={antenna.helixTurns ?? 8} unit="turns" min={1} max={40} step={1} onChange={(value) => updateAntenna({ helixTurns: Math.round(value) })} />
              <DesignNumberField label="Pitch" value={antenna.helixPitchMm ?? Number(designDefaults.helixPitchMm)} unit="mm" min={0.1} max={1000} onChange={(value) => updateAntenna({ helixPitchMm: value })} />
              <DesignNumberField label="Coil diameter" value={antenna.helixCoilDiameterMm ?? Number(designDefaults.helixCoilDiameterMm)} unit="mm" min={1} max={1000} onChange={(value) => updateAntenna({ helixCoilDiameterMm: value })} />
              <DesignNumberField label="Wire diameter" value={antenna.helixWireDiameterMm ?? antenna.diameterMm} unit="mm" min={0.2} max={40} onChange={(value) => updateAntenna({ helixWireDiameterMm: value })} />
              <DesignNumberField label="Reflector diameter" value={antenna.helixReflectorDiameterMm ?? Number(designDefaults.helixReflectorDiameterMm)} unit="mm" min={1} max={2000} onChange={(value) => updateAntenna({ helixReflectorDiameterMm: value })} />
            </div>
            <p className="text-[9px] leading-relaxed text-slate-500">Axial length is turns × pitch. A circumference near one wavelength and roughly quarter-wave pitch gives axial-mode operation.</p>
          </>
        )}
        {antenna.type === "horn" && (
          <div className="grid grid-cols-2 gap-2">
            <DesignNumberField label="Aperture width" value={antenna.hornApertureWidthMm ?? Number(designDefaults.hornApertureWidthMm)} unit="mm" min={1} max={2000} onChange={(value) => updateAntenna({ hornApertureWidthMm: value })} />
            <DesignNumberField label="Aperture height" value={antenna.hornApertureHeightMm ?? Number(designDefaults.hornApertureHeightMm)} unit="mm" min={1} max={2000} onChange={(value) => updateAntenna({ hornApertureHeightMm: value })} />
            <DesignNumberField label="Throat width" value={antenna.hornThroatWidthMm ?? Number(designDefaults.hornThroatWidthMm)} unit="mm" min={1} max={1000} onChange={(value) => updateAntenna({ hornThroatWidthMm: value })} />
            <DesignNumberField label="Throat height" value={antenna.hornThroatHeightMm ?? Number(designDefaults.hornThroatHeightMm)} unit="mm" min={1} max={1000} onChange={(value) => updateAntenna({ hornThroatHeightMm: value })} />
          </div>
        )}
        {antenna.type === "yagi" && (
          <div className="grid grid-cols-2 gap-2">
            <DesignNumberField label="Element count" value={antenna.yagiElementCount ?? 6} unit="elements" min={3} max={16} step={1} onChange={(value) => updateAntenna({ yagiElementCount: Math.round(value) })} />
            <DesignNumberField label="Driven element" value={antenna.yagiDrivenElementLengthMm ?? Number(designDefaults.yagiDrivenElementLengthMm)} unit="mm" min={1} max={1000} onChange={(value) => updateAntenna({ yagiDrivenElementLengthMm: value })} />
            <DesignNumberField label="Reflector length" value={antenna.yagiReflectorLengthMm ?? Number(designDefaults.yagiReflectorLengthMm)} unit="mm" min={1} max={1000} onChange={(value) => updateAntenna({ yagiReflectorLengthMm: value })} />
            <DesignNumberField label="Director length" value={antenna.yagiDirectorLengthMm ?? Number(designDefaults.yagiDirectorLengthMm)} unit="mm" min={1} max={1000} onChange={(value) => updateAntenna({ yagiDirectorLengthMm: value })} />
          </div>
        )}
        {antenna.type === "monopole" && (
          <DesignNumberField label="Ground plane diameter" value={antenna.monopoleGroundPlaneDiameterMm ?? Number(designDefaults.monopoleGroundPlaneDiameterMm)} unit="mm" min={1} max={2000} onChange={(value) => updateAntenna({ monopoleGroundPlaneDiameterMm: value })} />
        )}
        {antenna.type === "dipole" && (
          <p className="text-[9px] leading-relaxed text-slate-500">The entered length and element thickness define the center-fed wire dipole.</p>
        )}
        {antenna.type === "isotropic" && (
          <p className="text-[9px] leading-relaxed text-slate-500">Ideal reference source with a uniform pattern; it has no realizable physical radiator.</p>
        )}
      </div>

      {/* 3. Transmit Power (0.01 mW to 100,000 mW / 100 W) */}
      <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800/80 space-y-2">
        <div className="flex items-center justify-between font-mono">
          <span className="text-slate-300 flex items-center space-x-1.5">
            <Flame className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-semibold text-slate-200">Transmit Power</span>
          </span>
          <span className="text-amber-300 font-bold bg-amber-950/40 border border-amber-800/40 px-2 py-0.5 rounded text-[11px]">
            {antenna.powerMilliwatts >= 1000
              ? `${(antenna.powerMilliwatts / 1000).toFixed(antenna.powerMilliwatts >= 10000 ? 0 : 2)} W`
              : `${antenna.powerMilliwatts} mW`}{" "}
            ({powerDbm > 0 ? `+${powerDbm}` : powerDbm} dBm)
          </span>
        </div>

        <input
          type="range"
          min="-2"
          max="5"
          step="0.01"
          value={logPower}
          onChange={handleLogPowerSlider}
          className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
        />

        <div className="flex justify-between text-[9px] font-mono text-slate-400">
          <span>0.01 mW (-20dBm)</span>
          <span>100 mW (+20dBm)</span>
          <span>100 W (+50dBm)</span>
        </div>

        <div className="flex flex-wrap gap-1 pt-1">
          {POWER_PRESETS.map((p) => (
            <button
              key={p.mw}
              onClick={() => updateAntenna({ powerMilliwatts: p.mw })}
              className={`px-1.5 py-0.5 rounded text-[10px] font-mono border transition-all ${
                Math.abs(antenna.powerMilliwatts - p.mw) < 0.001
                  ? "bg-amber-500/20 text-amber-300 border-amber-500/50"
                  : "bg-slate-900/80 text-slate-400 border-slate-800 hover:text-slate-200"
              }`}
            >
              {p.mw >= 1000 ? `${p.mw / 1000}W` : `${p.mw}mW`}
            </button>
          ))}
        </div>
      </div>

      {/* 4. Antenna Gain (dBi) */}
      <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800/80 space-y-2">
        <div className="flex items-center justify-between font-mono">
          <span className="text-slate-300 flex items-center space-x-1.5">
            <Zap className="w-3.5 h-3.5 text-sky-400" />
            <span className="font-semibold text-slate-200">
              Peak Gain (dBi){ratedGainIsOffFrequency ? " · estimated" : ""}
            </span>
          </span>
          <span className="text-sky-300 font-bold bg-sky-950/40 border border-sky-800/40 px-2 py-0.5 rounded text-[11px]">
            {peakGainDbi > 0 ? `+${peakGainDbi.toFixed(1)}` : peakGainDbi.toFixed(1)} dBi
          </span>
        </div>

        <MeasuredPatternControl
          antenna={antenna}
          updateAntenna={updateAntenna}
        />

        <div className="grid grid-cols-2 gap-2">
          <label className="text-[10px] font-mono text-slate-400 space-y-1">
            <span className="block">Gain source</span>
            <select
              value={antenna.gainMode ?? "rated"}
              disabled={hasActiveMeasuredPattern}
              onChange={(event) => updateAntenna({
                gainMode: event.target.value as "rated" | "estimated",
                ...(event.target.value === "rated"
                  ? { gainReferenceFrequencyMHz: antenna.frequencyMHz }
                  : {}),
              })}
              className="w-full rounded-md border border-slate-700 bg-slate-900 px-2 py-1 text-slate-100 disabled:opacity-50"
            >
              <option value="rated">
                {ratedGainIsOffFrequency
                  ? `Rated / manual (${(antenna.gainReferenceFrequencyMHz! / 1000).toFixed(3)} GHz)`
                  : "Rated / manual"}
              </option>
              <option value="estimated">Analytical estimate</option>
            </select>
          </label>
          {hasActiveMeasuredPattern ? (
            <p className="self-end pb-1 text-[9px] font-mono text-emerald-300">
              Peak gain comes from the measured pattern
            </p>
          ) : antenna.type === "isotropic" ? (
            <p className="self-end pb-1 text-[9px] font-mono text-slate-500">Ideal reference fixed at 0 dBi</p>
          ) : antenna.gainMode === "estimated" ? (
            <DesignNumberField
              label="Radiation efficiency"
              value={antenna.radiationEfficiencyPercent ?? 75}
              unit="%"
              min={1}
              max={100}
              onChange={(value) => updateAntenna({ radiationEfficiencyPercent: value })}
            />
          ) : (
            <DesignNumberField
              label="Catalog gain"
              value={antenna.gainDbi}
              unit="dBi"
              min={-5}
              max={30}
              onChange={(value) => updateAntenna({
                gainDbi: value,
                gainReferenceFrequencyMHz: antenna.frequencyMHz,
              })}
            />
          )}
        </div>
        {!hasActiveMeasuredPattern && (
          <p className="text-[9px] leading-relaxed text-slate-500">
            {ratedGainIsOffFrequency
              ? `Catalog gain is rated at ${(antenna.gainReferenceFrequencyMHz! / 1000).toFixed(3)} GHz. Current peak gain and link budget use the analytical frequency-aware estimate.`
              : "Built-in radiation shape is analytical, not measured or full-wave validated. Import a full-sphere measured gain CSV for this antenna design to use its measured pattern and peak gain."}
          </p>
        )}

        <div className="flex justify-between items-center text-[10px] font-mono text-slate-400">
          <span>-5 dBi</span>
          <span className="text-slate-300">
            EIRP:{" "}
            <strong className="text-sky-300">
              {Math.round(eirpDbm * 10) / 10} dBm
            </strong>{" "}
            ({Math.round(eirpWatts * 100) / 100}W)
          </span>
          <span>+30 dBi</span>
        </div>
      </div>

      {/* 5. Frequency (MHz) */}
      <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800/80 space-y-2">
        <div className="flex items-center justify-between font-mono">
          <span className="text-slate-300 flex items-center space-x-1.5">
            <Radio className="w-3.5 h-3.5 text-indigo-400" />
            <span className="font-semibold text-slate-200">
              Operating Frequency
            </span>
          </span>
          <span className="text-indigo-300 font-bold bg-indigo-950/40 border border-indigo-800/40 px-2 py-0.5 rounded text-[11px]">
            {antenna.frequencyMHz >= 1000
              ? `${(antenna.frequencyMHz / 1000).toFixed(2)} GHz`
              : `${antenna.frequencyMHz} MHz`}
          </span>
        </div>

        <input
          type="range"
          min="100"
          max="10000"
          step="25"
          value={antenna.frequencyMHz}
          onChange={(e) =>
            updateAntenna({ frequencyMHz: parseFloat(e.target.value) })
          }
          className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-400"
        />

        <div className="flex flex-wrap gap-1 pt-1">
          {FREQ_PRESETS.map((f) => (
            <button
              key={f.mhz}
              onClick={() => {
                updateAntenna({ frequencyMHz: f.mhz });
              }}
              className={`px-1.5 py-0.5 rounded text-[10px] font-mono border transition-all ${
                antenna.frequencyMHz === f.mhz
                  ? "bg-indigo-500/20 text-indigo-300 border-indigo-500/50"
                  : "bg-slate-900/80 text-slate-400 border-slate-800 hover:text-slate-200"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        <div className="text-[10px] font-mono text-slate-400 flex items-center justify-between pt-1 border-t border-slate-800/50">
          <span>
            λ: <strong className="text-slate-200">{lambdaMm} mm</strong>
          </span>
          <span>
            λ/2 Dipole:{" "}
            <strong className="text-slate-200">
              {Math.round((lambdaMm / 2) * 10) / 10} mm
            </strong>
          </span>
        </div>
      </div>

      {/* These antennas use dedicated dimensions in their topology controls. */}
      {!["patch", "helical", "isotropic"].includes(antenna.type) && (
      <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800/80 space-y-2">
        <div className="flex items-center justify-between font-mono">
          <span className="text-slate-300 flex items-center space-x-1.5">
            <Ruler className="w-3.5 h-3.5 text-emerald-400" />
            <span className="font-semibold text-slate-200">
              {antenna.type === "yagi"
                ? "Boom Length"
                : antenna.type === "horn"
                  ? "Flare Length"
                  : antenna.type === "monopole"
                    ? "Whip Length"
                    : "Physical Length (L)"}
            </span>
          </span>
          <div className="flex items-center space-x-2">
            {(antenna.type === "dipole" || antenna.type === "monopole") && <button
              onClick={() => autoTuneResonance(antennaKey)}
              title="Auto-tune length to resonant λ/2 or λ/4"
              className="text-[10px] text-emerald-400 bg-emerald-950/60 hover:bg-emerald-900/80 px-2 py-0.5 rounded border border-emerald-800/50 flex items-center space-x-1"
            >
              <Wand2 className="w-3 h-3" />
              <span>Resonate</span>
            </button>}
            <span className="text-emerald-300 font-bold bg-emerald-950/40 border border-emerald-800/40 px-2 py-0.5 rounded text-[11px]">
              {antenna.lengthMm} mm
            </span>
          </div>
        </div>

        <input
          type="range"
          min="5"
          max="800"
          step="1"
          value={antenna.lengthMm}
          onChange={(e) =>
            updateAntenna({ lengthMm: parseFloat(e.target.value) })
          }
          className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-400"
        />

        {(antenna.type === "dipole" || antenna.type === "monopole") && <div className="flex items-center justify-between text-[10px] font-mono">
          <span className="text-slate-400">
            Electrical:{" "}
            <strong className="text-emerald-300">{electricalLength} λ</strong>
          </span>
          <span
            className={`px-1.5 py-0.5 rounded text-[9px] ${
              isWireResonant
                ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
                : electricalLength > 1.0
                  ? "bg-amber-500/20 text-amber-300 border border-amber-500/40"
                  : "bg-slate-800 text-slate-400"
            }`}
          >
            {isWireResonant
              ? antenna.type === "monopole" ? "Resonant (λ/4)" : "Resonant (λ/2)"
              : electricalLength > 1.0
                ? "Multi-Lobe Mode"
                : antenna.type === "monopole" ? "Short Monopole" : "Short Dipole"}
          </span>
        </div>}
      </div>
      )}

      {/* Only wire and array elements have a meaningful element diameter. */}
      {["dipole", "monopole", "yagi"].includes(antenna.type) && (
      <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800/80 space-y-2">
        <div className="flex items-center justify-between font-mono">
          <span className="text-slate-300 flex items-center space-x-1.5">
            <CircleDot className="w-3.5 h-3.5 text-purple-400" />
            <span className="font-semibold text-slate-200">
              {antenna.type === "yagi" ? "Element Diameter (d)" : "Wire Diameter (d)"}
            </span>
          </span>
          <span className="text-purple-300 font-bold bg-purple-950/40 border border-purple-800/40 px-2 py-0.5 rounded text-[11px]">
            {antenna.diameterMm} mm
          </span>
        </div>

        <input
          type="range"
          min="0.2"
          max="40"
          step="0.2"
          value={antenna.diameterMm}
          onChange={(e) =>
            updateAntenna({ diameterMm: parseFloat(e.target.value) })
          }
          className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-purple-400"
        />

        {antenna.type !== "yagi" && <div className="flex items-center justify-between text-[10px] font-mono text-slate-400">
          <span>
            Ratio L/d:{" "}
            {(antenna.lengthMm / Math.max(0.1, antenna.diameterMm)).toFixed(0)}
          </span>
          <span>
            Estimated element shortening:{" "}
            <strong className="text-slate-200">{(vf * 100).toFixed(1)}%</strong>
          </span>
        </div>}
      </div>
      )}

      {/* Lobe opacity controls only appearance, not the range radius. */}
      <div className="grid grid-cols-1 gap-2 pt-1 font-mono text-[11px] text-slate-400">
        <div>
          <div className="flex justify-between mb-1">
            <span>Opacity:</span>
            <span>{Math.round(antenna.opacity * 100)}%</span>
          </div>
          <input
            type="range"
            min="0.2"
            max="1.0"
            step="0.05"
            value={antenna.opacity}
            onChange={(e) =>
              updateAntenna({ opacity: parseFloat(e.target.value) })
            }
            className="w-full h-1 bg-slate-800 rounded appearance-none cursor-pointer accent-slate-400"
          />
        </div>
      </div>
    </div>
  );
};

export const AntennaControlPanel: React.FC = () => {
  const antenna1 = useAntennaStore((s) => s.antenna1);
  const antenna2 = useAntennaStore((s) => s.antenna2);
  const updateAntenna1 = useAntennaStore((s) => s.updateAntenna1);
  const updateAntenna2 = useAntennaStore((s) => s.updateAntenna2);
  const selectedTab = useAntennaStore((s) => s.selectedAntennaId);
  const setSelectedTab = useAntennaStore((s) => s.setSelectedAntennaId);

  // Environment Store
  const rfEnvironment = useAntennaStore((s) => s.rfEnvironment);
  const setWeather = useAntennaStore((s) => s.setWeather);
  const setBandwidthMHz = useAntennaStore((s) => s.setBandwidthMHz);
  const setNoiseFigureDb = useAntennaStore((s) => s.setNoiseFigureDb);
  const evalDistanceMeters = useAntennaStore((s) => s.evalDistanceMeters);
  const setEvalDistanceMeters = useAntennaStore((s) => s.setEvalDistanceMeters);

  const [envOpen, setEnvOpen] = useState(true);

  const noiseFloor = calculateNoiseFloor(
    rfEnvironment.bandwidthMHz * 1e6,
    rfEnvironment.noiseFigureDb,
    rfEnvironment.temperatureK,
  );
  const { specificAttenuationDbPerKm } = calculateAtmosphericLoss(
    1000,
    2400,
    rfEnvironment.weather,
  );

  return (
    <div className="h-full flex flex-col bg-slate-900/90 backdrop-blur-xl border-r border-slate-800 select-none overflow-hidden">
      {/* Tab Switcher */}
      <div className="p-3 border-b border-slate-800 grid grid-cols-2 gap-2 bg-slate-950/40">
        <button
          onClick={() => setSelectedTab("antenna-1")}
          className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center justify-center space-x-2 transition-all ${
            selectedTab === "antenna-1"
              ? "bg-sky-500/15 text-sky-400 border border-sky-500/40 shadow-sm"
              : "text-slate-400 hover:text-slate-200 border border-transparent hover:bg-slate-800/40"
          }`}
        >
          <div className="w-2.5 h-2.5 rounded-full bg-sky-400 shadow-sm" />
          <span>Antenna 1 (Tx A)</span>
        </button>

        <button
          onClick={() => setSelectedTab("antenna-2")}
          className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center justify-center space-x-2 transition-all ${
            selectedTab === "antenna-2"
              ? "bg-rose-500/15 text-rose-400 border border-rose-500/40 shadow-sm"
              : "text-slate-400 hover:text-slate-200 border border-transparent hover:bg-slate-800/40"
          }`}
        >
          <div className="w-2.5 h-2.5 rounded-full bg-rose-400 shadow-sm" />
          <span>Antenna 2 (Tx B)</span>
        </button>
      </div>

      {/* Scrollable Control Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {selectedTab === "antenna-1" ? (
          <AntennaSingleTab
            antenna={antenna1}
            updateAntenna={updateAntenna1}
            antennaKey="antenna-1"
          />
        ) : (
          <AntennaSingleTab
            antenna={antenna2}
            updateAntenna={updateAntenna2}
            antennaKey="antenna-2"
          />
        )}

        {/* Global Atmospheric Loss & RF Channel Noise Floor Card */}
        <div className="bg-slate-950/80 rounded-2xl border border-cyan-500/30 p-3.5 space-y-3 font-mono text-xs">
          <button
            onClick={() => setEnvOpen(!envOpen)}
            className="w-full flex items-center justify-between text-slate-200 font-bold"
          >
            <div className="flex items-center space-x-2">
              <CloudRain className="w-4 h-4 text-cyan-400" />
              <span>Atmospheric & Channel SNR</span>
            </div>
            {envOpen ? (
              <ChevronUp className="w-3.5 h-3.5" />
            ) : (
              <ChevronDown className="w-3.5 h-3.5" />
            )}
          </button>

          {envOpen && (
            <div className="space-y-3 pt-1 border-t border-slate-800/80">
              {/* Receiver Distance (D) */}
              <div>
                <div className="flex justify-between text-[10px] text-slate-400 mb-1">
                  <span>Receiver Distance (D):</span>
                  <span className="text-cyan-300 font-bold bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/40">
                    {evalDistanceMeters < 1000
                      ? `${evalDistanceMeters.toFixed(1)} m`
                      : `${(evalDistanceMeters / 1000).toFixed(2)} km`}
                  </span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="200"
                  step="0.5"
                  value={Math.min(200, evalDistanceMeters)}
                  onChange={(e) =>
                    setEvalDistanceMeters(parseFloat(e.target.value))
                  }
                  className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                />
                <div className="flex justify-between text-[8px] text-slate-500">
                  <span>0.5m (Near-field)</span>
                  <span>50m</span>
                  <span>200m (Far-field)</span>
                </div>
              </div>

              {/* Weather Conditions (ITU-R P.676 & P.838) */}
              <div>
                <label className="text-[10px] text-slate-400 block mb-1">
                  Weather & Atmosphere Condition:
                </label>
                <div className="grid grid-cols-2 gap-1">
                  {[
                    { id: "clear", label: "Clear Sky" },
                    { id: "fog", label: "Moderate Fog" },
                    { id: "light_rain", label: "Light Rain (2.5mm)" },
                    { id: "heavy_rain", label: "Tropical Rain (25mm)" },
                  ].map((w) => (
                    <button
                      key={w.id}
                      onClick={() => setWeather(w.id as WeatherCondition)}
                      className={`px-2 py-1.5 rounded-lg text-[10px] border transition-all text-left ${
                        rfEnvironment.weather === w.id
                          ? "bg-cyan-500/20 text-cyan-300 border-cyan-500/50 font-bold"
                          : "bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200"
                      }`}
                    >
                      {w.label}
                    </button>
                  ))}
                </div>
                <div className="text-[9px] text-slate-400 mt-1 flex justify-between">
                  <span>Atmo Attenuation (2.4G):</span>
                  <span className="text-cyan-300 font-bold">
                    {specificAttenuationDbPerKm.toFixed(3)} dB/km
                  </span>
                </div>
              </div>

              {/* Channel Bandwidth for Noise Floor (B) */}
              <div>
                <div className="flex justify-between text-[10px] text-slate-400 mb-1">
                  <span>Channel Bandwidth (B):</span>
                  <span className="text-indigo-300 font-bold">
                    {rfEnvironment.bandwidthMHz} MHz
                  </span>
                </div>
                <div className="flex flex-wrap gap-1">
                  {[
                    { bw: 0.125, label: "125k LoRa" },
                    { bw: 1.0, label: "1M BLE" },
                    { bw: 20, label: "20M Wi-Fi" },
                    { bw: 40, label: "40M Wi-Fi" },
                    { bw: 100, label: "100M 5G" },
                  ].map((item) => (
                    <button
                      key={item.bw}
                      onClick={() => setBandwidthMHz(item.bw)}
                      className={`px-1.5 py-0.5 rounded text-[10px] border transition-all ${
                        rfEnvironment.bandwidthMHz === item.bw
                          ? "bg-indigo-500/20 text-indigo-300 border-indigo-500/50 font-bold"
                          : "bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200"
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Receiver Noise Figure (NF) */}
              <div>
                <div className="flex justify-between text-[10px] text-slate-400 mb-0.5">
                  <span>LNA Noise Figure (NF):</span>
                  <span className="text-slate-200 font-bold">
                    +{rfEnvironment.noiseFigureDb} dB
                  </span>
                </div>
                <input
                  type="range"
                  min="2"
                  max="12"
                  step="0.5"
                  value={rfEnvironment.noiseFigureDb}
                  onChange={(e) => setNoiseFigureDb(parseFloat(e.target.value))}
                  className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-400"
                />
              </div>

              {/* Live Noise Floor Output */}
              <div className="bg-slate-900 p-2 rounded-xl border border-slate-800 flex items-center justify-between text-[11px]">
                <span className="text-slate-400">
                  Total Noise Floor (kTB + NF):
                </span>
                <span className="text-indigo-300 font-bold">
                  {noiseFloor.toFixed(1)} dBm
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
