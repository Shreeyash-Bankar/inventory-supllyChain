import React, { useState } from "react";
import { useAntennaStore } from "../store/antennaStore";
import { PolarPlot } from "./PolarPlot";
import {
  calculateEIRP,
  calculateMaxCoverageRange,
  mwToDbm,
  getWavelengthMm,
  calculateAtmosphericLoss,
} from "../math/rfPhysics";
import { getColorFromColormap } from "../math/colormaps";
import { getSharedGainColorScale } from "../math/directionGainColors";
import { getAntennaPeakGainDbi } from "../math/radiationPatterns";
import { calculateAntennaPairLinkBudget } from "../math/linkBudget";
import {
  BarChart3,
  ChevronDown,
  ChevronUp,
  Radio,
  Target,
  CloudRain,
  Cpu,
} from "lucide-react";

export const BottomAnalyticsDock: React.FC = () => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [showPolarModal, setShowPolarModal] = useState(false);

  const antenna1 = useAntennaStore((s) => s.antenna1);
  const antenna2 = useAntennaStore((s) => s.antenna2);
  const colormap = useAntennaStore((s) => s.colormap);
  const heatmapMetric = useAntennaStore((s) => s.heatmapMetric);
  const rxSensitivityDbm = useAntennaStore((s) => s.rxSensitivityDbm);
  const evalDistanceMeters = useAntennaStore((s) => s.evalDistanceMeters);
  const rfEnvironment = useAntennaStore((s) => s.rfEnvironment);
  const gainColorScale = getSharedGainColorScale(antenna1, antenna2);

  const pairLink = calculateAntennaPairLinkBudget(
    antenna1,
    antenna2,
    rfEnvironment,
    rxSensitivityDbm,
  );
  // Antenna 1 Metrics
  const gain1Dbi = getAntennaPeakGainDbi(antenna1);
  const gain2Dbi = getAntennaPeakGainDbi(antenna2);
  const eirp1 = calculateEIRP(antenna1.powerMilliwatts, gain1Dbi);
  const maxRange1 = calculateMaxCoverageRange(
    antenna1.powerMilliwatts,
    gain1Dbi,
    antenna1.frequencyMHz,
    rxSensitivityDbm,
    0,
    rfEnvironment.weather,
  );
  const lambda1 = Math.round(getWavelengthMm(antenna1.frequencyMHz) * 10) / 10;
  // const res1 = calculateReceivedPowerDbm(
  //   antenna1.powerMilliwatts,
  //   antenna1.gainDbi,
  //   0,
  //   evalDistanceMeters,
  //   antenna1.frequencyMHz,
  //   rfEnvironment.weather,
  // );

  // Antenna 2 Metrics
  const eirp2 = calculateEIRP(antenna2.powerMilliwatts, gain2Dbi);
  const maxRange2 = calculateMaxCoverageRange(
    antenna2.powerMilliwatts,
    gain2Dbi,
    antenna2.frequencyMHz,
    rxSensitivityDbm,
    0,
    rfEnvironment.weather,
  );
  const lambda2 = Math.round(getWavelengthMm(antenna2.frequencyMHz) * 10) / 10;
  // const res2 = calculateReceivedPowerDbm(
  //   antenna2.powerMilliwatts,
  //   antenna2.gainDbi,
  //   0,
  //   evalDistanceMeters,
  //   antenna2.frequencyMHz,
  //   rfEnvironment.weather,
  // );

  // Range Delta Comparison
  const rangeDeltaRatio = (maxRange2 / Math.max(0.1, maxRange1)).toFixed(2);
  const betterRangeAntenna = maxRange2 >= maxRange1 ? "Antenna 2" : "Antenna 1";

  return (
    <div className="absolute bottom-0 left-0 right-0 z-20 pointer-events-auto">
      {/* Drawer Container */}
      <div className="bg-slate-900/95 backdrop-blur-xl border-t border-slate-800 shadow-2xl transition-all duration-300">
        {/* Compact Header Bar */}
        <div className="h-10 px-4 flex items-center justify-between border-b border-slate-800/80 bg-slate-950/60 text-xs font-mono">
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setIsExpanded(!isExpanded)}
              className="flex items-center space-x-1.5 text-slate-300 hover:text-white transition-colors"
            >
              <BarChart3 className="w-4 h-4 text-sky-400" />
              <span className="font-semibold text-slate-200">
                Antenna Coverage & SNR Comparison
              </span>
              {isExpanded ? (
                <ChevronDown className="w-3.5 h-3.5" />
              ) : (
                <ChevronUp className="w-3.5 h-3.5" />
              )}
            </button>

            {/* Quick Summary Pill */}
            <span className="hidden md:inline-flex items-center space-x-1.5 text-[11px] bg-slate-900 px-2.5 py-0.5 rounded-full border border-slate-800 text-slate-400">
              <span>Sensitivity:</span>
              <strong className="text-sky-300">{rxSensitivityDbm} dBm</strong>
            </span>

            <span className="hidden sm:inline-flex items-center space-x-1 text-[11px] text-emerald-400">
              <Target className="w-3.5 h-3.5" />
              <span>
                {betterRangeAntenna} covers{" "}
                {maxRange1 > 0 && maxRange2 > 0
                  ? `${rangeDeltaRatio}x range`
                  : "more area"}
              </span>
            </span>

            {/* Weather / Atmo indicator */}
            <span className="hidden lg:inline-flex items-center space-x-1 text-[11px] text-cyan-300">
              <CloudRain className="w-3.5 h-3.5" />
              <span className="capitalize">
                {rfEnvironment.weather.replace("_", " ")} Atmo Loss
              </span>
            </span>
          </div>

          <div className="flex items-center space-x-3">
            {/* Color Legend Preview */}
            <div className="hidden lg:flex items-center space-x-2">
              <span className="text-[10px] text-slate-400">
                {heatmapMetric === "dbi"
                  ? `${gainColorScale.minDbi.toFixed(1)} dBi`
                  : "Min"}
              </span>
              <div
                className="w-28 h-2 rounded-full overflow-hidden border border-slate-700/60"
                style={{
                  background: `linear-gradient(to right, ${getColorFromColormap(0, colormap).getStyle()}, ${getColorFromColormap(
                    0.25,
                    colormap,
                  ).getStyle()}, ${getColorFromColormap(0.5, colormap).getStyle()}, ${getColorFromColormap(
                    0.75,
                    colormap,
                  ).getStyle()}, ${getColorFromColormap(1.0, colormap).getStyle()})`,
                }}
              />
              <span className="text-[10px] text-slate-400">
                {heatmapMetric === "dbi"
                  ? `${gainColorScale.maxDbi.toFixed(1)} dBi`
                  : `Max (${heatmapMetric.toUpperCase()})`}
              </span>
            </div>

            {/* 2D Polar Plots button */}
            <button
              onClick={() => setShowPolarModal(!showPolarModal)}
              className="px-2.5 py-1 rounded-lg text-[11px] bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 flex items-center space-x-1.5 transition-colors"
            >
              <Radio className="w-3 h-3 text-sky-400" />
              <span>2D Polar Cuts</span>
            </button>
          </div>
        </div>

        {/* Expanded Comparison Content */}
        {isExpanded && (
          <div className="p-4 grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono max-h-60 overflow-y-auto">
            {/* Antenna 1 Card */}
            <div className="bg-slate-950/70 p-3 rounded-xl border border-sky-500/30 space-y-2">
              <div className="flex items-center justify-between pb-1 border-b border-slate-800">
                <span className="font-bold text-sky-400 flex items-center space-x-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-sky-400" />
                  <span>{antenna1.name}</span>
                </span>
                <span className="text-slate-400">
                  {antenna1.type.toUpperCase()}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-y-1 text-slate-300 text-[11px]">
                <span className="text-slate-400">Power:</span>
                <span className="text-right">
                  {antenna1.powerMilliwatts >= 1000
                    ? `${antenna1.powerMilliwatts / 1000} W`
                    : `${antenna1.powerMilliwatts} mW`}{" "}
                  ({mwToDbm(antenna1.powerMilliwatts).toFixed(1)} dBm)
                </span>

                <span className="text-slate-400">Gain (Peak):</span>
                <span className="text-right text-sky-300 font-bold">
                  {gain1Dbi >= 0 ? "+" : ""}{gain1Dbi.toFixed(1)} dBi
                </span>

                <span className="text-slate-400">
                  Atmo Loss (@ {evalDistanceMeters}m):
                </span>
                {/* <span className="text-right text-cyan-300">
                  -{res1.atmosphericLossDb.toFixed(3)} dB
                </span> */}

                <span className="text-slate-400">EIRP Radiated:</span>
                <span className="text-right">
                  {eirp1.eirpDbm.toFixed(1)} dBm ({eirp1.eirpWatts.toFixed(2)}{" "}
                  W)
                </span>

                <span className="text-slate-400">Max Range (inc. Atmo):</span>
                <span className="text-right text-emerald-400 font-bold">
                  {maxRange1 < 1000
                    ? `${maxRange1.toFixed(1)} m`
                    : `${(maxRange1 / 1000).toFixed(2)} km`}
                </span>
              </div>
            </div>

            <div className="bg-slate-900/90 p-2 rounded-lg border border-indigo-500/30 flex items-center justify-between">
              <span className="text-slate-400 text-[11px]">Receiver SNR:</span>

              <span className="font-bold text-indigo-300">
                {pairLink.snrDb === null
                  ? "N/A"
                  : `${pairLink.snrDb.toFixed(1)} dB`}
              </span>
            </div>

            <div className="bg-slate-900/90 p-2 rounded-lg border border-slate-800 flex items-center justify-between">
              <span className="text-slate-400 text-[11px]">
                Actual Link Distance:
              </span>

              <span className="font-bold text-sky-300">
                {pairLink.distanceMeters.toFixed(2)} m
              </span>
            </div>

            {/* Antenna 2 Card */}
            <div className="bg-slate-950/70 p-3 rounded-xl border border-rose-500/30 space-y-2">
              <div className="flex items-center justify-between pb-1 border-b border-slate-800">
                <span className="font-bold text-rose-400 flex items-center space-x-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-rose-400" />
                  <span>{antenna2.name}</span>
                </span>
                <span className="text-slate-400">
                  {antenna2.type.toUpperCase()}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-y-1 text-slate-300 text-[11px]">
                <span className="text-slate-400">Power:</span>
                <span className="text-right">
                  {antenna2.powerMilliwatts >= 1000
                    ? `${antenna2.powerMilliwatts / 1000} W`
                    : `${antenna2.powerMilliwatts} mW`}{" "}
                  ({mwToDbm(antenna2.powerMilliwatts).toFixed(1)} dBm)
                </span>

                <span className="text-slate-400">Gain (Peak):</span>
                <span className="text-right text-rose-300 font-bold">
                  {gain2Dbi >= 0 ? "+" : ""}{gain2Dbi.toFixed(1)} dBi
                </span>

                <span className="text-slate-400">
                  Atmo Loss (@ {evalDistanceMeters}m):
                </span>
                {/* <span className="text-right text-cyan-300">
                  -{res2.atmosphericLossDb.toFixed(3)} dB
                </span> */}

                <span className="text-slate-400">EIRP Radiated:</span>
                <span className="text-right">
                  {eirp2.eirpDbm.toFixed(1)} dBm ({eirp2.eirpWatts.toFixed(2)}{" "}
                  W)
                </span>

                <span className="text-slate-400">Max Range (inc. Atmo):</span>
                <span className="text-right text-emerald-400 font-bold">
                  {maxRange2 < 1000
                    ? `${maxRange2.toFixed(1)} m`
                    : `${(maxRange2 / 1000).toFixed(2)} km`}
                </span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Floating 2D Polar Plots Modal / Drawer */}
      {showPolarModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 shadow-2xl max-w-2xl w-full text-slate-100 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center space-x-2">
                <Radio className="w-5 h-5 text-sky-400" />
                <h3 className="font-bold text-base font-mono">
                  2D Radiation Polar Cut Analyzer
                </h3>
              </div>
              <button
                onClick={() => setShowPolarModal(false)}
                className="text-slate-400 hover:text-white px-2.5 py-1 rounded-lg bg-slate-800"
              >
                ✕ Close
              </button>
            </div>

            {/* Legend & Info */}
            <div className="flex items-center justify-between text-xs font-mono py-3">
              <div className="flex items-center space-x-4">
                <span className="flex items-center space-x-1.5">
                  <div className="w-3 h-3 rounded-full bg-sky-400" />
                  <span className="text-sky-300">{antenna1.name}</span>
                </span>
                <span className="flex items-center space-x-1.5">
                  <div className="w-3 h-3 rounded-full bg-rose-400" />
                  <span className="text-rose-300">{antenna2.name}</span>
                </span>
              </div>
              <span className="text-slate-400 text-[11px]">
                Dynamic Range: 35 dB (outer circle = 0 dB peak)
              </span>
            </div>

            {/* Side by Side Elevation and Azimuth Plots */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 justify-items-center py-2">
              <div className="flex flex-col items-center">
                <PolarPlot plane="elevation" width={270} height={270} />
                <span className="text-xs font-mono text-slate-400 mt-2">
                  E-Plane (Elevation Cut)
                </span>
              </div>
              <div className="flex flex-col items-center">
                <PolarPlot plane="azimuth" width={270} height={270} />
                <span className="text-xs font-mono text-slate-400 mt-2">
                  H-Plane (Azimuth Cut)
                </span>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] font-mono text-slate-400 flex items-center justify-between">
              <span>
                Physical analytical patterns with realistic sidelobes, ground
                reflection, and cavity directivity.
              </span>
              <button
                onClick={() => setShowPolarModal(false)}
                className="px-4 py-1.5 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold rounded-xl transition-colors"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
