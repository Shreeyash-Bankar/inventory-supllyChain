import React, { useState } from "react";
import { AntennaConfig } from "../types/antenna";
import {
  getAntennaDesignSignature,
  parseMeasuredPatternCsv,
} from "../math/radiationPatterns";

interface MeasuredPatternControlProps {
  antenna: AntennaConfig;
  updateAntenna: (partial: Partial<AntennaConfig>) => void;
}

export const MeasuredPatternControl: React.FC<MeasuredPatternControlProps> = ({
  antenna,
  updateAntenna,
}) => {
  const [error, setError] = useState<string | null>(null);
  const patternPointCount = antenna.measuredPattern?.points.length ?? 0;
  const patternFrequencyMHz = antenna.measuredPattern?.frequencyMHz;
  const patternDesignMatches =
    antenna.measuredPattern?.designSignature ===
    getAntennaDesignSignature(antenna);
  const patternFrequencyMatches = Boolean(
    patternFrequencyMHz &&
      patternDesignMatches &&
      Math.abs(antenna.frequencyMHz - patternFrequencyMHz) <=
        Math.max(1e-6, patternFrequencyMHz * 1e-6),
  );

  const handleFileChange = async (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;

    try {
      const points = parseMeasuredPatternCsv(await file.text());
      updateAntenna({
        measuredPattern: {
          ...points,
          designSignature: getAntennaDesignSignature(antenna),
        },
      });
      setError(null);
    } catch (cause) {
      setError(
        cause instanceof Error ? cause.message : "Could not read this pattern file.",
      );
    }
  };

  return (
    <div className="space-y-1.5 rounded-lg border border-slate-800 bg-slate-900/70 p-2">
      <div className="flex items-center justify-between gap-2">
        <div className="min-w-0">
          <p className="text-[10px] font-mono font-semibold text-slate-200">
            Measured 3D pattern
          </p>
          <p className="text-[9px] leading-relaxed text-slate-500">
            Full-sphere absolute gain CSV; imported data replaces the analytical pattern.
          </p>
        </div>
        <label className="shrink-0 cursor-pointer rounded-md border border-sky-700/60 bg-sky-950/50 px-2 py-1 text-[10px] font-mono text-sky-300 hover:bg-sky-900/60">
          {patternPointCount ? "Replace CSV" : "Import CSV"}
          <input
            type="file"
            accept=".csv,text/csv"
            className="hidden"
            onChange={handleFileChange}
          />
        </label>
      </div>
      {patternPointCount > 0 && (
        <div
          className={`flex items-center justify-between text-[9px] font-mono ${
            patternFrequencyMatches ? "text-emerald-300" : "text-amber-300"
          }`}
        >
          <span>
            {patternPointCount.toLocaleString()} points at {patternFrequencyMHz} MHz
            {patternFrequencyMatches ? " • active" : " • design/frequency mismatch; inactive"}
          </span>
          <button
            type="button"
            className="text-slate-400 hover:text-rose-300"
            onClick={() => {
              updateAntenna({ measuredPattern: undefined });
              setError(null);
            }}
          >
            Remove
          </button>
        </div>
      )}
      {error && <p className="text-[9px] leading-relaxed text-rose-300">{error}</p>}
        <p className="text-[9px] leading-relaxed text-slate-600">
        Columns: frequencyMHz, thetaDeg, phiDeg, gainDbi. The pattern is active only at its measurement frequency. Theta is from local +Y; phi runs +X toward +Z.
        Include a complete grid from theta 0° to 180° with azimuth coverage around 360°.
      </p>
    </div>
  );
};
