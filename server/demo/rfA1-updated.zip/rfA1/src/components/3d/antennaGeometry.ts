// // import * as THREE from 'three';
// // import { AntennaConfig, ColormapType, HeatmapMetric, RFEnvironmentConfig } from '../../types/antenna';
// // import { calculateRadiationPattern } from '../../math/radiationPatterns';
// // import { getColorFromColormap } from '../../math/colormaps';
// // import {
// //   mwToDbm,
// //   calculateReceivedPowerDbm,
// //   calculateElectricField,
// //   calculatePowerDensityUWCm2,
// //   calculateEIRP,
// //   calculateSNR,
// // } from '../../math/rfPhysics';

// // /**
// //  * Builds the 3D Radiation Lobe Mesh with vertex colors corresponding to the radiation heatmap
// //  */
// // export function createRadiationLobeMesh(
// //   config: AntennaConfig,
// //   colormap: ColormapType,
// //   heatmapMetric: HeatmapMetric,
// //   evalDistanceMeters: number,
// //   rfEnvironment?: RFEnvironmentConfig
// // ): THREE.Mesh {
// //   // Discretization: 64 theta steps (polar), 96 phi steps (azimuth)
// //   const uSegments = 64; // theta
// //   const vSegments = 96; // phi

// //   const vertexCount = (uSegments + 1) * (vSegments + 1);
// //   const positions = new Float32Array(vertexCount * 3);
// //   const colors = new Float32Array(vertexCount * 3);
// //   const normals = new Float32Array(vertexCount * 3);
// //   const uvs = new Float32Array(vertexCount * 2);
// //   const indices: number[] = [];

// //   const { gainDbi, powerMilliwatts, frequencyMHz } = config;
// //   const { eirpWatts } = calculateEIRP(powerMilliwatts, gainDbi);

// //   const weather = rfEnvironment?.weather || 'clear';
// //   const bwHz = (rfEnvironment?.bandwidthMHz || 20) * 1e6;
// //   const nfDb = rfEnvironment?.noiseFigureDb || 5;

// //   // Determine dynamic range for heatmap metric
// //   const peakDbi = gainDbi;
// //   const minDbi = peakDbi - 30; // 30 dB dynamic range

// //   let vertexIndex = 0;

// //   for (let i = 0; i <= uSegments; i++) {
// //     const u = i / uSegments;
// //     const theta = u * Math.PI; // 0 to PI

// //     for (let j = 0; j <= vSegments; j++) {
// //       const v = j / vSegments;
// //       const phi = v * 2 * Math.PI - Math.PI; // -PI to PI

// //       // Sample radiation pattern
// //       const sample = calculateRadiationPattern(theta, phi, config);

// //       const r = sample.radius * (config.scaleLobe || 1.0);
// //       const sinT = Math.sin(theta);
// //       const cosT = Math.cos(theta);
// //       const sinP = Math.sin(phi);
// //       const cosP = Math.cos(phi);

// //       const px = r * sinT * cosP;
// //       const py = r * cosT;
// //       const pz = r * sinT * sinP;

// //       const pIdx = vertexIndex * 3;
// //       positions[pIdx] = px;
// //       positions[pIdx + 1] = py;
// //       positions[pIdx + 2] = pz;

// //       // Calculate normalized value for heatmap coloring
// //       let normVal = 0;

// //       switch (heatmapMetric) {
// //         case 'dbi': {
// //           normVal = (sample.gainDbi - minDbi) / Math.max(1, peakDbi - minDbi);
// //           break;
// //         }
// //         case 'rssi': {
// //           const { rssiDbm } = calculateReceivedPowerDbm(powerMilliwatts, sample.gainDbi, 0, evalDistanceMeters, frequencyMHz, weather);
// //           const maxRssi = mwToDbm(powerMilliwatts) + peakDbi - 40;
// //           const minRssi = maxRssi - 35;
// //           normVal = (rssiDbm - minRssi) / Math.max(1, maxRssi - minRssi);
// //           break;
// //         }
// //         case 'snr': {
// //           const { rssiDbm } = calculateReceivedPowerDbm(powerMilliwatts, sample.gainDbi, 0, evalDistanceMeters, frequencyMHz, weather);
// //           const { snrDb } = calculateSNR(rssiDbm, bwHz, nfDb);
// //           // Map -5 dB to +35 dB onto [0, 1]
// //           normVal = (snrDb - (-5)) / 40;
// //           break;
// //         }
// //         case 'field_strength': {
// //           const eField = calculateElectricField(eirpWatts * Math.pow(sample.relativeLinear, 2), evalDistanceMeters);
// //           const maxE = calculateElectricField(eirpWatts, evalDistanceMeters);
// //           normVal = eField / Math.max(0.001, maxE);
// //           break;
// //         }
// //         case 'power_density': {
// //           const s = calculatePowerDensityUWCm2(eirpWatts * Math.pow(sample.relativeLinear, 2), evalDistanceMeters);
// //           const maxS = calculatePowerDensityUWCm2(eirpWatts, evalDistanceMeters);
// //           normVal = s / Math.max(0.001, maxS);
// //           break;
// //         }
// //       }

// //       normVal = Math.max(0, Math.min(1, normVal));
// //       const col = getColorFromColormap(normVal, colormap);

// //       colors[pIdx] = col.r;
// //       colors[pIdx + 1] = col.g;
// //       colors[pIdx + 2] = col.b;

// //       uvs[vertexIndex * 2] = v;
// //       uvs[vertexIndex * 2 + 1] = u;

// //       vertexIndex++;
// //     }
// //   }

// //   // Create Triangles
// //   for (let i = 0; i < uSegments; i++) {
// //     for (let j = 0; j < vSegments; j++) {
// //       const a = i * (vSegments + 1) + j;
// //       const b = (i + 1) * (vSegments + 1) + j;
// //       const c = (i + 1) * (vSegments + 1) + (j + 1);
// //       const d = i * (vSegments + 1) + (j + 1);

// //       indices.push(a, b, d);
// //       indices.push(b, c, d);
// //     }
// //   }

// //   const geometry = new THREE.BufferGeometry();
// //   geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
// //   geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
// //   geometry.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
// //   geometry.setIndex(indices);
// //   geometry.computeVertexNormals();

// //   // Mesh Material
// //   const material = new THREE.MeshStandardMaterial({
// //     vertexColors: true,
// //     roughness: 0.25,
// //     metalness: 0.15,
// //     wireframe: config.wireframe,
// //     transparent: true,
// //     opacity: config.opacity,
// //     side: THREE.DoubleSide,
// //     depthWrite: false, // Prevents Z-fighting in transparent dual lobes
// //   });

// //   const mesh = new THREE.Mesh(geometry, material);
// //   mesh.name = `radiation-lobe-${config.id}`;
// //   mesh.userData = { configId: config.id, isRadiationLobe: true };

// //   return mesh;
// // }

// // /**
// //  * Builds physical 3D antenna representation (brass/copper/dielectric realistic models)
// //  */
// // export function createPhysicalAntennaMesh(config: AntennaConfig): THREE.Group {
// //   const group = new THREE.Group();
// //   group.name = `physical-antenna-${config.id}`;

// //   const { type, lengthMm, diameterMm } = config;

// //   // Normalized scale: map 100mm -> 1.0 unit in 3D scene
// //   const lengthScale = Math.max(0.2, Math.min(4.0, (lengthMm / 100)));
// //   const diaScale = Math.max(0.015, Math.min(0.25, (diameterMm / 100)));

// //   // Materials
// //   const copperMaterial = new THREE.MeshStandardMaterial({
// //     color: 0xcd7f32,
// //     metalness: 0.9,
// //     roughness: 0.2,
// //   });

// //   const brassMaterial = new THREE.MeshStandardMaterial({
// //     color: 0xd4af37,
// //     metalness: 0.85,
// //     roughness: 0.25,
// //   });

// //   const chromeMaterial = new THREE.MeshStandardMaterial({
// //     color: 0xdde2ea,
// //     metalness: 0.95,
// //     roughness: 0.1,
// //   });

// //   const pcbMaterial = new THREE.MeshStandardMaterial({
// //     color: 0x14532d, // dark FR4 green
// //     metalness: 0.1,
// //     roughness: 0.5,
// //   });

// //   const feedMaterial = new THREE.MeshStandardMaterial({
// //     color: 0x1e293b,
// //     metalness: 0.4,
// //     roughness: 0.6,
// //   });

// //   switch (type) {
// //     case 'dipole': {
// //       // Center fed dipole with upper and lower elements along Y axis
// //       const armLength = (lengthScale * 0.95) / 2;
// //       const radius = Math.max(0.02, diaScale);

// //       // Upper arm
// //       const upperGeo = new THREE.CylinderGeometry(radius, radius, armLength, 16);
// //       const upperMesh = new THREE.Mesh(upperGeo, brassMaterial);
// //       upperMesh.position.y = armLength / 2 + 0.04;

// //       // Lower arm
// //       const lowerGeo = new THREE.CylinderGeometry(radius, radius, armLength, 16);
// //       const lowerMesh = new THREE.Mesh(lowerGeo, brassMaterial);
// //       lowerMesh.position.y = -armLength / 2 - 0.04;

// //       // Center feedpoint insulator / balun
// //       const feedGeo = new THREE.CylinderGeometry(radius * 1.6, radius * 1.6, 0.08, 16);
// //       const feedMesh = new THREE.Mesh(feedGeo, feedMaterial);

// //       // Coax feed connector
// //       const coaxGeo = new THREE.CylinderGeometry(radius * 0.8, radius * 0.8, 0.35, 12);
// //       const coaxMesh = new THREE.Mesh(coaxGeo, chromeMaterial);
// //       coaxMesh.rotation.z = Math.PI / 2;
// //       coaxMesh.position.x = -0.18;

// //       group.add(upperMesh, lowerMesh, feedMesh, coaxMesh);
// //       break;
// //     }

// //     case 'monopole': {
// //       // Quarter-wave whip along +Y over ground plane disc
// //       const whipLength = lengthScale * 0.9;
// //       const radius = Math.max(0.02, diaScale);

// //       // Ground plane disc
// //       const groundGeo = new THREE.CylinderGeometry(radius * 8, radius * 8, 0.03, 32);
// //       const groundMesh = new THREE.Mesh(groundGeo, chromeMaterial);
// //       groundMesh.position.y = 0;

// //       // Whip element
// //       const whipGeo = new THREE.CylinderGeometry(radius * 0.7, radius, whipLength, 16);
// //       const whipMesh = new THREE.Mesh(whipGeo, brassMaterial);
// //       whipMesh.position.y = whipLength / 2 + 0.02;

// //       // SMA base
// //       const baseGeo = new THREE.CylinderGeometry(radius * 2, radius * 2, 0.1, 16);
// //       const baseMesh = new THREE.Mesh(baseGeo, feedMaterial);
// //       baseMesh.position.y = -0.05;

// //       group.add(groundMesh, whipMesh, baseMesh);
// //       break;
// //     }

// //     case 'patch': {
// //       // Microstrip patch: FR4 PCB substrate + copper rectangular patch on top facing +X
// //       const size = lengthScale * 0.7;
// //       const subGeo = new THREE.BoxGeometry(0.04, size * 1.3, size * 1.3);
// //       const subMesh = new THREE.Mesh(subGeo, pcbMaterial);

// //       const patchGeo = new THREE.BoxGeometry(0.02, size * 0.9, size * 0.9);
// //       const patchMesh = new THREE.Mesh(patchGeo, copperMaterial);
// //       patchMesh.position.x = 0.025; // on top of substrate facing +X

// //       // SMA connector on the back
// //       const smaGeo = new THREE.CylinderGeometry(0.04, 0.04, 0.15, 12);
// //       const smaMesh = new THREE.Mesh(smaGeo, brassMaterial);
// //       smaMesh.rotation.z = Math.PI / 2;
// //       smaMesh.position.x = -0.09;

// //       group.add(subMesh, patchMesh, smaMesh);
// //       break;
// //     }

// //     case 'yagi': {
// //       // Boom + Reflector + Driven element + Directors along +X axis
// //       const boomLength = lengthScale * 1.5;
// //       const boomGeo = new THREE.CylinderGeometry(0.025, 0.025, boomLength, 12);
// //       const boomMesh = new THREE.Mesh(boomGeo, chromeMaterial);
// //       boomMesh.rotation.z = Math.PI / 2;
// //       boomMesh.position.x = boomLength / 2 - 0.2;

// //       // Reflector (longest element at rear)
// //       const refLen = lengthScale * 0.95;
// //       const refGeo = new THREE.CylinderGeometry(0.015, 0.015, refLen, 12);
// //       const refMesh = new THREE.Mesh(refGeo, chromeMaterial);
// //       refMesh.position.x = -0.15;

// //       // Driven element (dipole with feed)
// //       const drvLen = lengthScale * 0.85;
// //       const drvGeo = new THREE.CylinderGeometry(0.018, 0.018, drvLen, 12);
// //       const drvMesh = new THREE.Mesh(drvGeo, brassMaterial);
// //       drvMesh.position.x = 0.08;

// //       group.add(boomMesh, refMesh, drvMesh);

// //       // 4 Directors spaced along +X
// //       for (let i = 1; i <= 4; i++) {
// //         const dirLen = drvLen * (1 - i * 0.06);
// //         const dirGeo = new THREE.CylinderGeometry(0.015, 0.015, dirLen, 12);
// //         const dirMesh = new THREE.Mesh(dirGeo, chromeMaterial);
// //         dirMesh.position.x = 0.08 + i * (boomLength / 5);
// //         group.add(dirMesh);
// //       }
// //       break;
// //     }

// //     case 'horn': {
// //       // Pyramidal flared horn facing +X
// //       const hornLength = lengthScale * 0.9;
// //       const apertureSize = Math.max(0.4, diaScale * 3);
// //       const throatSize = 0.12;

// //       // Flared horn pyramid
// //       const hornGeo = new THREE.CylinderGeometry(apertureSize, throatSize, hornLength, 4, 1, true);
// //       const hornMesh = new THREE.Mesh(hornGeo, brassMaterial);
// //       hornMesh.rotation.z = -Math.PI / 2;
// //       hornMesh.rotation.y = Math.PI / 4;
// //       hornMesh.position.x = hornLength / 2;

// //       // Waveguide throat & flange
// //       const throatGeo = new THREE.CylinderGeometry(throatSize, throatSize, 0.2, 4);
// //       const throatMesh = new THREE.Mesh(throatGeo, chromeMaterial);
// //       throatMesh.rotation.z = -Math.PI / 2;
// //       throatMesh.rotation.y = Math.PI / 4;
// //       throatMesh.position.x = -0.1;

// //       group.add(hornMesh, throatMesh);
// //       break;
// //     }

// //     case 'helical': {
// //       // Ground reflector disc + helical wire wound along +Z or +Y
// //       const groundGeo = new THREE.CylinderGeometry(0.5, 0.5, 0.02, 24);
// //       const groundMesh = new THREE.Mesh(groundGeo, chromeMaterial);
// //       groundMesh.position.y = -0.1;

// //       // Spiral coil curve
// //       const turns = 6;
// //       const height = lengthScale * 1.1;
// //       const coilRadius = Math.max(0.12, diaScale);
// //       const curvePoints: THREE.Vector3[] = [];

// //       for (let t = 0; t <= 120; t++) {
// //         const angle = (t / 120) * (turns * 2 * Math.PI);
// //         const cy = (t / 120) * height;
// //         const cx = coilRadius * Math.cos(angle);
// //         const cz = coilRadius * Math.sin(angle);
// //         curvePoints.push(new THREE.Vector3(cx, cy, cz));
// //       }

// //       const curve = new THREE.CatmullRomCurve3(curvePoints);
// //       const tubeGeo = new THREE.TubeGeometry(curve, 90, 0.015, 8, false);
// //       const tubeMesh = new THREE.Mesh(tubeGeo, copperMaterial);

// //       group.add(groundMesh, tubeMesh);
// //       break;
// //     }

// //     case 'isotropic':
// //     default: {
// //       // Glowing omnidirectional beacon sphere
// //       const sphereGeo = new THREE.SphereGeometry(0.12, 24, 24);
// //       const sphereMat = new THREE.MeshStandardMaterial({
// //         color: 0x38bdf8,
// //         emissive: 0x0284c7,
// //         emissiveIntensity: 0.6,
// //         roughness: 0.2,
// //       });
// //       const beacon = new THREE.Mesh(sphereGeo, sphereMat);
// //       group.add(beacon);
// //       break;
// //     }
// //   }

// //   // Anchor ring indicator
// //   const ringGeo = new THREE.RingGeometry(0.1, 0.15, 24);
// //   const ringMat = new THREE.MeshBasicMaterial({
// //     color: new THREE.Color(config.color),
// //     side: THREE.DoubleSide,
// //     transparent: true,
// //     opacity: 0.8,
// //   });
// //   const ring = new THREE.Mesh(ringGeo, ringMat);
// //   ring.rotation.x = Math.PI / 2;
// //   ring.position.y = -0.01;
// //   group.add(ring);

// //   return group;
// // }
// import * as THREE from "three";
// import {
//   AntennaConfig,
//   ColormapType,
//   HeatmapMetric,
//   RFEnvironmentConfig,
// } from "../../types/antenna";
// import { calculateRadiationPattern } from "../../math/radiationPatterns";
// import { getColorFromColormap } from "../../math/colormaps";
// import {
//   calculateElectricField,
//   calculatePowerDensityUWCm2,
// } from "../../math/rfPhysics";
// import { calculateDirectionalCoverageMetrics } from "../../math/directionalCoverage";

// /**
//  * Builds a radiation-pattern mesh whose radius is the maximum usable RF range
//  * in each direction. The pattern still controls the shape; the RF link budget
//  * controls how far each part of the shape extends.
//  */
// export function createRadiationLobeMesh(
//   config: AntennaConfig,
//   peerConfig: AntennaConfig,
//   rxSensitivityDbm: number,
//   colormap: ColormapType,
//   heatmapMetric: HeatmapMetric,
//   evalDistanceMeters: number,
//   rfEnvironment?: RFEnvironmentConfig,
// ): THREE.Mesh {
//   // Keep the existing mesh resolution and visual quality.
//   const uSegments = 64; // theta
//   const vSegments = 96; // phi

//   const vertexCount = (uSegments + 1) * (vSegments + 1);
//   const positions = new Float32Array(vertexCount * 3);
//   const colors = new Float32Array(vertexCount * 3);
//   const uvs = new Float32Array(vertexCount * 2);
//   const indices: number[] = [];

//   // The configured gainDbi is the peak of the normalized pattern model.
//   const peakDbi = config.gainDbi;
//   const minDbi = peakDbi - 30; // Keep the existing 30 dB gain-color range.
//   const peakMetrics = calculateDirectionalCoverageMetrics(
//     config,
//     peerConfig,
//     peakDbi,
//     evalDistanceMeters,
//     rxSensitivityDbm,
//     rfEnvironment,
//   );
//   const peakEField = calculateElectricField(
//     peakMetrics.eirpWatts,
//     evalDistanceMeters,
//   );
//   const peakPowerDensity = calculatePowerDensityUWCm2(
//     peakMetrics.eirpWatts,
//     evalDistanceMeters,
//   );

//   const scaleLobe = Math.max(0.01, config.scaleLobe || 1);
//   let vertexIndex = 0;

//   for (let i = 0; i <= uSegments; i++) {
//     const theta = (i / uSegments) * Math.PI;

//     for (let j = 0; j <= vSegments; j++) {
//       const phi = (j / vSegments) * 2 * Math.PI - Math.PI;
//       const sample = calculateRadiationPattern(theta, phi, config);

//       // A TX lobe uses directional TX gain. An RX lobe uses the reciprocal
//       // directional RX gain. The partner is assumed optimally aligned at peak
//       // gain, so this is a potential-coverage envelope, not the live link SNR.
//       const metrics = calculateDirectionalCoverageMetrics(
//         config,
//         peerConfig,
//         sample.gainDbi,
//         evalDistanceMeters,
//         rxSensitivityDbm,
//         rfEnvironment,
//       );

//       // One Three.js world unit represents one metre in the coverage scene.
//       // Use the calculated range directly rather than the old fixed 0.18–2.4 radius.
//       const rangeMeters = metrics.coverageRangeMeters;
//       const radius = Math.max(0.1, rangeMeters) * scaleLobe;

//       const sinTheta = Math.sin(theta);
//       const cosTheta = Math.cos(theta);
//       const sinPhi = Math.sin(phi);
//       const cosPhi = Math.cos(phi);

//       const pIdx = vertexIndex * 3;
//       positions[pIdx] = radius * sinTheta * cosPhi;
//       positions[pIdx + 1] = radius * cosTheta;
//       positions[pIdx + 2] = radius * sinTheta * sinPhi;

//       // Heatmap colors continue to represent the metric selected in the UI.
//       let normVal = 0;
//       switch (heatmapMetric) {
//         case "dbi": {
//           normVal = (sample.gainDbi - minDbi) / Math.max(1, peakDbi - minDbi);
//           break;
//         }
//         case "rssi": {
//           const minRssi = peakMetrics.rssiDbm - 35;
//           normVal = (metrics.rssiDbm - minRssi) / 35;
//           break;
//         }
//         case "snr": {
//           // Preserve the existing -5 dB to +35 dB color window.
//           normVal = (metrics.snrDb + 5) / 40;
//           break;
//         }
//         case "field_strength": {
//           const eField = calculateElectricField(
//             metrics.eirpWatts,
//             evalDistanceMeters,
//           );
//           normVal = eField / Math.max(0.001, peakEField);
//           break;
//         }
//         case "power_density": {
//           const density = calculatePowerDensityUWCm2(
//             metrics.eirpWatts,
//             evalDistanceMeters,
//           );
//           normVal = density / Math.max(0.001, peakPowerDensity);
//           break;
//         }
//       }

//       normVal = Math.max(0, Math.min(1, normVal));
//       const color = getColorFromColormap(normVal, colormap);
//       colors[pIdx] = color.r;
//       colors[pIdx + 1] = color.g;
//       colors[pIdx + 2] = color.b;

//       uvs[vertexIndex * 2] = j / vSegments;
//       uvs[vertexIndex * 2 + 1] = i / uSegments;
//       vertexIndex++;
//     }
//   }

//   // Create triangles.
//   for (let i = 0; i < uSegments; i++) {
//     for (let j = 0; j < vSegments; j++) {
//       const a = i * (vSegments + 1) + j;
//       const b = (i + 1) * (vSegments + 1) + j;
//       const c = (i + 1) * (vSegments + 1) + (j + 1);
//       const d = i * (vSegments + 1) + (j + 1);
//       indices.push(a, b, d);
//       indices.push(b, c, d);
//     }
//   }

//   const geometry = new THREE.BufferGeometry();
//   geometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
//   geometry.setAttribute("color", new THREE.BufferAttribute(colors, 3));
//   geometry.setAttribute("uv", new THREE.BufferAttribute(uvs, 2));
//   geometry.setIndex(indices);
//   geometry.computeVertexNormals();

//   const material = new THREE.MeshStandardMaterial({
//     vertexColors: true,
//     roughness: 0.25,
//     metalness: 0.15,
//     wireframe: config.wireframe,
//     transparent: true,
//     opacity: config.opacity,
//     side: THREE.DoubleSide,
//     depthWrite: false,
//   });

//   const mesh = new THREE.Mesh(geometry, material);
//   mesh.name = `radiation-lobe-${config.id}`;
//   mesh.userData = { configId: config.id, isRadiationLobe: true };
//   return mesh;
// }

// /**
//  * Builds physical 3D antenna representation (brass/copper/dielectric realistic models)
//  */
// export function createPhysicalAntennaMesh(config: AntennaConfig): THREE.Group {
//   const group = new THREE.Group();
//   group.name = `physical-antenna-${config.id}`;

//   const { type, lengthMm, diameterMm } = config;

//   // Normalized scale: map 100mm -> 1.0 unit in 3D scene
//   const lengthScale = Math.max(0.2, Math.min(4.0, lengthMm / 100));
//   const diaScale = Math.max(0.015, Math.min(0.25, diameterMm / 100));

//   // Materials
//   const copperMaterial = new THREE.MeshStandardMaterial({
//     color: 0xcd7f32,
//     metalness: 0.9,
//     roughness: 0.2,
//   });

//   const brassMaterial = new THREE.MeshStandardMaterial({
//     color: 0xd4af37,
//     metalness: 0.85,
//     roughness: 0.25,
//   });

//   const chromeMaterial = new THREE.MeshStandardMaterial({
//     color: 0xdde2ea,
//     metalness: 0.95,
//     roughness: 0.1,
//   });

//   const pcbMaterial = new THREE.MeshStandardMaterial({
//     color: 0x14532d, // dark FR4 green
//     metalness: 0.1,
//     roughness: 0.5,
//   });

//   const feedMaterial = new THREE.MeshStandardMaterial({
//     color: 0x1e293b,
//     metalness: 0.4,
//     roughness: 0.6,
//   });

//   switch (type) {
//     case "dipole": {
//       // Center fed dipole with upper and lower elements along Y axis
//       const armLength = (lengthScale * 0.95) / 2;
//       const radius = Math.max(0.02, diaScale);

//       // Upper arm
//       const upperGeo = new THREE.CylinderGeometry(
//         radius,
//         radius,
//         armLength,
//         16,
//       );
//       const upperMesh = new THREE.Mesh(upperGeo, brassMaterial);
//       upperMesh.position.y = armLength / 2 + 0.04;

//       // Lower arm
//       const lowerGeo = new THREE.CylinderGeometry(
//         radius,
//         radius,
//         armLength,
//         16,
//       );
//       const lowerMesh = new THREE.Mesh(lowerGeo, brassMaterial);
//       lowerMesh.position.y = -armLength / 2 - 0.04;

//       // Center feedpoint insulator / balun
//       const feedGeo = new THREE.CylinderGeometry(
//         radius * 1.6,
//         radius * 1.6,
//         0.08,
//         16,
//       );
//       const feedMesh = new THREE.Mesh(feedGeo, feedMaterial);

//       // Coax feed connector
//       const coaxGeo = new THREE.CylinderGeometry(
//         radius * 0.8,
//         radius * 0.8,
//         0.35,
//         12,
//       );
//       const coaxMesh = new THREE.Mesh(coaxGeo, chromeMaterial);
//       coaxMesh.rotation.z = Math.PI / 2;
//       coaxMesh.position.x = -0.18;

//       group.add(upperMesh, lowerMesh, feedMesh, coaxMesh);
//       break;
//     }

//     case "monopole": {
//       // Quarter-wave whip along +Y over ground plane disc
//       const whipLength = lengthScale * 0.9;
//       const radius = Math.max(0.02, diaScale);

//       // Ground plane disc
//       const groundGeo = new THREE.CylinderGeometry(
//         radius * 8,
//         radius * 8,
//         0.03,
//         32,
//       );
//       const groundMesh = new THREE.Mesh(groundGeo, chromeMaterial);
//       groundMesh.position.y = 0;

//       // Whip element
//       const whipGeo = new THREE.CylinderGeometry(
//         radius * 0.7,
//         radius,
//         whipLength,
//         16,
//       );
//       const whipMesh = new THREE.Mesh(whipGeo, brassMaterial);
//       whipMesh.position.y = whipLength / 2 + 0.02;

//       // SMA base
//       const baseGeo = new THREE.CylinderGeometry(
//         radius * 2,
//         radius * 2,
//         0.1,
//         16,
//       );
//       const baseMesh = new THREE.Mesh(baseGeo, feedMaterial);
//       baseMesh.position.y = -0.05;

//       group.add(groundMesh, whipMesh, baseMesh);
//       break;
//     }

//     case "patch": {
//       // Microstrip patch: FR4 PCB substrate + copper rectangular patch on top facing +X
//       const size = lengthScale * 0.7;
//       const subGeo = new THREE.BoxGeometry(0.04, size * 1.3, size * 1.3);
//       const subMesh = new THREE.Mesh(subGeo, pcbMaterial);

//       const patchGeo = new THREE.BoxGeometry(0.02, size * 0.9, size * 0.9);
//       const patchMesh = new THREE.Mesh(patchGeo, copperMaterial);
//       patchMesh.position.x = 0.025; // on top of substrate facing +X

//       // SMA connector on the back
//       const smaGeo = new THREE.CylinderGeometry(0.04, 0.04, 0.15, 12);
//       const smaMesh = new THREE.Mesh(smaGeo, brassMaterial);
//       smaMesh.rotation.z = Math.PI / 2;
//       smaMesh.position.x = -0.09;

//       group.add(subMesh, patchMesh, smaMesh);
//       break;
//     }

//     case "yagi": {
//       // Boom + Reflector + Driven element + Directors along +X axis
//       const boomLength = lengthScale * 1.5;
//       const boomGeo = new THREE.CylinderGeometry(0.025, 0.025, boomLength, 12);
//       const boomMesh = new THREE.Mesh(boomGeo, chromeMaterial);
//       boomMesh.rotation.z = Math.PI / 2;
//       boomMesh.position.x = boomLength / 2 - 0.2;

//       // Reflector (longest element at rear)
//       const refLen = lengthScale * 0.95;
//       const refGeo = new THREE.CylinderGeometry(0.015, 0.015, refLen, 12);
//       const refMesh = new THREE.Mesh(refGeo, chromeMaterial);
//       refMesh.position.x = -0.15;

//       // Driven element (dipole with feed)
//       const drvLen = lengthScale * 0.85;
//       const drvGeo = new THREE.CylinderGeometry(0.018, 0.018, drvLen, 12);
//       const drvMesh = new THREE.Mesh(drvGeo, brassMaterial);
//       drvMesh.position.x = 0.08;

//       group.add(boomMesh, refMesh, drvMesh);

//       // 4 Directors spaced along +X
//       for (let i = 1; i <= 4; i++) {
//         const dirLen = drvLen * (1 - i * 0.06);
//         const dirGeo = new THREE.CylinderGeometry(0.015, 0.015, dirLen, 12);
//         const dirMesh = new THREE.Mesh(dirGeo, chromeMaterial);
//         dirMesh.position.x = 0.08 + i * (boomLength / 5);
//         group.add(dirMesh);
//       }
//       break;
//     }

//     case "horn": {
//       // Pyramidal flared horn facing +X
//       const hornLength = lengthScale * 0.9;
//       const apertureSize = Math.max(0.4, diaScale * 3);
//       const throatSize = 0.12;

//       // Flared horn pyramid
//       const hornGeo = new THREE.CylinderGeometry(
//         apertureSize,
//         throatSize,
//         hornLength,
//         4,
//         1,
//         true,
//       );
//       const hornMesh = new THREE.Mesh(hornGeo, brassMaterial);
//       hornMesh.rotation.z = -Math.PI / 2;
//       hornMesh.rotation.y = Math.PI / 4;
//       hornMesh.position.x = hornLength / 2;

//       // Waveguide throat & flange
//       const throatGeo = new THREE.CylinderGeometry(
//         throatSize,
//         throatSize,
//         0.2,
//         4,
//       );
//       const throatMesh = new THREE.Mesh(throatGeo, chromeMaterial);
//       throatMesh.rotation.z = -Math.PI / 2;
//       throatMesh.rotation.y = Math.PI / 4;
//       throatMesh.position.x = -0.1;

//       group.add(hornMesh, throatMesh);
//       break;
//     }

//     case "helical": {
//       // Ground reflector disc + helical wire wound along +Z or +Y
//       const groundGeo = new THREE.CylinderGeometry(0.5, 0.5, 0.02, 24);
//       const groundMesh = new THREE.Mesh(groundGeo, chromeMaterial);
//       groundMesh.position.y = -0.1;

//       // Spiral coil curve
//       const turns = 6;
//       const height = lengthScale * 1.1;
//       const coilRadius = Math.max(0.12, diaScale);
//       const curvePoints: THREE.Vector3[] = [];

//       for (let t = 0; t <= 120; t++) {
//         const angle = (t / 120) * (turns * 2 * Math.PI);
//         const cy = (t / 120) * height;
//         const cx = coilRadius * Math.cos(angle);
//         const cz = coilRadius * Math.sin(angle);
//         curvePoints.push(new THREE.Vector3(cx, cy, cz));
//       }

//       const curve = new THREE.CatmullRomCurve3(curvePoints);
//       const tubeGeo = new THREE.TubeGeometry(curve, 90, 0.015, 8, false);
//       const tubeMesh = new THREE.Mesh(tubeGeo, copperMaterial);

//       group.add(groundMesh, tubeMesh);
//       break;
//     }

//     case "isotropic":
//     default: {
//       // Glowing omnidirectional beacon sphere
//       const sphereGeo = new THREE.SphereGeometry(0.12, 24, 24);
//       const sphereMat = new THREE.MeshStandardMaterial({
//         color: 0x38bdf8,
//         emissive: 0x0284c7,
//         emissiveIntensity: 0.6,
//         roughness: 0.2,
//       });
//       const beacon = new THREE.Mesh(sphereGeo, sphereMat);
//       group.add(beacon);
//       break;
//     }
//   }

//   // Anchor ring indicator
//   const ringGeo = new THREE.RingGeometry(0.1, 0.15, 24);
//   const ringMat = new THREE.MeshBasicMaterial({
//     color: new THREE.Color(config.color),
//     side: THREE.DoubleSide,
//     transparent: true,
//     opacity: 0.8,
//   });
//   const ring = new THREE.Mesh(ringGeo, ringMat);
//   ring.rotation.x = Math.PI / 2;
//   ring.position.y = -0.01;
//   group.add(ring);

//   return group;
// }
// import * as THREE from 'three';
// import { AntennaConfig, ColormapType, HeatmapMetric, RFEnvironmentConfig } from '../../types/antenna';
// import { calculateRadiationPattern } from '../../math/radiationPatterns';
// import { getColorFromColormap } from '../../math/colormaps';
// import {
//   mwToDbm,
//   calculateReceivedPowerDbm,
//   calculateElectricField,
//   calculatePowerDensityUWCm2,
//   calculateEIRP,
//   calculateSNR,
// } from '../../math/rfPhysics';

// /**
//  * Builds the 3D Radiation Lobe Mesh with vertex colors corresponding to the radiation heatmap
//  */
// export function createRadiationLobeMesh(
//   config: AntennaConfig,
//   colormap: ColormapType,
//   heatmapMetric: HeatmapMetric,
//   evalDistanceMeters: number,
//   rfEnvironment?: RFEnvironmentConfig
// ): THREE.Mesh {
//   // Discretization: 64 theta steps (polar), 96 phi steps (azimuth)
//   const uSegments = 64; // theta
//   const vSegments = 96; // phi

//   const vertexCount = (uSegments + 1) * (vSegments + 1);
//   const positions = new Float32Array(vertexCount * 3);
//   const colors = new Float32Array(vertexCount * 3);
//   const normals = new Float32Array(vertexCount * 3);
//   const uvs = new Float32Array(vertexCount * 2);
//   const indices: number[] = [];

//   const { gainDbi, powerMilliwatts, frequencyMHz } = config;
//   const { eirpWatts } = calculateEIRP(powerMilliwatts, gainDbi);

//   const weather = rfEnvironment?.weather || 'clear';
//   const bwHz = (rfEnvironment?.bandwidthMHz || 20) * 1e6;
//   const nfDb = rfEnvironment?.noiseFigureDb || 5;

//   // Determine dynamic range for heatmap metric
//   const peakDbi = gainDbi;
//   const minDbi = peakDbi - 30; // 30 dB dynamic range

//   let vertexIndex = 0;

//   for (let i = 0; i <= uSegments; i++) {
//     const u = i / uSegments;
//     const theta = u * Math.PI; // 0 to PI

//     for (let j = 0; j <= vSegments; j++) {
//       const v = j / vSegments;
//       const phi = v * 2 * Math.PI - Math.PI; // -PI to PI

//       // Sample radiation pattern
//       const sample = calculateRadiationPattern(theta, phi, config);

//       const r = sample.radius * (config.scaleLobe || 1.0);
//       const sinT = Math.sin(theta);
//       const cosT = Math.cos(theta);
//       const sinP = Math.sin(phi);
//       const cosP = Math.cos(phi);

//       const px = r * sinT * cosP;
//       const py = r * cosT;
//       const pz = r * sinT * sinP;

//       const pIdx = vertexIndex * 3;
//       positions[pIdx] = px;
//       positions[pIdx + 1] = py;
//       positions[pIdx + 2] = pz;

//       // Calculate normalized value for heatmap coloring
//       let normVal = 0;

//       switch (heatmapMetric) {
//         case 'dbi': {
//           normVal = (sample.gainDbi - minDbi) / Math.max(1, peakDbi - minDbi);
//           break;
//         }
//         case 'rssi': {
//           const { rssiDbm } = calculateReceivedPowerDbm(powerMilliwatts, sample.gainDbi, 0, evalDistanceMeters, frequencyMHz, weather);
//           const maxRssi = mwToDbm(powerMilliwatts) + peakDbi - 40;
//           const minRssi = maxRssi - 35;
//           normVal = (rssiDbm - minRssi) / Math.max(1, maxRssi - minRssi);
//           break;
//         }
//         case 'snr': {
//           const { rssiDbm } = calculateReceivedPowerDbm(powerMilliwatts, sample.gainDbi, 0, evalDistanceMeters, frequencyMHz, weather);
//           const { snrDb } = calculateSNR(rssiDbm, bwHz, nfDb);
//           // Map -5 dB to +35 dB onto [0, 1]
//           normVal = (snrDb - (-5)) / 40;
//           break;
//         }
//         case 'field_strength': {
//           const eField = calculateElectricField(eirpWatts * Math.pow(sample.relativeLinear, 2), evalDistanceMeters);
//           const maxE = calculateElectricField(eirpWatts, evalDistanceMeters);
//           normVal = eField / Math.max(0.001, maxE);
//           break;
//         }
//         case 'power_density': {
//           const s = calculatePowerDensityUWCm2(eirpWatts * Math.pow(sample.relativeLinear, 2), evalDistanceMeters);
//           const maxS = calculatePowerDensityUWCm2(eirpWatts, evalDistanceMeters);
//           normVal = s / Math.max(0.001, maxS);
//           break;
//         }
//       }

//       normVal = Math.max(0, Math.min(1, normVal));
//       const col = getColorFromColormap(normVal, colormap);

//       colors[pIdx] = col.r;
//       colors[pIdx + 1] = col.g;
//       colors[pIdx + 2] = col.b;

//       uvs[vertexIndex * 2] = v;
//       uvs[vertexIndex * 2 + 1] = u;

//       vertexIndex++;
//     }
//   }

//   // Create Triangles
//   for (let i = 0; i < uSegments; i++) {
//     for (let j = 0; j < vSegments; j++) {
//       const a = i * (vSegments + 1) + j;
//       const b = (i + 1) * (vSegments + 1) + j;
//       const c = (i + 1) * (vSegments + 1) + (j + 1);
//       const d = i * (vSegments + 1) + (j + 1);

//       indices.push(a, b, d);
//       indices.push(b, c, d);
//     }
//   }

//   const geometry = new THREE.BufferGeometry();
//   geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
//   geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
//   geometry.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
//   geometry.setIndex(indices);
//   geometry.computeVertexNormals();

//   // Mesh Material
//   const material = new THREE.MeshStandardMaterial({
//     vertexColors: true,
//     roughness: 0.25,
//     metalness: 0.15,
//     wireframe: config.wireframe,
//     transparent: true,
//     opacity: config.opacity,
//     side: THREE.DoubleSide,
//     depthWrite: false, // Prevents Z-fighting in transparent dual lobes
//   });

//   const mesh = new THREE.Mesh(geometry, material);
//   mesh.name = `radiation-lobe-${config.id}`;
//   mesh.userData = { configId: config.id, isRadiationLobe: true };

//   return mesh;
// }

// /**
//  * Builds physical 3D antenna representation (brass/copper/dielectric realistic models)
//  */
// export function createPhysicalAntennaMesh(config: AntennaConfig): THREE.Group {
//   const group = new THREE.Group();
//   group.name = `physical-antenna-${config.id}`;

//   const { type, lengthMm, diameterMm } = config;

//   // Normalized scale: map 100mm -> 1.0 unit in 3D scene
//   const lengthScale = Math.max(0.2, Math.min(4.0, (lengthMm / 100)));
//   const diaScale = Math.max(0.015, Math.min(0.25, (diameterMm / 100)));

//   // Materials
//   const copperMaterial = new THREE.MeshStandardMaterial({
//     color: 0xcd7f32,
//     metalness: 0.9,
//     roughness: 0.2,
//   });

//   const brassMaterial = new THREE.MeshStandardMaterial({
//     color: 0xd4af37,
//     metalness: 0.85,
//     roughness: 0.25,
//   });

//   const chromeMaterial = new THREE.MeshStandardMaterial({
//     color: 0xdde2ea,
//     metalness: 0.95,
//     roughness: 0.1,
//   });

//   const pcbMaterial = new THREE.MeshStandardMaterial({
//     color: 0x14532d, // dark FR4 green
//     metalness: 0.1,
//     roughness: 0.5,
//   });

//   const feedMaterial = new THREE.MeshStandardMaterial({
//     color: 0x1e293b,
//     metalness: 0.4,
//     roughness: 0.6,
//   });

//   switch (type) {
//     case 'dipole': {
//       // Center fed dipole with upper and lower elements along Y axis
//       const armLength = (lengthScale * 0.95) / 2;
//       const radius = Math.max(0.02, diaScale);

//       // Upper arm
//       const upperGeo = new THREE.CylinderGeometry(radius, radius, armLength, 16);
//       const upperMesh = new THREE.Mesh(upperGeo, brassMaterial);
//       upperMesh.position.y = armLength / 2 + 0.04;

//       // Lower arm
//       const lowerGeo = new THREE.CylinderGeometry(radius, radius, armLength, 16);
//       const lowerMesh = new THREE.Mesh(lowerGeo, brassMaterial);
//       lowerMesh.position.y = -armLength / 2 - 0.04;

//       // Center feedpoint insulator / balun
//       const feedGeo = new THREE.CylinderGeometry(radius * 1.6, radius * 1.6, 0.08, 16);
//       const feedMesh = new THREE.Mesh(feedGeo, feedMaterial);

//       // Coax feed connector
//       const coaxGeo = new THREE.CylinderGeometry(radius * 0.8, radius * 0.8, 0.35, 12);
//       const coaxMesh = new THREE.Mesh(coaxGeo, chromeMaterial);
//       coaxMesh.rotation.z = Math.PI / 2;
//       coaxMesh.position.x = -0.18;

//       group.add(upperMesh, lowerMesh, feedMesh, coaxMesh);
//       break;
//     }

//     case 'monopole': {
//       // Quarter-wave whip along +Y over ground plane disc
//       const whipLength = lengthScale * 0.9;
//       const radius = Math.max(0.02, diaScale);

//       // Ground plane disc
//       const groundGeo = new THREE.CylinderGeometry(radius * 8, radius * 8, 0.03, 32);
//       const groundMesh = new THREE.Mesh(groundGeo, chromeMaterial);
//       groundMesh.position.y = 0;

//       // Whip element
//       const whipGeo = new THREE.CylinderGeometry(radius * 0.7, radius, whipLength, 16);
//       const whipMesh = new THREE.Mesh(whipGeo, brassMaterial);
//       whipMesh.position.y = whipLength / 2 + 0.02;

//       // SMA base
//       const baseGeo = new THREE.CylinderGeometry(radius * 2, radius * 2, 0.1, 16);
//       const baseMesh = new THREE.Mesh(baseGeo, feedMaterial);
//       baseMesh.position.y = -0.05;

//       group.add(groundMesh, whipMesh, baseMesh);
//       break;
//     }

//     case 'patch': {
//       // Microstrip patch: FR4 PCB substrate + copper rectangular patch on top facing +X
//       const size = lengthScale * 0.7;
//       const subGeo = new THREE.BoxGeometry(0.04, size * 1.3, size * 1.3);
//       const subMesh = new THREE.Mesh(subGeo, pcbMaterial);

//       const patchGeo = new THREE.BoxGeometry(0.02, size * 0.9, size * 0.9);
//       const patchMesh = new THREE.Mesh(patchGeo, copperMaterial);
//       patchMesh.position.x = 0.025; // on top of substrate facing +X

//       // SMA connector on the back
//       const smaGeo = new THREE.CylinderGeometry(0.04, 0.04, 0.15, 12);
//       const smaMesh = new THREE.Mesh(smaGeo, brassMaterial);
//       smaMesh.rotation.z = Math.PI / 2;
//       smaMesh.position.x = -0.09;

//       group.add(subMesh, patchMesh, smaMesh);
//       break;
//     }

//     case 'yagi': {
//       // Boom + Reflector + Driven element + Directors along +X axis
//       const boomLength = lengthScale * 1.5;
//       const boomGeo = new THREE.CylinderGeometry(0.025, 0.025, boomLength, 12);
//       const boomMesh = new THREE.Mesh(boomGeo, chromeMaterial);
//       boomMesh.rotation.z = Math.PI / 2;
//       boomMesh.position.x = boomLength / 2 - 0.2;

//       // Reflector (longest element at rear)
//       const refLen = lengthScale * 0.95;
//       const refGeo = new THREE.CylinderGeometry(0.015, 0.015, refLen, 12);
//       const refMesh = new THREE.Mesh(refGeo, chromeMaterial);
//       refMesh.position.x = -0.15;

//       // Driven element (dipole with feed)
//       const drvLen = lengthScale * 0.85;
//       const drvGeo = new THREE.CylinderGeometry(0.018, 0.018, drvLen, 12);
//       const drvMesh = new THREE.Mesh(drvGeo, brassMaterial);
//       drvMesh.position.x = 0.08;

//       group.add(boomMesh, refMesh, drvMesh);

//       // 4 Directors spaced along +X
//       for (let i = 1; i <= 4; i++) {
//         const dirLen = drvLen * (1 - i * 0.06);
//         const dirGeo = new THREE.CylinderGeometry(0.015, 0.015, dirLen, 12);
//         const dirMesh = new THREE.Mesh(dirGeo, chromeMaterial);
//         dirMesh.position.x = 0.08 + i * (boomLength / 5);
//         group.add(dirMesh);
//       }
//       break;
//     }

//     case 'horn': {
//       // Pyramidal flared horn facing +X
//       const hornLength = lengthScale * 0.9;
//       const apertureSize = Math.max(0.4, diaScale * 3);
//       const throatSize = 0.12;

//       // Flared horn pyramid
//       const hornGeo = new THREE.CylinderGeometry(apertureSize, throatSize, hornLength, 4, 1, true);
//       const hornMesh = new THREE.Mesh(hornGeo, brassMaterial);
//       hornMesh.rotation.z = -Math.PI / 2;
//       hornMesh.rotation.y = Math.PI / 4;
//       hornMesh.position.x = hornLength / 2;

//       // Waveguide throat & flange
//       const throatGeo = new THREE.CylinderGeometry(throatSize, throatSize, 0.2, 4);
//       const throatMesh = new THREE.Mesh(throatGeo, chromeMaterial);
//       throatMesh.rotation.z = -Math.PI / 2;
//       throatMesh.rotation.y = Math.PI / 4;
//       throatMesh.position.x = -0.1;

//       group.add(hornMesh, throatMesh);
//       break;
//     }

//     case 'helical': {
//       // Ground reflector disc + helical wire wound along +Z or +Y
//       const groundGeo = new THREE.CylinderGeometry(0.5, 0.5, 0.02, 24);
//       const groundMesh = new THREE.Mesh(groundGeo, chromeMaterial);
//       groundMesh.position.y = -0.1;

//       // Spiral coil curve
//       const turns = 6;
//       const height = lengthScale * 1.1;
//       const coilRadius = Math.max(0.12, diaScale);
//       const curvePoints: THREE.Vector3[] = [];

//       for (let t = 0; t <= 120; t++) {
//         const angle = (t / 120) * (turns * 2 * Math.PI);
//         const cy = (t / 120) * height;
//         const cx = coilRadius * Math.cos(angle);
//         const cz = coilRadius * Math.sin(angle);
//         curvePoints.push(new THREE.Vector3(cx, cy, cz));
//       }

//       const curve = new THREE.CatmullRomCurve3(curvePoints);
//       const tubeGeo = new THREE.TubeGeometry(curve, 90, 0.015, 8, false);
//       const tubeMesh = new THREE.Mesh(tubeGeo, copperMaterial);

//       group.add(groundMesh, tubeMesh);
//       break;
//     }

//     case 'isotropic':
//     default: {
//       // Glowing omnidirectional beacon sphere
//       const sphereGeo = new THREE.SphereGeometry(0.12, 24, 24);
//       const sphereMat = new THREE.MeshStandardMaterial({
//         color: 0x38bdf8,
//         emissive: 0x0284c7,
//         emissiveIntensity: 0.6,
//         roughness: 0.2,
//       });
//       const beacon = new THREE.Mesh(sphereGeo, sphereMat);
//       group.add(beacon);
//       break;
//     }
//   }

//   // Anchor ring indicator
//   const ringGeo = new THREE.RingGeometry(0.1, 0.15, 24);
//   const ringMat = new THREE.MeshBasicMaterial({
//     color: new THREE.Color(config.color),
//     side: THREE.DoubleSide,
//     transparent: true,
//     opacity: 0.8,
//   });
//   const ring = new THREE.Mesh(ringGeo, ringMat);
//   ring.rotation.x = Math.PI / 2;
//   ring.position.y = -0.01;
//   group.add(ring);

//   return group;
// }
import * as THREE from "three";
import {
  AntennaConfig,
  ColormapType,
  HeatmapMetric,
  RFEnvironmentConfig,
} from "../../types/antenna";
import {
  calculateRadiationPattern,
  getAntennaPeakGainDbi,
} from "../../math/radiationPatterns";
import { getColorFromColormap } from "../../math/colormaps";
import {
  calculateElectricField,
  calculatePowerDensityUWCm2,
  getWavelengthMm,
} from "../../math/rfPhysics";
import { calculateDirectionalCoverageMetrics } from "../../math/directionalCoverage";
import { getSharedGainColorScale } from "../../math/directionGainColors";

export const PATTERN_DISPLAY_RADIUS_METERS = 2.5;

/**
 * Radiation lobe. The silhouette shows modeled coverage range when a usable
 * link exists; otherwise it falls back to a normalized antenna pattern shape.
 * Heatmap color is independent of this radial scale.
 */
export function createRadiationLobeMesh(
  config: AntennaConfig,
  peerConfig: AntennaConfig,
  rxSensitivityDbm: number,
  colormap: ColormapType,
  heatmapMetric: HeatmapMetric,
  evalDistanceMeters: number,
  rfEnvironment?: RFEnvironmentConfig,
): THREE.Mesh {
  // Denser than the old 64×96 grid so multi-lobe wires and horn
  // sidelobes survive the tessellation. Monopoles stop at the horizon:
  // a full sphere with a dark lower hemisphere collapses into a filled cone.
  const thetaLimit = Math.PI;
  // Finer angular sampling keeps narrow null rings and sidelobe valleys from
  // being skipped between vertices, especially on multi-element antennas.
  const uSegments = 128;
  const vSegments = 192;

  const vertexCount = (uSegments + 1) * (vSegments + 1);
  const positions = new Float32Array(vertexCount * 3);
  const colors = new Float32Array(vertexCount * 3);
  const uvs = new Float32Array(vertexCount * 2);
  const indices: number[] = [];

  const peakDbi = getAntennaPeakGainDbi(config);
  const gainColorScale = getSharedGainColorScale(config, peerConfig);
  const peakMetrics = calculateDirectionalCoverageMetrics(
    config,
    peerConfig,
    peakDbi,
    evalDistanceMeters,
    rxSensitivityDbm,
    rfEnvironment,
    false,
  );
  const peakPowerAtDistance =
    peakMetrics.eirpWatts * 10 ** (-peakMetrics.atmosphericLossDb / 10);
  const peakEField = calculateElectricField(
    peakPowerAtDistance,
    evalDistanceMeters,
  );
  const peakPowerDensity = calculatePowerDensityUWCm2(
    peakPowerAtDistance,
    evalDistanceMeters,
  );

  let vertexIndex = 0;

  for (let i = 0; i <= uSegments; i++) {
    const theta = (i / uSegments) * thetaLimit;

    for (let j = 0; j <= vSegments; j++) {
      const phi = (j / vSegments) * 2 * Math.PI - Math.PI;
      const sample = calculateRadiationPattern(theta, phi, config);

      // Solve the distance where the modeled received power reaches sensitivity.
      const metrics = calculateDirectionalCoverageMetrics(
        config,
        peerConfig,
        sample.gainDbi,
        evalDistanceMeters,
        rxSensitivityDbm,
        rfEnvironment,
        true,
      );

      // Show actual link-budget range, not a radius that changes with antenna
      // spacing. If there is no valid receiver/link, show a normalized pattern
      // at a fixed schematic size so the antenna's radiation shape stays visible.
      const coverageRadius = metrics.coverageRangeMeters;
      const patternRadius =
        Math.sqrt(sample.relativeLinear) * PATTERN_DISPLAY_RADIUS_METERS;
      const radius = coverageRadius > 0 ? coverageRadius : patternRadius;

      const sinTheta = Math.sin(theta);
      const cosTheta = Math.cos(theta);
      const sinPhi = Math.sin(phi);
      const cosPhi = Math.cos(phi);

      const pIdx = vertexIndex * 3;
      positions[pIdx] = radius * sinTheta * cosPhi;
      positions[pIdx + 1] = radius * cosTheta;
      positions[pIdx + 2] = radius * sinTheta * sinPhi;

      // Heatmap colors continue to represent the metric selected in the UI.
      let normVal = 0;
      switch (heatmapMetric) {
        case "dbi": {
          normVal =
            (sample.gainDbi - gainColorScale.minDbi) /
            Math.max(1, gainColorScale.maxDbi - gainColorScale.minDbi);
          break;
        }
        case "rssi": {
          const minRssi = peakMetrics.rssiDbm - 35;
          normVal = (metrics.rssiDbm - minRssi) / 35;
          break;
        }
        case "snr": {
          // Preserve the existing -5 dB to +35 dB color window.
          normVal = (metrics.snrDb + 5) / 40;
          break;
        }
        case "field_strength": {
          const receivedPowerWatts =
            metrics.eirpWatts * 10 ** (-metrics.atmosphericLossDb / 10);
          const eField = calculateElectricField(
            receivedPowerWatts,
            evalDistanceMeters,
          );
          normVal = eField / Math.max(0.001, peakEField);
          break;
        }
        case "power_density": {
          const receivedPowerWatts =
            metrics.eirpWatts * 10 ** (-metrics.atmosphericLossDb / 10);
          const density = calculatePowerDensityUWCm2(
            receivedPowerWatts,
            evalDistanceMeters,
          );
          normVal = density / Math.max(0.001, peakPowerDensity);
          break;
        }
      }

      normVal = Number.isFinite(normVal)
        ? Math.max(0, Math.min(1, normVal))
        : 0;
      const color = getColorFromColormap(normVal, colormap);
      colors[pIdx] = color.r;
      colors[pIdx + 1] = color.g;
      colors[pIdx + 2] = color.b;

      uvs[vertexIndex * 2] = j / vSegments;
      uvs[vertexIndex * 2 + 1] = i / uSegments;
      vertexIndex++;
    }
  }

  // Create triangles.
  for (let i = 0; i < uSegments; i++) {
    for (let j = 0; j < vSegments; j++) {
      const a = i * (vSegments + 1) + j;
      const b = (i + 1) * (vSegments + 1) + j;
      const c = (i + 1) * (vSegments + 1) + (j + 1);
      const d = i * (vSegments + 1) + (j + 1);
      indices.push(a, b, d);
      indices.push(b, c, d);
    }
  }

  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
  geometry.setAttribute("color", new THREE.BufferAttribute(colors, 3));
  geometry.setAttribute("uv", new THREE.BufferAttribute(uvs, 2));
  geometry.setIndex(indices);
  geometry.computeVertexNormals();

  const material = new THREE.MeshStandardMaterial({
    vertexColors: true,
    roughness: 0.25,
    metalness: 0.15,
    wireframe: config.wireframe,
    transparent: true,
    opacity: config.opacity,
    side: THREE.DoubleSide,
    depthWrite: false,
  });

  const mesh = new THREE.Mesh(geometry, material);
  mesh.renderOrder = 1;
  mesh.name = `radiation-lobe-${config.id}`;
  mesh.userData = { configId: config.id, isRadiationLobe: true };
  return mesh;
}

/**
 * Builds physical 3D antenna representation (brass/copper/dielectric realistic models)
 */
export function createPhysicalAntennaMesh(config: AntennaConfig): THREE.Group {
  const group = new THREE.Group();
  group.name = `physical-antenna-${config.id}`;

  const { type, lengthMm, diameterMm } = config;

  // Normalized scale: map 100mm -> 1.0 unit in 3D scene
  const lengthScale = Math.max(0.01, lengthMm / 100);
  const diaScale = Math.max(0.001, diameterMm / 100);

  // Materials
  const copperMaterial = new THREE.MeshStandardMaterial({
    color: 0xcd7f32,
    metalness: 0.9,
    roughness: 0.2,
  });

  const brassMaterial = new THREE.MeshStandardMaterial({
    color: 0xd4af37,
    metalness: 0.85,
    roughness: 0.25,
  });

  const chromeMaterial = new THREE.MeshStandardMaterial({
    color: 0xdde2ea,
    metalness: 0.95,
    roughness: 0.1,
  });

  const pcbMaterial = new THREE.MeshStandardMaterial({
    color: 0x14532d, // dark FR4 green
    metalness: 0.1,
    roughness: 0.5,
  });

  const feedMaterial = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    metalness: 0.4,
    roughness: 0.6,
  });

  switch (type) {
    case "dipole": {
      // Center fed dipole with upper and lower elements along Y axis
      const centerGap = Math.min(0.04, lengthScale * 0.1);
      const armLength = Math.max(0.005, (lengthScale - centerGap) / 2);
      const radius = Math.max(0.002, diaScale / 2);

      // Upper arm
      const upperGeo = new THREE.CylinderGeometry(
        radius,
        radius,
        armLength,
        16,
      );
      const upperMesh = new THREE.Mesh(upperGeo, brassMaterial);
      upperMesh.position.y = armLength / 2 + centerGap / 2;

      // Lower arm
      const lowerGeo = new THREE.CylinderGeometry(
        radius,
        radius,
        armLength,
        16,
      );
      const lowerMesh = new THREE.Mesh(lowerGeo, brassMaterial);
      lowerMesh.position.y = -armLength / 2 - centerGap / 2;

      // Center feedpoint insulator / balun
      const feedGeo = new THREE.CylinderGeometry(
        radius * 1.6,
        radius * 1.6,
        0.08,
        16,
      );
      const feedMesh = new THREE.Mesh(feedGeo, feedMaterial);

      // Coax feed connector
      const coaxGeo = new THREE.CylinderGeometry(
        radius * 0.8,
        radius * 0.8,
        0.35,
        12,
      );
      const coaxMesh = new THREE.Mesh(coaxGeo, chromeMaterial);
      coaxMesh.rotation.z = Math.PI / 2;
      coaxMesh.position.x = -0.18;

      group.add(upperMesh, lowerMesh, feedMesh, coaxMesh);
      break;
    }

    case "monopole": {
      // Quarter-wave whip along +Y over ground plane disc
      const whipLength = lengthScale;
      const radius = Math.max(0.002, diaScale / 2);
      const groundPlaneRadius = Math.max(
        0.003,
        (config.monopoleGroundPlaneDiameterMm ??
          getWavelengthMm(config.frequencyMHz) * 0.5) / 200,
      );

      // Ground plane disc
      const groundGeo = new THREE.CylinderGeometry(
        groundPlaneRadius,
        groundPlaneRadius,
        0.03,
        32,
      );
      const groundMesh = new THREE.Mesh(groundGeo, chromeMaterial);
      groundMesh.position.y = 0;

      // Whip element
      const whipGeo = new THREE.CylinderGeometry(
        radius * 0.7,
        radius,
        whipLength,
        16,
      );
      const whipMesh = new THREE.Mesh(whipGeo, brassMaterial);
      whipMesh.position.y = whipLength / 2 + 0.02;

      // SMA base
      const baseGeo = new THREE.CylinderGeometry(
        radius * 2,
        radius * 2,
        0.1,
        16,
      );
      const baseMesh = new THREE.Mesh(baseGeo, feedMaterial);
      baseMesh.position.y = -0.05;

      group.add(groundMesh, whipMesh, baseMesh);
      break;
    }

    case "patch": {
      // Rectangular patch on a dielectric substrate with a finite back plane.
      const mmToScene = (value: number) => Math.max(0.001, value / 100);
      const patchLengthMm = config.patchLengthMm ?? lengthMm;
      const patchWidthMm = config.patchWidthMm ?? diameterMm;
      const groundMarginMm = config.patchGroundMarginMm ?? 8;
      const substrateThickness = mmToScene(config.patchSubstrateThicknessMm ?? 1.6);
      const patchLength = mmToScene(patchLengthMm);
      const patchWidth = mmToScene(patchWidthMm);
      const groundLength = mmToScene(patchLengthMm + groundMarginMm * 2);
      const groundWidth = mmToScene(patchWidthMm + groundMarginMm * 2);
      const subGeo = new THREE.BoxGeometry(
        substrateThickness,
        groundLength,
        groundWidth,
      );
      const subMesh = new THREE.Mesh(subGeo, pcbMaterial);

      const patchGeo = new THREE.BoxGeometry(
        Math.max(0.006, substrateThickness * 0.08),
        patchLength,
        patchWidth,
      );
      const patchMesh = new THREE.Mesh(patchGeo, copperMaterial);
      patchMesh.position.x = substrateThickness / 2 + 0.004;
      const feedInset = mmToScene(
        Math.min(patchLengthMm / 2, config.patchFeedInsetMm ?? patchLengthMm * 0.25),
      );
      patchMesh.position.y = -patchLength / 2 + feedInset;
      const feedTrace = new THREE.Mesh(
        new THREE.BoxGeometry(
          Math.max(0.006, substrateThickness * 0.08),
          Math.max(0.008, feedInset),
          Math.max(0.004, Math.min(0.02, patchWidth * 0.08)),
        ),
        copperMaterial,
      );
      feedTrace.position.set(
        substrateThickness / 2 + 0.004,
        -patchLength / 2 + feedInset / 2,
        0,
      );

      const groundPlane = new THREE.Mesh(
        new THREE.BoxGeometry(0.008, groundLength, groundWidth),
        chromeMaterial,
      );
      groundPlane.position.x = -substrateThickness / 2 - 0.004;

      // SMA connector on the back
      const smaGeo = new THREE.CylinderGeometry(0.025, 0.025, 0.15, 12);
      const smaMesh = new THREE.Mesh(smaGeo, brassMaterial);
      smaMesh.rotation.z = Math.PI / 2;
      smaMesh.position.x = -substrateThickness / 2 - 0.08;
      smaMesh.position.y = patchMesh.position.y;

      group.add(subMesh, groundPlane, patchMesh, feedTrace, smaMesh);
      break;
    }

    case "yagi": {
      // Six-element Yagi: reflector, driven element, and four directors. The
      // boom length sets their actual spacing; frequency sets element length.
      const boomLength = lengthScale;
      const elementCount = Math.max(3, Math.min(16, Math.round(config.yagiElementCount ?? 6)));
      const wavelengthMm = getWavelengthMm(config.frequencyMHz);
      const mmToScene = (value: number) => Math.max(0.001, value / 100);
      const drivenLength = mmToScene(
        config.yagiDrivenElementLengthMm ?? (wavelengthMm > 0 ? wavelengthMm * 0.47 : lengthMm * 0.85),
      );
      const reflectorLength = mmToScene(
        config.yagiReflectorLengthMm ?? (wavelengthMm > 0 ? wavelengthMm * 0.5 : lengthMm * 0.9),
      );
      const directorLength = mmToScene(
        config.yagiDirectorLengthMm ?? (wavelengthMm > 0 ? wavelengthMm * 0.45 : lengthMm * 0.8),
      );
      const elementSpacing = boomLength / (elementCount - 1);
      const elementRadius = Math.max(0.001, diaScale * 0.5);
      const boomRadius = Math.max(0.002, diaScale * 0.65);
      const boomGeo = new THREE.CylinderGeometry(
        boomRadius,
        boomRadius,
        boomLength,
        12,
      );
      const boomMesh = new THREE.Mesh(boomGeo, chromeMaterial);
      boomMesh.rotation.z = Math.PI / 2;
      boomMesh.position.x = boomLength / 2;

      // Reflector (longest element at rear)
      const refGeo = new THREE.CylinderGeometry(
        elementRadius,
        elementRadius,
        reflectorLength,
        12,
      );
      const refMesh = new THREE.Mesh(refGeo, chromeMaterial);
      refMesh.position.x = 0;

      // Driven element (dipole with feed)
      const drvGeo = new THREE.CylinderGeometry(
        elementRadius,
        elementRadius,
        drivenLength,
        12,
      );
      const drvMesh = new THREE.Mesh(drvGeo, brassMaterial);
      drvMesh.position.x = elementSpacing;

      group.add(boomMesh, refMesh, drvMesh);

      // Directors follow the element-count control along the boom.
      for (let i = 2; i < elementCount; i++) {
        const dirGeo = new THREE.CylinderGeometry(
          elementRadius,
          elementRadius,
          directorLength,
          12,
        );
        const dirMesh = new THREE.Mesh(dirGeo, chromeMaterial);
        dirMesh.position.x = i * elementSpacing;
        group.add(dirMesh);
      }
      break;
    }

    case "horn": {
      // Rectangular pyramidal flare from a rectangular waveguide throat to its
      // independently configured mouth; both open toward local +X.
      const mmToScene = (value: number) => Math.max(0.001, value / 100);
      const flareLength = lengthScale;
      const apertureWidth = mmToScene(config.hornApertureWidthMm ?? diameterMm);
      const apertureHeight = mmToScene(config.hornApertureHeightMm ?? diameterMm * 0.8);
      const throatWidth = mmToScene(config.hornThroatWidthMm ?? diameterMm * 0.45);
      const throatHeight = mmToScene(config.hornThroatHeightMm ?? diameterMm * 0.3);
      const corners = [
        [-throatHeight / 2, -throatWidth / 2],
        [throatHeight / 2, -throatWidth / 2],
        [throatHeight / 2, throatWidth / 2],
        [-throatHeight / 2, throatWidth / 2],
        [-apertureHeight / 2, -apertureWidth / 2],
        [apertureHeight / 2, -apertureWidth / 2],
        [apertureHeight / 2, apertureWidth / 2],
        [-apertureHeight / 2, apertureWidth / 2],
      ];
      const hornPositions = new Float32Array([
        0, ...corners[0], 0, ...corners[1], 0, ...corners[2], 0, ...corners[3],
        flareLength, ...corners[4], flareLength, ...corners[5],
        flareLength, ...corners[6], flareLength, ...corners[7],
      ]);
      const hornIndices = [0, 1, 5, 0, 5, 4, 1, 2, 6, 1, 6, 5, 2, 3, 7, 2, 7, 6, 3, 0, 4, 3, 4, 7];
      const hornGeo = new THREE.BufferGeometry();
      hornGeo.setAttribute("position", new THREE.BufferAttribute(hornPositions, 3));
      hornGeo.setIndex(hornIndices);
      hornGeo.computeVertexNormals();
      const hornMesh = new THREE.Mesh(hornGeo, brassMaterial);
      hornMesh.material.side = THREE.DoubleSide;

      const throatMesh = new THREE.Mesh(
        new THREE.BoxGeometry(0.2, throatHeight, throatWidth),
        chromeMaterial,
      );
      throatMesh.position.x = -0.1;
      group.add(hornMesh, throatMesh);
      break;
    }

    case "helical": {
      // Coil axis is +X, the same boresight the radiation pattern uses.
      const mmToScene = (value: number) => Math.max(0.001, value / 100);
      const reflectorRadius = mmToScene(
        (config.helixReflectorDiameterMm ?? getWavelengthMm(config.frequencyMHz) * 1.2) / 2,
      );
      const groundGeo = new THREE.CylinderGeometry(
        reflectorRadius,
        reflectorRadius,
        0.02,
        32,
      );
      const groundMesh = new THREE.Mesh(groundGeo, chromeMaterial);
      groundMesh.rotation.z = Math.PI / 2;
      groundMesh.position.x = -0.08;

      const wavelengthMm = getWavelengthMm(config.frequencyMHz);
      const turns = Math.max(1, Math.min(40, Math.round(config.helixTurns ?? 8)));
      const pitchMm = config.helixPitchMm ?? wavelengthMm * 0.25;
      const height = mmToScene(turns * pitchMm);
      const coilRadius = mmToScene((config.helixCoilDiameterMm ?? diameterMm) / 2);
      const wireRadius = Math.max(0.003, mmToScene(config.helixWireDiameterMm ?? diameterMm) / 2);
      const curvePoints: THREE.Vector3[] = [];
      const steps = Math.max(80, turns * 24);

      for (let t = 0; t <= steps; t++) {
        const angle = (t / steps) * (turns * 2 * Math.PI);
        const cx = (t / steps) * height;
        const cy = coilRadius * Math.cos(angle);
        const cz = coilRadius * Math.sin(angle);
        curvePoints.push(new THREE.Vector3(cx, cy, cz));
      }

      const curve = new THREE.CatmullRomCurve3(curvePoints);
      const tubeGeo = new THREE.TubeGeometry(curve, steps, wireRadius, 8, false);
      const tubeMesh = new THREE.Mesh(tubeGeo, copperMaterial);

      group.add(groundMesh, tubeMesh);
      break;
    }

    case "isotropic":
    default: {
      // Glowing omnidirectional beacon sphere
      const sphereGeo = new THREE.SphereGeometry(0.12, 24, 24);
      const sphereMat = new THREE.MeshStandardMaterial({
        color: 0x38bdf8,
        emissive: 0x0284c7,
        emissiveIntensity: 0.6,
        roughness: 0.2,
      });
      const beacon = new THREE.Mesh(sphereGeo, sphereMat);
      group.add(beacon);
      break;
    }
  }

  // Keep the physical antenna legible at the center of its translucent lobe.
  // The lobe does not write depth, so rendering the source afterward lets the
  // source remain visible without changing the coverage surface itself.
  group.traverse((object) => {
    if (!(object instanceof THREE.Mesh)) return;
    object.renderOrder = 2;
    const materials = Array.isArray(object.material)
      ? object.material
      : [object.material];
    for (const material of materials) {
      material.transparent = true;
      material.opacity = 1;
      material.depthWrite = false;
      material.needsUpdate = true;
    }
  });

  return group;
}
